import { AuthConfig } from 'angular-oauth2-oidc';
import { Wso2ApiConstants } from './wso2-api.constants';
import { environment } from '../../environments/environment';

export const authConfig: AuthConfig = {
    loginUrl: `${Wso2ApiConstants.realUrl}/${Wso2ApiConstants.sso.login}`,
    redirectUri: window.location.origin + '/home',
    silentRefreshRedirectUri: window.location.origin + '/silent-refresh.html',
    clientId: environment.sso.clientId,
    scope: 'openid',
    oidc: true,
    issuer: `${Wso2ApiConstants.realUrl}/${Wso2ApiConstants.sso.issuer}`,
    logoutUrl: `${Wso2ApiConstants.realUrl}/${Wso2ApiConstants.sso.logout}`
};
