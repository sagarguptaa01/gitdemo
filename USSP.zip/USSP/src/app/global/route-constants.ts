export const RouteConstants = {
    data: {
        title: 'title'
    },
    defaultTitle: 'EXFO User Self-Service Portal',
    accountRegistration: {
        path: 'account-registration',
        title: 'Create an organization account'
    },
    accountRegistrationConfirmation: {
        path: 'account-registration-confirmation',
        title: 'Create an organization account'
    },
    activateAccount: {
        path: 'activate-account'
    },
    mandatoryClaims: {
        path: 'mandatory-claims'
    },
    createPassword: {
        path: 'create-password',
        title: 'Create password'
    },
    exfoApps: {
        path: 'exfo-applications'
    },
    resetPassword: {
        path: 'reset-password',
        title: 'Reset password'
    },
    recoverPassword: {
        path: 'recover-password',
        title: 'Recover password'
    },
    recoverPasswordConfirmation: {
        path: 'recover-password-confirmation',
        title: 'Recover password'
    },
    error: {
        path: 'error',
        title: 'Error has occured'
    }
};
