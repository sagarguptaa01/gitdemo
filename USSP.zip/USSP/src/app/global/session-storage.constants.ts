export const SessionStorageConstants = {
    accountEmail: 'accountEmail',
    passwordResetEmail : 'passwordResetEmail',
    newAccountEmail: 'newAccountEmail'
};
