import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';

@Injectable()
export class ErrorExtractorService {
    constructor() {}

    public getErrorMessage(data: any): string {
        let error: string = null;

        try {
            error = this.soapFaultExtract(data);
        } catch (err) {
            try {
                error = this.domExtract(data);
            } catch (err) {
                try {
                    error = this.jsonExtract(data);
                } catch (err) {
                    error = this.restExtract(data);
                }
            }
        }

        if (!error || (error.includes('{') && error.includes('}'))) {
            error = 'Error: Something went wrong';
        } else {
            error = `${"Error: "+error}`;
        }

        return error;
    }

    private restExtract(data): string {
        return data.text();
    }

    private jsonExtract(data): string {
        let errorObject = data.json();
        return errorObject.description;
    }

    private domExtract(data): string {
        let dom = new DOMParser();
        let errorObject = dom.parseFromString(data.text(), 'text/xml');
        let text: Element = errorObject.getElementsByTagName('faultstring')[0];
        return text.childNodes[0].nodeValue;
    }

    private soapFaultExtract(data): string {
        let errorObject = data.json();
        return errorObject.Fault.Reason;
    }
}
