import { TestBed, inject } from '@angular/core/testing';

import { WindowService } from './window.service';

let service: WindowService;

describe('WindowService', () => {
  beforeEach(() => {
    service = new WindowService();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
