import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Observable } from 'rxjs/Rx';

@Injectable()
export class ConfigService {

  private config: Object = null;
  private env: Object = null;
  private CONFIG_FILE_PATH = './assets/conf/config.json';

  constructor(private http: Http) {

  }

  public get(key: any) {
    return this.config[key];
  }

  public load(): Promise<any> {
    return new Promise((resolve, reject) => {

      const request = this.http.get(this.CONFIG_FILE_PATH);
      if (request) {
        request
          .map(res => res.json())
          .catch((error: any) => {
            resolve(error);
            return Observable.throw(error.json().error || 'Something went wrong');
          })
          .subscribe((responseData) => {
            this.config = responseData;
            resolve(true);
          });
      } else {
        resolve(true);
      }
    }).catch((error: any) => {
      return Observable.throw(error.json().error || 'Something went wrong');
    });
  }
}
