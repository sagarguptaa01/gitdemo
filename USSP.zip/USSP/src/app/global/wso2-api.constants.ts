import { environment } from '../../environments/environment';

// TODO Wso2APIConstant devrait être dans wso2 et non pas dans global ?
export const Wso2ApiConstants = {
    realUrl: `${environment.wso2.protocol}://${environment.wso2.address}`,
    // TODO Ne sont pas lier a WSO2, ne devrait pas être dans le fichier WSo2APIConstant
    proxyUrl: `${environment.backend.protocol}://${environment.backend.address}/bsc`,
    proxyAddBasicAuthUrl: `${environment.backend.protocol}://${environment.backend.address}/sbsc`,
    proxyAuthorizationUrl: `${environment.backend.protocol}://${environment.backend.address}/sbsc-remote-auth`,
    services: {
        baseEndpoint: '/services/',
        scimRestEndpoint: '/wso2/scim/',
        tenantMgtAdmin: {
            name: 'TenantMgtAdminService',
            actionAddTenant: 'AddTenant',
            actionGetTenant: 'getTenant',
            actionUpdateTenant: 'updateTenant'
        },
        userAdminService: {
            name: 'UserAdmin',
            action: {
                changePasswordByUser : {
                    soapAction : 'changePasswordByUser'
                }
            }
        },
        remoteAuthorizationManagerService: {
            name: 'RemoteAuthorizationManagerService',
            actionIsUserAuthorized: 'isUserAuthorized'
        },
        userProfile: {
            get: 'Users/me',
            put: 'Users/'
        }
    },
    sso: {
        login: 'oauth2/authorize',
        issuer: 'oauth2/token',
        logout: 'oidc/logout'
    },
    identityRecovery: {
        baseEndpoint: '/api/identity/tenant/v0.9/',
        setPassword: 'set-password',
        addUser: 'add-user',
        validateCode: 'validate-code'
    },
    accountRecovery: {
        baseEndpoint: '/api/identity/recovery/v0.9/',
        recoverPassword: 'recover-password',
        setPassword: 'set-password',
        validateCode: 'validate-code'
    },
    authentication: {
        baseEndpoint: '/authenticationendpoint/',
        claims: 'claims.do'
    }
};
