import { TestBed, inject } from '@angular/core/testing';

import { CountryService } from './country.service';
import {MockBackend} from '@angular/http/testing';
import {BaseRequestOptions, Http, Response, ResponseOptions} from '@angular/http';

describe('CountryService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MockBackend, BaseRequestOptions, {
        provide: Http,
        useFactory: (backendInstance: MockBackend, defaultOptions: BaseRequestOptions) => {
          return new Http(backendInstance, defaultOptions);
        },
        deps: [MockBackend, BaseRequestOptions]
      }, CountryService]
    });
  });

  it('should be created', inject([CountryService], (service: CountryService) => {
    expect(service).toBeTruthy();
  }));

  describe('getCountryList', () => {

    it('should return a list of CountryDto built from country-list.json', 
      inject([CountryService, MockBackend], (service: CountryService, mockBackend: MockBackend) => {
      let mockResponse =  [
          {code: 'AF', name: 'Afghanistan'},
          {code: 'OC', name: 'Oceania'},
          {code: 'US', name: 'United States'},
          {code: 'CA', name: 'Canada'}
      ];

      mockBackend.connections.subscribe((connection) => {
        connection.mockRespond(new Response(new ResponseOptions({
          body: JSON.stringify(mockResponse)
        })));
      });

      service.getCountryList(null).subscribe(countries => {
        expect(countries.length).toEqual(4);
        let countryCodes = countries.map(country => country.code);
        expect(countryCodes).toContain('AF');
        expect(countryCodes).toContain('OC');
        expect(countryCodes).toContain('US');
        expect(countryCodes).toContain('CA');
      })
    }));

    it('the returned country list should be in alphabetical order', inject([CountryService, MockBackend], (service: CountryService, mockBackend: MockBackend) => {
      let mockResponse =  [
          {code: 'AF', name: 'Afghanistan'},
          {code: 'OC', name: 'Oceania'},
          {code: 'US', name: 'United States'},
          {code: 'CA', name: 'Canada'}
      ];

      mockBackend.connections.subscribe((connection) => {
        connection.mockRespond(new Response(new ResponseOptions({
          body: JSON.stringify(mockResponse)
        })));
      });

      service.getCountryList(null).subscribe(countries => {
        expect(countries[0].name).toEqual('Afghanistan');
        expect(countries[1].name).toEqual('Canada');
        expect(countries[2].name).toEqual('Oceania');
        expect(countries[3].name).toEqual('United States');
      })
    }));

    it('the list of country codes passed in parameter should be the first in the returned list', inject([CountryService, MockBackend], (service: CountryService, mockBackend: MockBackend) => {
      let mockResponse =  [
          {code: 'AF', name: 'Afghanistan'},
          {code: 'OC', name: 'Oceania'},
          {code: 'US', name: 'United States'},
          {code: 'CA', name: 'Canada'}
      ];
      
      let firstCountries = ['US', 'OC'];

      mockBackend.connections.subscribe((connection) => {
        connection.mockRespond(new Response(new ResponseOptions({
          body: JSON.stringify(mockResponse)
        })));
      });

      service.getCountryList(firstCountries).subscribe(countries => {
        expect(countries[0].code).toEqual('US');
        expect(countries[1].code).toEqual('OC');
      })
    }));

    it('the countries whose codes are not passed in parameter should be in alphabetical order', inject([CountryService, MockBackend], (service: CountryService, mockBackend: MockBackend) => {
      let mockResponse =  [
          {code: 'AF', name: 'Afghanistan'},
          {code: 'OC', name: 'Oceania'},
          {code: 'US', name: 'United States'},
          {code: 'CA', name: 'Canada'}
      ];
      
      let firstCountries = ['US', 'OC'];

      mockBackend.connections.subscribe((connection) => {
        connection.mockRespond(new Response(new ResponseOptions({
          body: JSON.stringify(mockResponse)
        })));
      });

      service.getCountryList(firstCountries).subscribe(countries => {
        expect(countries[2].name).toEqual('Afghanistan');
        expect(countries[3].name).toEqual('Canada');
      })
    }));
    
  });
});
