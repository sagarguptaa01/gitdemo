export const ConfigKeys = {
  firstCountries: 'firstCountries',
  softwareLicenseAgreement: 'softwareLicenseAgreement',
  userPrivacyNotice: 'userPrivacyNotice',
  firstName: {
    regex: 'utf8Regex',
    maxLength: 'firstNameMaxLength'
  },
  lastName: {
    regex: 'utf8Regex',
    maxLength: 'lastNameMaxLength'
  },
  orgName: {
    regex: 'utf8Regex',
    maxLength: 'orgNameMaxLength'
  },
  companyName: {
    regex: 'utf8Regex',
    maxLength: 'companyNameMaxLength'
  },
  address: {
    regex: 'utf8Regex',
    maxLength: 'addressMaxLength'
  },
  postalCode: {
    regex: 'utf8Regex',
    maxLength: 'postalCodeMaxLength'
  },
  phoneNumber: {
    regex: 'phoneRegex',
    maxLength: 'phoneMaxLength'
  },
  email: {
    regex: 'emailRegex',
    maxLength: 'emailMaxLength'
  },
  password: {
    regex: 'passwordRegex',
    maxLength: 'passwordMaxLength',
    minLength: 'passwordMinLength',
    histroyCount: 'passwordHistoryCount'
  }
}
