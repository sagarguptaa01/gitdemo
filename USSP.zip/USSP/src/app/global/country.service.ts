import { Injectable } from '@angular/core';
import {Http} from '@angular/http';
import {Observable} from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import {CountryDto} from './dto/country.dto';

@Injectable()
export class CountryService {

  private countriesData: CountryDto[] = null;

  constructor(private http: Http) { }

  public getCountryList(firstCountriesCodes: string[]): Observable<CountryDto[]> {

    if (this.countriesData === null) {
      return this.http.get('../../assets/json/country-list.json')
        .map(response => this.sortCountriesByName(firstCountriesCodes, this.parseResponse(response)));
    } else {
      return Observable.of(this.countriesData);
    }
  }

  private sortCountriesByName(firstCountriesCodes: string[], countries: CountryDto[]): CountryDto[] {
    let firstCountries: CountryDto[];
    let otherCountries: CountryDto[];

    if (firstCountriesCodes) {
      firstCountries = this.getCountriesByCode(firstCountriesCodes, countries);
      otherCountries = countries.filter(function(country) { return !firstCountriesCodes.includes(country.code); });
    } else {
      firstCountries = [];
      otherCountries = countries;
    }

    otherCountries.sort(this.compareCountriesByName);

    this.countriesData = firstCountries.concat(otherCountries);
    return this.countriesData;
  }

  private getCountriesByCode(countriesCodes: string[], countries: CountryDto[]): CountryDto[] {
    let firstCountries = [];
    countriesCodes.forEach(code => firstCountries.push(countries.find(country => country.code === code)));
    return firstCountries;
  }

  private compareCountriesByName(countryA: CountryDto, countryB: CountryDto): number {
    let value = 0;
    if (countryA.name < countryB.name) {
      value = -1;
    } else if (countryA.name > countryB.name) {
      value = 1;
    }
    return value;
  }

  private parseResponse(response): CountryDto[] {
    return response.json().map(country => new CountryDto(country.code, country.name));
  }
}
