import { EqualValidatorDirective } from '../../../validator/equal-validator.directive';
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ControlContainer, NgForm } from '@angular/forms';
import { ConfigService } from '../../config.service';
import { ConfigKeys } from '../../config-keys.constants';

@Component({
  selector: 'app-set-password',
  templateUrl: './set-password.component.html',
  styleUrls: ['./set-password.component.css'],
  viewProviders: [ { provide: ControlContainer, useExisting: NgForm }]
})
export class SetPasswordComponent implements OnInit {
  passwordMaxLength: string;
  passwordMinLength: string;
  passwordRegex: string;

  constructor(private config: ConfigService) {}

  ngOnInit() {
    this.passwordMaxLength     =     this.config.get(ConfigKeys.password.maxLength);
    this.passwordMinLength     =     this.config.get(ConfigKeys.password.minLength);
    this.passwordRegex         =     this.config.get(ConfigKeys.password.regex);
   }

}
