import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { SetPasswordComponent } from './set-password.component';
import { NgForm } from '@angular/forms';
import { ConfigService } from '../../config.service';
import { ConfigKeys } from '../../config-keys.constants';

describe('SetPasswordComponent', () => {
  let component: SetPasswordComponent;
  let fixture: ComponentFixture<SetPasswordComponent>;
  let configServiceMock: ConfigService;

  class MockConfigService extends ConfigService {
    constructor() {
      super(null);
    }
  }
  
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SetPasswordComponent ],
     imports: [
        FormsModule
      ],
      providers: [
        { provide: NgForm, useClass: MockNgForm },
        { provide: ConfigService, useClass: MockConfig },
      ]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SetPasswordComponent);
    component = fixture.componentInstance;
    configServiceMock = new MockConfigService();
    component = new SetPasswordComponent(configServiceMock);
    
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

class MockNgForm extends NgForm {

}

class MockConfig {
  public get(key: string) { }
}
