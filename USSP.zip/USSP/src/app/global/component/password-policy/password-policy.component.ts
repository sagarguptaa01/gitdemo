import { Component, OnInit } from '@angular/core';
import { ConfigService } from '../../config.service';
import { ConfigKeys } from '../../config-keys.constants';

@Component({
  selector: 'app-password-policy',
  templateUrl: './password-policy.component.html',
  styleUrls: ['./password-policy.component.css']
})
export class PasswordPolicyComponent implements OnInit {
  passwordMaxLength: string;
  passwordMinLength: string;
  passwordHistoryCount: string;

  constructor(private config: ConfigService) {}

  ngOnInit() {
    this.passwordMaxLength     =     this.config.get(ConfigKeys.password.maxLength);
    this.passwordMinLength     =     this.config.get(ConfigKeys.password.minLength);
    this.passwordHistoryCount  =     this.config.get(ConfigKeys.password.histroyCount);
   }

}
