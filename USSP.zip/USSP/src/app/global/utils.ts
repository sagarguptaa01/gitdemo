export class Utils {

  public static trim(obj: any): any {
    if (obj === null || obj === undefined) {
    return obj;
    } else {
    return obj.trim();
    }
  }
}
