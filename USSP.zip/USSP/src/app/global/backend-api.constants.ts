import { environment } from '../../environments/environment';

export const BackendApiConstants = {
    baseUrl: `${environment.backend.protocol}://${environment.backend.address}`,
    services: {
        tenant: {
            createWithFirstUser:  {
                name: `/tenant`
            },
            exist:  {
                name: `/tenant/exist`
            },
            getProfile: {
                name: `/tenant/profile`
            },
            updateProfile: {
                name: `/tenant/profile`
            },
            validateEmail: {
                Endpoint: '/tenant/validate-email',
                validationStatus: {
                    Success: 'SUCCESS',
                    Failed: 'FAILED',
                    Skipped: 'SKIPPED',
                },
                validationFailedReason: {
                    None: 'NONE',
                    UnverifiableEmail : 'UNVERIFIABLE_EMAIL',
                    MailBoxFull : 'MAILBOX_FULL',
                    TransientNetworkFault : 'TRANSIENT_NETWORKFAULT'
                }
            }
        },
        User: {
            BaseEndpoint: '/user/',
            PasswordStatus: {
                Endpoint: '/password-status',
                Updated: 'UPDATED',
                Pending: 'PENDING'
            }
        },
        setPassword: {
            name: '/setPassword'
        },
        updateUserProfile: {
            name: '/user/profile'
        },
        claim: {
            name: '/claim'
        }
    }
};
