import { UserPortalComponent } from './ussp/user-portal/user-portal.component';
import { AccountRegistrationComponent } from './wso2/registration/account-registration/account-registration.component';
import { NotFoundComponent } from './ussp/other-view/not-found/not-found.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
// tslint:disable-next-line:max-line-length
import { AccountRegistrationConfirmationComponent} from './wso2/registration/account-registration-confirmation/account-registration-confirmation.component';
import { UserProfileComponent} from './ussp/user-profile/user-profile.component';
import { AuthGuardService } from './ussp/auth/service/auth-guard.service';
// tslint:disable-next-line:max-line-length
import { ActivateAccountComponent } from './wso2/registration/activate-account/activate-account.component';
import { ActivateAccountGuardService } from './wso2/registration/service/activate-account-guard.service';
import { ErrorComponent } from './wso2/other-view/error/error.component';
import { ResetPasswordFromPortalComponent } from './ussp/reset-password-from-portal/reset-password-from-portal.component';
import { RecoverPasswordComponent } from './wso2/authentication/view/recover-password/recover-password.component';
import { RecoverPasswordConfirmationComponent } from './wso2/authentication/view/recover-password-confirmation/recover-password-confirmation.component';
import { CreatePasswordComponent } from './wso2/authentication/view/create-password/create-password.component';
import { ResetPasswordComponent } from './wso2/authentication/view/reset-password/reset-password.component';
import { ManageOrgAccountComponent } from './ussp/manage-org-account/manage-org-account.component';
import { RouteConstants } from './global/route-constants';
import { ExfoAppsComponent } from './ussp/exfo-apps/view/exfo-apps/exfo-apps.component';
import { MandatoryClaimsComponent } from './wso2/registration/mandatory-claims/view/mandatory-claims/mandatory-claims.component';
import { CreatePasswordGuardService } from './wso2/authentication/service/create-password-guard.service';
import { ResetPasswordGuardService } from './wso2/authentication/service/reset-password-guard.service';

const appRoutes: Routes = [
  {
    path: '',
    redirectTo: 'home/exfo-applications',
    pathMatch: 'full'
  },
  {
    path: 'home',
    component: UserPortalComponent,
    canActivate: [AuthGuardService],
    canActivateChild: [AuthGuardService],
    children: [
      {
        path: '',
        redirectTo: 'exfo-applications',
        pathMatch: 'full'
      },
      {
        path: 'change-password',
        component: ResetPasswordFromPortalComponent
      },
      {
        path: 'user-profile',
        component: UserProfileComponent
      },
      {
        path: 'manage-org-account',
        component: ManageOrgAccountComponent
      },
      {
        path: 'exfo-applications',
        component: ExfoAppsComponent
      }
    ]
  },
  {
    path: RouteConstants.accountRegistration.path,
    component: AccountRegistrationComponent,
    data: { title: RouteConstants.accountRegistration.title }
  },
  {
    path: RouteConstants.activateAccount.path,
    component: ActivateAccountComponent,
    canActivate: [ActivateAccountGuardService]
  },
  {
    path: RouteConstants.mandatoryClaims.path,
    component: MandatoryClaimsComponent
  },
  {
    path: RouteConstants.createPassword.path,
    component: CreatePasswordComponent,
    data: {
      title: RouteConstants.createPassword.title
    },
    canActivate: [CreatePasswordGuardService]
  },
  {
    path: RouteConstants.resetPassword.path,
    component: ResetPasswordComponent,
    data: {
      title: RouteConstants.resetPassword.title
    },
    canActivate: [ResetPasswordGuardService]
  },
  {
    path: RouteConstants.accountRegistrationConfirmation.path,
    component: AccountRegistrationConfirmationComponent,
    data: { title: RouteConstants.accountRegistrationConfirmation.title }
  },
  {
    path: RouteConstants.error.path,
    component: ErrorComponent,
    data: { title: RouteConstants.error.title }
  },
  {
    path: RouteConstants.recoverPassword.path,
    component: RecoverPasswordComponent,
    data: {
      title: RouteConstants.recoverPassword.title
    }
  },
  {
    path: RouteConstants.recoverPasswordConfirmation.path,
    component: RecoverPasswordConfirmationComponent,
    data: {
      title: RouteConstants.recoverPasswordConfirmation.title
    }
  },
  {
    path: '**',
    component: NotFoundComponent
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(
      appRoutes
    )
  ],
  exports: [
    RouterModule
  ]
})
export class AppRoutingModule { }
