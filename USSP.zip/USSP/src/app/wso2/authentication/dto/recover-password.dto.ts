export class RecoverPasswordDto {
    user: UsernameDto;
    properties = [];

    constructor(username: String) {
        this.user = new UsernameDto(username);
    }
}

export class UsernameDto {
    username : String;
    realm : String = "PRIMARY";
    "tenant-domain" : String = "carbon.super";

    constructor(username: String) {
        this.username = username;
    }
}