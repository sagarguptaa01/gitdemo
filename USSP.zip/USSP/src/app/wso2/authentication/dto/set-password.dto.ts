export class SetPasswordDto {
    key: String;
    password: String;
    properties = [];

    constructor(key: String, password: String, properties = []) {
        this.key = key;
        this.password = password;
        this.properties = properties;
    }
}
