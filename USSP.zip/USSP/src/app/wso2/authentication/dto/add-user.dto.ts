export class AddUserDto {
    key: String;
    properties = [];

    constructor(key: String, properties = []) {
        this.key = key;
        this.properties = properties;
    }
}
