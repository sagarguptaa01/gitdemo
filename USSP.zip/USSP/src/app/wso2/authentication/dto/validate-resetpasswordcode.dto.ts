export class ValidateResetPasswordCodeDto {
    code: String;
    step: String;
    properties = [];

    constructor(code: String) {
        this.code = code;
        this.step = 'UPDATE_PASSWORD';
    }
}

export class ValidateConfirmInviteCodeDto {
    code: String;
    step: String;
    properties = [];

    constructor(code: String) {
        this.code = code;
        this.step = 'CONFIRM_INVITE';
    }
}