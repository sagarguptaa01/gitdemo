import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs/Rx';
import { RouteConstants } from '../../../global/route-constants';
import { IdentityRecoveryService } from '../../authentication/service/identity-recovery.service';

@Injectable()
export class ResetPasswordGuardService implements CanActivate {

  constructor(private router: Router
    , private identityRecoveryService: IdentityRecoveryService) { }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
    let confirmation = route.queryParams.confirmation;

    return this.identityRecoveryService.validateResetPasswordCode(confirmation).map(
      result => this.handleResetPasswordStatusCodeResponse(result, confirmation))
      .catch(error => this.handleError(error));
  }

  private handleResetPasswordStatusCodeResponse(result, confirmation): boolean {
    return true;
  }

  private handleError(error) {
    this.router.navigateByUrl(RouteConstants.error.path);
    return Observable.of(false);
  }
}
