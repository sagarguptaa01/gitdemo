import { TestBed, inject } from '@angular/core/testing';
import { IdentityRecoveryService } from './identity-recovery.service';
import { MockBackend } from '@angular/http/testing';
import { BaseRequestOptions, Http } from '@angular/http';
import { BackendApiConstants } from '../../../global/backend-api.constants';
import { Wso2ApiConstants } from '../../../global/wso2-api.constants';

describe('IdentityRecoveryService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        MockBackend,
        BaseRequestOptions,
        {
          provide: Http,
          useFactory: (backendInstance: MockBackend, defaultOptions: BaseRequestOptions) => {
            return new Http(backendInstance, defaultOptions);
          },
          deps: [MockBackend, BaseRequestOptions]
        },
        IdentityRecoveryService
      ]
    });
  });

  it('should be created', inject([IdentityRecoveryService], (service: IdentityRecoveryService) => {
    expect(service).toBeTruthy();
  }));

  describe('setPassword', () => {
    it('should make a POST request to WSO2\'s setPassword method', inject([IdentityRecoveryService, MockBackend],
      (service: IdentityRecoveryService, mockBackend: MockBackend) => {
      mockBackend.connections.subscribe(connection => {
        expect(connection.request.url).toEqual(Wso2ApiConstants.proxyAddBasicAuthUrl +
                                               Wso2ApiConstants.identityRecovery.baseEndpoint +
                                               Wso2ApiConstants.identityRecovery.setPassword);
      });

      service.setPassword(null, null);
    }));

    it('should include the token and the new password in the POST request body', inject([IdentityRecoveryService, MockBackend],
      (service: IdentityRecoveryService, mockBackend: MockBackend) => {
      let expectedToken = 'expected-token';
      let expectedPassword = 'expected-password';

      mockBackend.connections.subscribe(connection => {
        let body = connection.request.json();
        expect(body.key).toEqual(expectedToken);
        expect(body.password).toEqual(expectedPassword);
      });

      service.setPassword(expectedToken, expectedPassword);
    }));

    it('should include a Content-Type:application/json header', inject([IdentityRecoveryService, MockBackend],
      (service: IdentityRecoveryService, mockBackend: MockBackend) => {
      mockBackend.connections.subscribe((connection) => {
        expect(connection.request.headers.get('Content-Type')).toEqual('application/json');
      });

      service.setPassword(null, null);
    }));
  });

  describe('addUser', () => {
    it('should make a POST request to WSO2\'s add-user method', inject([IdentityRecoveryService, MockBackend],
      (service: IdentityRecoveryService, mockBackend: MockBackend) => {
      let confirmation = 'confirmation';

      mockBackend.connections.subscribe(connection => {
        expect(connection.request.url).toEqual(Wso2ApiConstants.proxyAddBasicAuthUrl +
                                               Wso2ApiConstants.identityRecovery.baseEndpoint +
                                               Wso2ApiConstants.identityRecovery.addUser);
      });

      service.addUser(confirmation);
    }));

    it('should include the token in the POST request body', inject([IdentityRecoveryService, MockBackend],
      (service: IdentityRecoveryService, mockBackend: MockBackend) => {
      let expectedToken = 'expected-token';

      mockBackend.connections.subscribe(connection => {
        let body = connection.request.json();
        expect(body.key).toEqual(expectedToken);
      });

      service.addUser(expectedToken);
    }));

    it('should include a Content-Type:application/json header', inject([IdentityRecoveryService, MockBackend],
      (service: IdentityRecoveryService, mockBackend: MockBackend) => {
      let confirmation = 'confirmation';

      mockBackend.connections.subscribe((connection) => {
        expect(connection.request.headers.get('Content-Type')).toEqual('application/json');
      });

      service.addUser(confirmation);
    }));
  });

  describe('validateResetPasswordCode', () => {
    it('should make a POST request to WSO2\'s validate-code method for validating the reset-password code',
     inject([IdentityRecoveryService, MockBackend],
      (service: IdentityRecoveryService, mockBackend: MockBackend) => {

      // Act
      service.validateResetPasswordCode(null);

      // Assert
      mockBackend.connections.subscribe(connection => {
        expect(connection.request.url).toEqual(Wso2ApiConstants.proxyAddBasicAuthUrl +
                                               Wso2ApiConstants.accountRecovery.baseEndpoint +
                                               Wso2ApiConstants.accountRecovery.validateCode);
      });
    }));

    it('should include reset-password code in the POST request body', inject([IdentityRecoveryService, MockBackend],
      (service: IdentityRecoveryService, mockBackend: MockBackend) => {

      // Arrange
      let expectedRestPasswordCode = 'reset-password-code';
      let expectedStep = 'UPDATE_PASSWORD';

      // Act
      service.validateResetPasswordCode(expectedRestPasswordCode);

      // Assert
      mockBackend.connections.subscribe(connection => {
        let body = connection.request.json();
        expect(body.code).toEqual(expectedRestPasswordCode);
        expect(body.step).toEqual(expectedStep);
      });
    }));

    it('should include a Content-Type:application/json header', inject([IdentityRecoveryService, MockBackend],
      (service: IdentityRecoveryService, mockBackend: MockBackend) => {

      // Act
      service.validateResetPasswordCode(null);

      // Assert
      mockBackend.connections.subscribe((connection) => {
        expect(connection.request.headers.get('Content-Type')).toEqual('application/json');
      });
    }));
  });

  describe('validateConfirmInviteCode', () => {
    it('should make a POST request to WSO2\'s validate-code method for validating the confirm-invite code',
     inject([IdentityRecoveryService, MockBackend],
      (service: IdentityRecoveryService, mockBackend: MockBackend) => {

      // Act
      service.validateConfirmInviteCode(null);

      // Assert
      mockBackend.connections.subscribe(connection => {
        expect(connection.request.url).toEqual(Wso2ApiConstants.proxyAddBasicAuthUrl +
                                               Wso2ApiConstants.identityRecovery.baseEndpoint +
                                               Wso2ApiConstants.identityRecovery.validateCode);
      });
    }));

    it('should include confirm-invite code in the POST request body', inject([IdentityRecoveryService, MockBackend],
      (service: IdentityRecoveryService, mockBackend: MockBackend) => {

      // Arrange
      let expectedInviteCode = 'confirm-invite-code';
      let expectedStep = 'CONFIRM_INVITE';

      // Act
      service.validateConfirmInviteCode(expectedInviteCode);

      // Assert
      mockBackend.connections.subscribe(connection => {
        let body = connection.request.json();
        expect(body.code).toEqual(expectedInviteCode);
        expect(body.step).toEqual(expectedStep);
      });
    }));

    it('should include a Content-Type:application/json header', inject([IdentityRecoveryService, MockBackend],
      (service: IdentityRecoveryService, mockBackend: MockBackend) => {
      // Act
      service.validateConfirmInviteCode(null);

      // Assert
      mockBackend.connections.subscribe((connection) => {
        expect(connection.request.headers.get('Content-Type')).toEqual('application/json');
      });
    }));
  });

});

