import { TestBed, inject } from '@angular/core/testing';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs/Rx';
import { RouteConstants } from '../../../global/route-constants';
import { IdentityRecoveryService } from '../../authentication/service/identity-recovery.service';
import { ResetPasswordGuardService } from './reset-password-guard.service';

describe('ResetPasswordGuardService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        ResetPasswordGuardService,
        { provide: Router, useClass: MockRouter },
        { provide: IdentityRecoveryService, useClass: MockIdentityRecoveryService }
      ]
    });
  });


  it('should be created', inject([ResetPasswordGuardService], (service: ResetPasswordGuardService) => {
    expect(service).toBeTruthy();
  }));

  it('should call Password Confirmation Code API when we call canActivate', inject([ResetPasswordGuardService,
    IdentityRecoveryService],
    (service: ResetPasswordGuardService,
      identityRecoveryService: IdentityRecoveryService) => {

    // Arrange
    let confirmation = 'confirmation';
    let route = createRoute(confirmation);
    let identityRecoverySpy = spyOn(identityRecoveryService, 'validateResetPasswordCode').and.returnValue(Observable.of(true));

    // Act
    let result = service.canActivate(route, null);

    // Assert
    expect(identityRecoverySpy).toHaveBeenCalledWith(confirmation);
  }));

  it('should return true when Password Confirmation Code is Valid', inject([ResetPasswordGuardService,
    IdentityRecoveryService],
    (service: ResetPasswordGuardService,
      identityRecoveryService: IdentityRecoveryService) => {

    // Arrange
    let expected = true;
    let route = createRoute('');
    let identityRecoverySpy = spyOn(identityRecoveryService, 'validateResetPasswordCode').and.returnValue(Observable.of(true));

    // Act
    let result = service.canActivate(route, null);

    // Assert
    expect(result).not.toBeNull();
    result.subscribe( res => {
      expect(res).toBe(expected);
    });

  }));

  it('should return false when Password Confirmation Code is InValid', inject([ResetPasswordGuardService,
    IdentityRecoveryService],
    (service: ResetPasswordGuardService,
      identityRecoveryService: IdentityRecoveryService) => {

    // Arrange
    let expected = false;
    let route = createRoute('');
    let identityRecoverySpy = spyOn(identityRecoveryService, 'validateResetPasswordCode').and.returnValue(Observable.throw('error'));

    // Act
    let result = service.canActivate(route, null);

    // Assert
    expect(result).not.toBeNull();
    result.subscribe( res => {
      expect(res).toBe(expected);
    });
  }));

  it('should navigate to error page when Password Confirmation Code is InValid', inject([ResetPasswordGuardService,
    IdentityRecoveryService, Router],
    (service: ResetPasswordGuardService,
      identityRecoveryService: IdentityRecoveryService,router: Router) => {

    // Arrange
    let expected = false;
    let route = createRoute('');
    let identityRecoverySpy = spyOn(identityRecoveryService, 'validateResetPasswordCode').and.returnValue(Observable.throw('error'));
    let routerSpy = spyOn(router, 'navigateByUrl');

    // Act
    let result = service.canActivate(route, null);

    // Assert
    expect(result).not.toBeNull();
    result.subscribe( res => {
      expect(routerSpy).toHaveBeenCalledWith(RouteConstants.error.path);
    });
  }));
});

class MockIdentityRecoveryService {
  public validateResetPasswordCode(confirmationCode: string): Observable<any> {
    return Observable.of(true);
  }
}

class MockActivatedRouteSnapshot extends ActivatedRouteSnapshot {
  queryParams: any;

    setQueryParams(queryParams: any): void {
      this.queryParams = queryParams;
    }
}

class MockRouter {
  public navigate(url, options) { }
  public navigateByUrl(url: string) { }
}

function createRoute(confirmation: string) {
  let route = new MockActivatedRouteSnapshot();
  route.setQueryParams({
    confirmation: confirmation
  });
  return route;
}

