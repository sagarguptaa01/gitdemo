import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { SetPasswordDto } from '../dto//set-password.dto';
import { RecoverPasswordDto } from '../dto/recover-password.dto';
import { BackendApiConstants } from '../../../global/backend-api.constants';
import { Wso2ApiConstants } from '../../../global/wso2-api.constants';
import { AddUserDto } from '../dto/add-user.dto';
import { ValidateResetPasswordCodeDto, ValidateConfirmInviteCodeDto } from '../dto/validate-resetpasswordcode.dto';

@Injectable()
export class IdentityRecoveryService {

  constructor(private http: Http) { }

  public setPassword(token: string, password: string): Observable<any> {
    let url = Wso2ApiConstants.proxyAddBasicAuthUrl +
              Wso2ApiConstants.identityRecovery.baseEndpoint +
              Wso2ApiConstants.identityRecovery.setPassword;
    let body = new SetPasswordDto(token, password);
    return this.postRequest(url, body);
  }

  public resetPassword(token: string, password: string): Observable<any> {
    let url = Wso2ApiConstants.proxyAddBasicAuthUrl +
              Wso2ApiConstants.accountRecovery.baseEndpoint +
              Wso2ApiConstants.accountRecovery.setPassword;
    let body = new SetPasswordDto(token, password);
    return this.postRequest(url, body);
  }

  public recoverPassword(userName: string): Observable<any> {
    let url = Wso2ApiConstants.proxyAddBasicAuthUrl +
              Wso2ApiConstants.accountRecovery.baseEndpoint +
              Wso2ApiConstants.accountRecovery.recoverPassword;

    let body = new RecoverPasswordDto(userName);
    return this.postRequest(url, body);
  }

  public addUser(confirmationCode: String): Observable<any> {
    let url = Wso2ApiConstants.proxyAddBasicAuthUrl +
              Wso2ApiConstants.identityRecovery.baseEndpoint +
              Wso2ApiConstants.identityRecovery.addUser;
    let body = new AddUserDto(confirmationCode);
    let options = {
      headers: this.getHeaders()
    };
    return this.http.post(url, JSON.stringify(body), options);
  }

  public validateResetPasswordCode(confirmationCode: string): Observable<any> {
    let url = Wso2ApiConstants.proxyAddBasicAuthUrl +
              Wso2ApiConstants.accountRecovery.baseEndpoint +
              Wso2ApiConstants.accountRecovery.validateCode;

    let body = new ValidateResetPasswordCodeDto(confirmationCode);
    return this.postRequest(url, body);
  }

  public validateConfirmInviteCode(confirmationCode: string): Observable<any> {
    let url = Wso2ApiConstants.proxyAddBasicAuthUrl +
              Wso2ApiConstants.identityRecovery.baseEndpoint +
              Wso2ApiConstants.identityRecovery.validateCode;

    let body = new ValidateConfirmInviteCodeDto(confirmationCode);
    return this.postRequest(url, body);
  }

  private getHeaders(): Headers {
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
    return headers;
  }

  private postRequest(url: string, body: any): Observable<any> {
    let options = {
      headers: this.getHeaders()
    };
    return this.http.post(url, JSON.stringify(body), options);
  }
}
