import { TestBed, inject } from '@angular/core/testing';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs/Rx';
import { RouteConstants } from '../../../global/route-constants';
import { IdentityRecoveryService } from '../../authentication/service/identity-recovery.service';
import { CreatePasswordGuardService } from './create-password-guard.service';

describe('CreatePasswordGuardService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        CreatePasswordGuardService,
        { provide: Router, useClass: MockRouter },
        { provide: IdentityRecoveryService, useClass: MockIdentityRecoveryService }
      ]
    });
  });


  it('should be created', inject([CreatePasswordGuardService], (service: CreatePasswordGuardService) => {
    expect(service).toBeTruthy();
  }));

  it('should call Invite Confirmation Code API when we call canActivate', inject([CreatePasswordGuardService,
    IdentityRecoveryService],
    (service: CreatePasswordGuardService,
      identityRecoveryService: IdentityRecoveryService) => {

    // Arrange
    let confirmation = 'confirmation';
    let route = createRoute(confirmation);
    let identityRecoverySpy = spyOn(identityRecoveryService, 'validateConfirmInviteCode').and.returnValue(Observable.of(true));

    // Act
    let result = service.canActivate(route, null);

    // Assert
    expect(identityRecoverySpy).toHaveBeenCalledWith(confirmation);
  }));

  it('should return true when Invite Confirmation Code is Valid', inject([CreatePasswordGuardService,
    IdentityRecoveryService],
    (service: CreatePasswordGuardService,
      identityRecoveryService: IdentityRecoveryService) => {

    // Arrange
    let expected = true;
    let route = createRoute('');
    let identityRecoverySpy = spyOn(identityRecoveryService, 'validateConfirmInviteCode').and.returnValue(Observable.of(true));

    // Act
    let result = service.canActivate(route, null);

    // Assert
    expect(result).not.toBeNull();
    result.subscribe( res => {
      expect(res).toBe(expected);
    });

  }));

  it('should return false when Invite Confirmation Code is InValid', inject([CreatePasswordGuardService,
    IdentityRecoveryService],
    (service: CreatePasswordGuardService,
      identityRecoveryService: IdentityRecoveryService) => {

    // Arrange
    let expected = false;
    let route = createRoute('');
    let identityRecoverySpy = spyOn(identityRecoveryService, 'validateConfirmInviteCode').and.returnValue(Observable.throw('error'));

    // Act
    let result = service.canActivate(route, null);

    // Assert
    expect(result).not.toBeNull();
    result.subscribe( res => {
      expect(res).toBe(expected);
    });
  }));

  it('should navigate to error page when Invite Confirmation Code is InValid', inject([CreatePasswordGuardService,
    IdentityRecoveryService, Router],
    (service: CreatePasswordGuardService,
      identityRecoveryService: IdentityRecoveryService,router: Router) => {

    // Arrange
    let expected = false;
    let route = createRoute('');
    let identityRecoverySpy = spyOn(identityRecoveryService, 'validateConfirmInviteCode').and.returnValue(Observable.throw('error'));
    let routerSpy = spyOn(router, 'navigateByUrl');

    // Act
    let result = service.canActivate(route, null);

    // Assert
    expect(result).not.toBeNull();
    result.subscribe( res => {
      expect(routerSpy).toHaveBeenCalledWith(RouteConstants.error.path);
    });
  }));
});

class MockIdentityRecoveryService {
  public validateConfirmInviteCode(confirmationCode: string): Observable<any> {
    return Observable.of(true);
  }
}

class MockActivatedRouteSnapshot extends ActivatedRouteSnapshot {
  queryParams: any;

    setQueryParams(queryParams: any): void {
      this.queryParams = queryParams;
    }
}

class MockRouter {
  public navigate(url, options) { }
  public navigateByUrl(url: string) { }
}

function createRoute(confirmation: string) {
  let route = new MockActivatedRouteSnapshot();
  route.setQueryParams({
    confirmation: confirmation
  });
  return route;
}

