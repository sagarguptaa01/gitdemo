import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { CreatePasswordComponent } from './create-password.component';
import { Observable } from 'rxjs/Rx';
import { Router, ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';
import { Response, ResponseOptions, ResponseType } from '@angular/http';
import { IdentityRecoveryService } from '../../service/identity-recovery.service';
import { SetPasswordComponent } from '../../../../global/component/set-password/set-password.component';
import { ErrorExtractorService } from '../../../../global/error-extractor.service';
import { ConfigService } from '../../../../global/config.service';



describe('CreatePasswordComponent', () => {
  let component: CreatePasswordComponent;
  let fixture: ComponentFixture<CreatePasswordComponent>;
  let configServiceMock: ConfigService;
  let activatedRoute: ActivatedRoute;

  let mockActivatedRoute = {
    snapshot: {
      queryParamMap: {
        get: function(key) { },
        getAll: function(key) { }
      }
    }
  };

  class MockConfigService extends ConfigService {
    constructor() {
      super(null);
    }
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreatePasswordComponent, SetPasswordComponent ],
     imports: [
        FormsModule
      ],
      providers: [
        { provide: IdentityRecoveryService, useClass: MockIdentityRecoveryService },
        { provide: Router, useClass: MockRouter },
        { provide: ActivatedRoute, useValue: mockActivatedRoute },
        { provide: ErrorExtractorService, useClass: MockErrorExtractor },
        { provide: ConfigService, useClass: MockConfig },
      ]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreatePasswordComponent);
    component = fixture.componentInstance;
    activatedRoute = fixture.debugElement.injector.get(ActivatedRoute);
  });

  it('should create', () => {
    fixture.detectChanges();

    expect(component).toBeTruthy();
  });

  describe('destroy', () => {

    it('should release the savePassword subscription', () => {
      fixture.detectChanges();
      component.savePassword = new Subscription();

      fixture.destroy();

      expect(component.savePassword.closed).toBeTruthy();
    });
  });

  describe('ngOnInit', () => {
    it('should assign the confirmation param from the url to the token parameter', () => {
      let confirmation = 'this-is-confirmation-code-1234';
      activatedRoute.snapshot.queryParamMap.get = jasmine.createSpy('get').and.callFake(function(key) {
        if (key === 'confirmation') {
          return confirmation;
        }
      });

      fixture.detectChanges();

      expect(component.token).toEqual(confirmation);
    });
  });

  describe('Save', () => {
    let identityRecoveryService: IdentityRecoveryService;
    let response: Response;

     beforeEach(() => {
       identityRecoveryService = fixture.debugElement.injector.get(IdentityRecoveryService);
       let options = { type: ResponseType.Default, status: 200, statusText: 'OK' };
       response = new Response(new ResponseOptions(options));
       fixture.detectChanges();
    });

    it('should use IdentityRecoveryService to update password', () => {
      let password = 'this-is-password';
      let token = 'this-is-token';
      component.changePasswordForm = {
        value: {
          newPassword: password
        }
      };
      component.token = token;
      let setPasswordSpy = spyOn(identityRecoveryService, 'setPassword').and.returnValue(Observable.of(null));

      component.save();

      expect(setPasswordSpy).toHaveBeenCalledWith(token, password);
    });

    it('should navigate to the home page after a successful call to setPassword', () => {

      let setPasswordSpy = spyOn(identityRecoveryService, 'setPassword').and.returnValue(Observable.of(null));
      let spy = spyOn(component, 'handleError').and.returnValue(null);
      let router = fixture.debugElement.injector.get(Router);
      let routerSpy = spyOn(router, 'navigateByUrl');

      component.save();

      expect(routerSpy).toHaveBeenCalledWith('/home');
    });

    describe('when the call to setPassword returns an error', () => {

      it('should set the errorMessage', () => {

        let setPasswordSpy = spyOn(identityRecoveryService, 'setPassword').and.returnValue(Observable.throw({'status': 404}));
        let spy = spyOn(component, 'handleError').and.returnValue(null);
        component.save();

        expect(spy).toHaveBeenCalled();
      });
    });
  });
});

class MockIdentityRecoveryService extends IdentityRecoveryService{
  constructor() {
    super(null);
  }

  public setPassword(token: string, password: string): Observable<any> {
    return Observable.of();
  }
}

class MockRouter {
  public navigateByUrl(url: string) { }
}

class MockErrorExtractor extends ErrorExtractorService {
  constructor() {
    super();
  }
}

class MockConfig {
  public get(key: string) { }
}
