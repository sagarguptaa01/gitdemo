import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule, NgControl, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Rx';
import { Response, ResponseOptions } from '@angular/http';

import { SessionStorageConstants } from '../../../../global/session-storage.constants';
import { RecoverPasswordComponent } from './recover-password.component';
import { ErrorExtractorService } from '../../../../global/error-extractor.service';
import { IdentityRecoveryService } from '../../service/identity-recovery.service';
import { ConfigService } from '../../../../global/config.service';

describe('RecoverPasswordComponent', () => {
  let component: RecoverPasswordComponent;
  let fixture: ComponentFixture<RecoverPasswordComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RecoverPasswordComponent ],
      imports: [
        FormsModule,
        ReactiveFormsModule
      ],
      providers: [
        { provide: IdentityRecoveryService, useClass: MockIdentityRecoveryService },
        { provide: Router, useClass: MockRouter },
        { provide: ErrorExtractorService, useClass: MockError },
        { provide: ConfigService, useClass: MockConfigService }
      ]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RecoverPasswordComponent);
    component = fixture.componentInstance;
  });

  it('should be created', () => {
    fixture.detectChanges();
    expect(component).toBeTruthy();
  });

  it('should set the "errorMessage" to ""', () => {
    fixture.detectChanges();
    expect(component.errorMessage).toBeFalsy();
  });

  describe('onSubmit', () => {
    it('should use IdentityRecoveryService to ask the reset password email', () => {
      let recoveryService = fixture.debugElement.injector.get(IdentityRecoveryService);
      let recoveryServiceSpy = spyOn(recoveryService, 'recoverPassword').and.returnValue(Observable.of(null));
      component.accountEmail = 'myUserName';
      component.submit();
      expect(recoveryServiceSpy).toHaveBeenCalledWith(component.accountEmail);
    });

    it('should navigate to the recover-password-confirmation page after a successful call to IdentityRecoveryService', () => {
      let recoveryService = fixture.debugElement.injector.get(IdentityRecoveryService);
      let recoveryServiceSpy = spyOn(recoveryService, 'recoverPassword').and.returnValue(Observable.of(null));
      let router = fixture.debugElement.injector.get(Router);
      let routerSpy = spyOn(router, 'navigateByUrl');
      component.submit();
      expect(routerSpy).toHaveBeenCalledWith('/recover-password-confirmation');
    });

    it('should keep the email in storate after a successful call to IdentityRecoveryService', () => {
        let recoveryService = fixture.debugElement.injector.get(IdentityRecoveryService);
        let recoveryServiceSpy = spyOn(recoveryService, 'recoverPassword').and.returnValue(Observable.of(null));
        component.accountEmail = 'myUserName';
        component.submit();
        expect(sessionStorage.getItem(SessionStorageConstants.passwordResetEmail)).toEqual(component.accountEmail);
      });

    describe('when the call to IdentityRecoveryService returns an error', () => {
      it('should not navigate to another page', () => {
        let recoveryService = fixture.debugElement.injector.get(IdentityRecoveryService);
        let recoveryServiceSpy = spyOn(recoveryService, 'recoverPassword')
                                  .and.returnValue(Observable.throw(new Response(new ResponseOptions({}))));
        let router = fixture.debugElement.injector.get(Router);
        let routerSpy = spyOn(router, 'navigateByUrl');
        component.submit();
        expect(routerSpy.calls.any()).toBeFalsy();
      });

      it('should set the "errorMessage"', () => {
        let recoveryService = fixture.debugElement.injector.get(IdentityRecoveryService);
        let recoveryServiceSpy = spyOn(recoveryService, 'recoverPassword')
                                  .and.returnValue(Observable.throw(new Response(new ResponseOptions({}))));
        component.submit();
        expect(component.errorMessage).toBeTruthy();
      });
    });
  });
});

class MockIdentityRecoveryService extends IdentityRecoveryService {
    constructor() {
        super(null);
    }
}

class MockRouter {
  public navigateByUrl(url: string) { }
}

class MockError {
  public getErrorMessage(data: any): string {
    return 'some error';
  }
}

class MockConfigService {
  public get(key: string) { }
}
