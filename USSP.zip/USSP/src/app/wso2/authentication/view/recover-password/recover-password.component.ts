import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IdentityRecoveryService } from '../../service/identity-recovery.service';
import { RouteConstants } from '../../../../global/route-constants';
import { SessionStorageConstants } from '../../../../global/session-storage.constants';
import { ErrorExtractorService } from '../../../../global/error-extractor.service';
import { ConfigService } from '../../../../global/config.service';
import { ConfigKeys } from '../../../../global/config-keys.constants';

@Component({
  selector: 'app-recover-password',
  templateUrl: './recover-password.component.html',
  styleUrls: ['./recover-password.component.css']
})
export class RecoverPasswordComponent implements OnInit {

    public accountEmail: string;
    errorMessage: string;
    emailRegex: string;
    emailMaxLength: string;

    constructor(private identityRecoveryService: IdentityRecoveryService,
                private router: Router,
                private errorService: ErrorExtractorService,
                private config: ConfigService) { }

    ngOnInit() {
        this.hideMessage();
        this.emailRegex = this.config.get(ConfigKeys.email.regex);
        this.emailMaxLength = this.config.get(ConfigKeys.email.maxLength);
    }

    hideMessage() {
        this.errorMessage = '';
    }

    submit() {
        this.identityRecoveryService.recoverPassword(this.accountEmail)
            .subscribe(
                () =>  this.notificationSent(),
                error => this.handleError(error)
            );
    }

    notificationSent() {
        sessionStorage.setItem(SessionStorageConstants.passwordResetEmail, this.accountEmail);
        this.router.navigateByUrl('/' + RouteConstants.recoverPasswordConfirmation.path);
    }

    private handleError(error) {
        this.errorMessage = this.errorService.getErrorMessage(error);
    }
}
