import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { IdentityRecoveryService } from '../../service/identity-recovery.service';
import { ErrorExtractorService } from '../../../../global/error-extractor.service';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css']
})
export class ResetPasswordComponent implements OnInit, OnDestroy {

  @ViewChild('changePasswordForm') changePasswordForm;

  token: string;
  savePassword: Subscription;
  errorMessage = '';

  constructor(public activatedRoute: ActivatedRoute,
              private identityRecoveryService: IdentityRecoveryService,
              private router: Router,
              private errorService: ErrorExtractorService) {
  }

  ngOnInit() {
    this.token = this.activatedRoute.snapshot.queryParamMap.get('confirmation');
   }

  ngOnDestroy() {
    if (this.savePassword) {
        this.savePassword.unsubscribe();
    }
  }

  hideMessages() {
    this.errorMessage = '';
  }

  save() {
    let password = this.changePasswordForm.value.newPassword;
    this.savePassword = this.identityRecoveryService.resetPassword(this.token, password)
      .subscribe(
        () =>  this.passwordUpdated(),
        error => this.handleError(error)
      );
  }

  private passwordUpdated() {
    this.router.navigateByUrl('/home');
  }

  protected handleError(error) {
    this.errorMessage = this.errorService.getErrorMessage(error);
  }
}
