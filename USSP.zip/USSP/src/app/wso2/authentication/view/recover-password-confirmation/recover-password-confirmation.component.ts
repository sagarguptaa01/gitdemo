import { Component } from '@angular/core';
import { AccountRegistrationConstants } from '../../../registration/account-registration.constants';
import { SessionStorageConstants } from '../../../../global/session-storage.constants';

@Component({
  selector: 'app-recover-password-confirmation',
  templateUrl: './recover-password-confirmation.component.html',
  styleUrls: ['./recover-password-confirmation.component.css']
})
export class RecoverPasswordConfirmationComponent {

    email: string;
    contactUsLink: string;

    constructor() { }

    ngOnInit() {
      this.email = sessionStorage.getItem(SessionStorageConstants.passwordResetEmail);
      this.contactUsLink = AccountRegistrationConstants.ExfoLinks.ContactUs;
    }
}