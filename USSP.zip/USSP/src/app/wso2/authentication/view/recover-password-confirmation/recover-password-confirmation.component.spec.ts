import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RecoverPasswordConfirmationComponent } from './recover-password-confirmation.component';

describe('AccountRegistrationConfirmationComponent', () => {
  let component: RecoverPasswordConfirmationComponent;
  let fixture: ComponentFixture<RecoverPasswordConfirmationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RecoverPasswordConfirmationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RecoverPasswordConfirmationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});