export const AccountRegistrationConstants = {
    ExfoLinks: {
        ContactUs: 'https://www.exfo.com/en/contact/'
    }
}
