export enum EmailValidationState {
  emailNotVerified,
  emailVerifiedandValid,
  emailVerifiedandInvalid
}
