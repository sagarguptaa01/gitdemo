import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule, NgControl, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Rx';
import { Response, ResponseOptions } from '@angular/http';
import { AccountRegistrationComponent } from './account-registration.component';
import { AccountRegistrationService } from '../service/account-registration.service';
import { CountryService } from '../../../global/country.service';
import { CountryDto } from '../../../global/dto/country.dto';
import { ConfigService } from '../../../global/config.service';
import { ConfigKeys } from '../../../global/config-keys.constants';
import { ErrorExtractorService } from '../../../global/error-extractor.service';
import { Component } from '@angular/core';
import { EmailValidationService } from '../service/email-validation-service';
import { BackendApiConstants } from '../../../global/backend-api.constants';
import { EmailValidationState } from './email-validation.state';

@Component({
  selector: 'app-account-registration',
  template: '',
})
class TestableAccountRegistrationComponent extends AccountRegistrationComponent {
  constructor(accountRegistrationService: AccountRegistrationService,
    countryService: CountryService,
    router: Router,
    config: ConfigService,
    errorService: ErrorExtractorService,
    emailValidationService: EmailValidationService) {
    super(accountRegistrationService, countryService, router, config, errorService, emailValidationService);
  }
}

describe('AccountRegistrationComponent', () => {
  let component: TestableAccountRegistrationComponent;
  let fixture: ComponentFixture<TestableAccountRegistrationComponent>;
  let AccountRegistrationServiceMock:AccountRegistrationService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [TestableAccountRegistrationComponent],
      imports: [
        FormsModule,
        ReactiveFormsModule
      ],
      providers: [
        { provide: AccountRegistrationService, useClass: MockAccountRegistrationService },
        { provide: CountryService, useClass: MockCountryService },
        { provide: Router, useClass: MockRouter },
        { provide: ConfigService, useClass: MockConfig },
        { provide: ErrorExtractorService, useClass: MockError },
        { provide: EmailValidationService, useClass: MockEmailValidationService }
      ]
    });
  }));

  beforeEach(() => {
    AccountRegistrationServiceMock = new AccountRegistrationService(null);
    fixture = TestBed.createComponent(TestableAccountRegistrationComponent);
    component = fixture.componentInstance;
    component.model.country="";
    component.model.firstName = "";
    component.model.lastName = "";
    component.model.company = "";
    component.model.email = "";
  });

  it('should be created', () => {
    fixture.detectChanges();

    expect(component).toBeTruthy();
  });

  it('should set the "errorMessage" flag to "false"', () => {
    fixture.detectChanges();
    expect(component.errorMessage).toBeFalsy();
  });

  it('should set the "inProgress" flag to "false"', () => {
    fixture.detectChanges();
    expect(component.inProgress).toBeFalsy();
  });

  it('should get the software license agreement link from the Config', () => {
    let expectedSoftwareLicenseAgreementLink = 'LicenseAgreementLink';
    let configService = fixture.debugElement.injector.get(ConfigService);
    spyOn(configService, 'get').and.callFake(configKey => {
      if (configKey === ConfigKeys.softwareLicenseAgreement) {
        return expectedSoftwareLicenseAgreementLink;
      }
    });
    fixture.detectChanges();
    expect(component.softwareLicenseAgreementLink).toEqual(expectedSoftwareLicenseAgreementLink);
  });

  it('should get the user privacy notice link from the Config', () => {

    let expectedUserPrivacyLink = 'UserPrivacyLink';
    let configService = fixture.debugElement.injector.get(ConfigService);
    spyOn(configService, 'get').and.callFake(configKey => {
      if (configKey === ConfigKeys.userPrivacyNotice) {
        return expectedUserPrivacyLink;
      }
    });
    fixture.detectChanges();
    expect(component.userPrivacyNoticeLink).toEqual(expectedUserPrivacyLink);
  });

  it('should call CountryService to get the country list the first countries provided by Config', () => {
    let firstCountriesCodes = ['US', 'CA'];
    let configService = fixture.debugElement.injector.get(ConfigService);
    let configServiceSpy = spyOn(configService, 'get').and.callFake(configKey => {
      if (configKey === ConfigKeys.firstCountries) {
        return firstCountriesCodes;
      }
    });
    let countryService = fixture.debugElement.injector.get(CountryService);
    let countryServiceSpy = spyOn(countryService, 'getCountryList').and.returnValue(Observable.of(null));

    fixture.detectChanges();

    expect(countryServiceSpy).toHaveBeenCalledWith(['US', 'CA']);
  });

  it('should get the organization name regex from the Config', () => {
    let configService = fixture.debugElement.injector.get(ConfigService);
    let orgNameRegex = 'org-name-regex-thing';
    spyOn(configService, 'get').and.callFake(configKey => {
      if (configKey === ConfigKeys.orgName.regex) {
        return orgNameRegex;
      }
    });

    fixture.detectChanges();

    expect(component.orgNameRegex).toEqual(orgNameRegex);
  });

  describe('organization name field', () => {

    it("should not call the server when the field is empty", () => {
      let accountRegistrationService = fixture.debugElement.injector.get(AccountRegistrationService);
      let accountRegistrationSpy = spyOn(accountRegistrationService, 'organizationAccountExist').and.returnValue(Observable.of(false));

      component.validateOrganizationName(null);
      expect(accountRegistrationSpy).not.toHaveBeenCalled();
    });

    it("should call the server when the field is not empty", () => {
      let accountRegistrationService = fixture.debugElement.injector.get(AccountRegistrationService);
      let accountRegistrationSpy = spyOn(accountRegistrationService, 'organizationAccountExist').and.returnValue(Observable.of(new Response(new ResponseOptions({ body: false }))));

      component.model.company = "not empty";
      component.validateOrganizationName(null);
      expect(accountRegistrationSpy).toHaveBeenCalledTimes(1);
    });

    it("should set the control in error when the value already exist", () => {
      let accountRegistrationService = fixture.debugElement.injector.get(AccountRegistrationService);
      let accountRegistrationSpy = spyOn(accountRegistrationService, 'organizationAccountExist').and.returnValue(Observable.of(new Response(new ResponseOptions({ body: true }))));

      let control = new MockControl();
      component.model.company = "not empty";

      component.validateOrganizationName(control);
      expect(control.control.hasError("alreadyExist")).toBeTruthy();
    });

    it("should set no error in the control the value does not exist", () => {
      let accountRegistrationService = fixture.debugElement.injector.get(AccountRegistrationService);
      let accountRegistrationSpy = spyOn(accountRegistrationService, 'organizationAccountExist').and.returnValue(Observable.of(new Response(new ResponseOptions({ body: false }))));

      let control = new MockControl();
      component.model.company = "not empty";

      component.validateOrganizationName(control);
      expect(control.control.valid).toBeTruthy();
    });

    it("should set the server error to the control when an unexpected error happens", () => {
      let error = "Some error";
      let accountRegistrationService = fixture.debugElement.injector.get(AccountRegistrationService);
      let accountRegistrationSpy = spyOn(accountRegistrationService, 'organizationAccountExist').and.returnValue(Observable.throw(new Response(new ResponseOptions({ body: error }))));
      let errorExtractor = fixture.debugElement.injector.get(ErrorExtractorService);
      spyOn(errorExtractor, 'getErrorMessage').and.returnValue(error);
      let control = new MockControl();
      component.model.company = "not empty";

      component.validateOrganizationName(control);
      expect(control.control.getError("serverError")).toContain(error);
    });
  });

  describe('onSubmit', () => {

    it('should use AccountRegistrationService to create an account', () => {
      let accountRegistrationService = fixture.debugElement.injector.get(AccountRegistrationService);
      let accountRegistrationSpy = spyOn(accountRegistrationService, 'createOrganizationAccount').and.returnValue(Observable.of(null));

      component.onSubmit();

      expect(accountRegistrationSpy).toHaveBeenCalledWith(component.model.firstName, component.model.lastName, component.model.company, component.model.country, component.model.email, component.emailEncryptionKey, component.acceptPrivacyPolicy, component.acceptLicenseAgreement);
    });

    it('should leave the "inProgress" flag to "true" after a successful call to AccountRegistrationService', () => {
      let accountRegistrationService = fixture.debugElement.injector.get(AccountRegistrationService);
      let accountRegistrationSpy = spyOn(accountRegistrationService, 'createOrganizationAccount').and.returnValue(Observable.of(null));

      let router = fixture.debugElement.injector.get(Router);
      spyOn(router, 'navigateByUrl');

      component.onSubmit();

      expect(component.inProgress).toBeTruthy();
    });

    it('should navigate to the account-registration-confirmation page after a successful call to AccountRegistrationService', () => {
      let accountRegistrationService = fixture.debugElement.injector.get(AccountRegistrationService);
      let accountRegistrationSpy = spyOn(accountRegistrationService, 'createOrganizationAccount').and.returnValue(Observable.of(null));

      let router = fixture.debugElement.injector.get(Router);
      let routerSpy = spyOn(router, 'navigateByUrl');

      component.onSubmit();

      expect(routerSpy).toHaveBeenCalledWith('/account-registration-confirmation');
    });

    describe('when the call to AccountRegistrationService returns an error', () => {

      it('should not navigate to another page', () => {
        let accountRegistrationService = fixture.debugElement.injector.get(AccountRegistrationService);
        let accountRegistrationSpy = spyOn(accountRegistrationService, 'createOrganizationAccount').and.returnValue(Observable.throw(new Response(new ResponseOptions({}))));

        let router = fixture.debugElement.injector.get(Router);
        let routerSpy = spyOn(router, 'navigateByUrl');

        component.onSubmit();

        expect(routerSpy.calls.any()).toBeFalsy();
      });

      it('should set the "errorMessage"', () => {
        let accountRegistrationService = fixture.debugElement.injector.get(AccountRegistrationService);
        let accountRegistrationSpy = spyOn(accountRegistrationService, 'createOrganizationAccount').and.returnValue(Observable.throw(new Response(new ResponseOptions({}))));

        component.onSubmit();

        expect(component.errorMessage).toBeTruthy();
      });
    });

    [{modelElement: 'firstName',    createOrganizationAccountDtoElement: 'firstName',   value: ' firstName ',    expectedResult: 'firstName' },
    { modelElement: 'lastName',     createOrganizationAccountDtoElement: 'lastName',    value: ' address ',      expectedResult: 'address' },
    { modelElement: 'workPhone',    createOrganizationAccountDtoElement: 'workPhone',   value: ' 9999999999 ',   expectedResult: '9999999999' },
    { modelElement: 'mobilePhone',  createOrganizationAccountDtoElement: 'mobilePhone', value: ' 9999999999 ',   expectedResult: '9999999999' },
    { modelElement: 'company',      createOrganizationAccountDtoElement: 'organization',value: ' company ',      expectedResult: 'company' }
    ].forEach(function (run) {
      it('should trim when "' + run.modelElement + '" have extra spaces', function () {
        // Arrange & Define Assert
        component.model[run.modelElement] = run.value;
        spyOn(AccountRegistrationServiceMock, 'createOrganizationAccount').and.callFake(data => {
          expect(data[run.createOrganizationAccountDtoElement]).toBe(run.expectedResult);
          return new Observable<any>(observer => observer.next(new Response(new ResponseOptions())));
        });

        // Act
        component.onSubmit();
      });
    });

    [{modelElement: 'firstName',    createOrganizationAccountDtoElement: 'firstName',   value: undefined,   expectedResult: undefined },
    { modelElement: 'lastName',     createOrganizationAccountDtoElement: 'lastName',    value: null,        expectedResult: null },
    { modelElement: 'workPhone ',   createOrganizationAccountDtoElement: 'workPhone',   value: undefined,   expectedResult: undefined },
    { modelElement: 'mobilePhone',  createOrganizationAccountDtoElement: 'mobilePhone', value: '',          expectedResult: '' },
    { modelElement: 'company',      createOrganizationAccountDtoElement: 'organization',value: ' company ', expectedResult: 'company' }
    ].forEach(function (run) {
      it('should not trim when "' + run.modelElement + '" is NULL or UNDEFINED', function () {
        // Arrange & Define Assert
        component.model[run.modelElement] = run.value;
        spyOn(AccountRegistrationServiceMock, 'createOrganizationAccount').and.callFake(data => {
          expect(data[run.createOrganizationAccountDtoElement]).toBe(run.expectedResult);
          return new Observable<any>(observer => observer.next(new Response(new ResponseOptions())));
        });

        // Act
        component.onSubmit();
      });
    });

  });

  describe('emailIsValid', () => {
    it('should return false If Entered Email is not matching with Regex', () => {
      // Arrange
      let expected = false;
      spyOn(component, 'emailRegexMatching').and.returnValue(false);

      // Act
      let result = component.emailIsValid();

      // Assert
      expect(result).toBe(expected);
    });

    it('should return true If Entered Email is Verified and Valid', () => {
      // Arrange
      let expected = true;
      spyOn(component, 'emailRegexMatching').and.returnValue(true);
      component.emailValidiationState = EmailValidationState.emailVerifiedandValid;
      component.model.email = 'TestEmail';
      component.lastVerifiedEmail = component.model.email;

      // Act
      let result = component.emailIsValid();

      // Assert
      expect(result).toBe(expected);
    });

    it('should return false If Entered Email is Verified and Invalid', () => {
      // Arrange
      let expected = false;
      spyOn(component, 'emailRegexMatching').and.returnValue(true);
      component.emailValidiationState = EmailValidationState.emailVerifiedandInvalid;
      component.model.email = 'TestEmail';
      component.lastVerifiedEmail = component.model.email;

      // Act
      let result = component.emailIsValid();

      // Assert
      expect(result).toBe(expected);
    });

    it('should return false If Entered Email is Not Verified', () => {
      // Arrange
      let expected = false;
      spyOn(component, 'emailRegexMatching').and.returnValue(true);
      component.emailValidiationState = EmailValidationState.emailNotVerified;
      component.model.email = 'TestEmail';
      component.lastVerifiedEmail = component.model.email;

      // Act
      let result = component.emailIsValid();

      // Assert
      expect(result).toBe(expected);
    });

    it('should return false If Last Verified Email is not same as current Entered Email', () => {
      // Arrange
      let expected = false;
      spyOn(component, 'emailRegexMatching').and.returnValue(true);
      component.emailValidiationState = EmailValidationState.emailVerifiedandValid;
      component.model.email = 'CurrentTestEmail';
      component.lastVerifiedEmail = 'LastVerifiedTestEmail';

      // Act
      let result = component.emailIsValid();

      // Assert
      expect(result).toBe(expected);
    });

    it('should return false If Entered Email is blank', () => {
      // Arrange
      let expected = false;
      spyOn(component, 'emailRegexMatching').and.returnValue(true);
      component.emailValidiationState = EmailValidationState.emailVerifiedandInvalid;

      // Act
      let result = component.emailIsValid();

      // Assert
      expect(result).toBe(expected);
    });
  });

  describe('emailIsInvalid', () => {
    it('should set Default Email Error If Entered Email is not matching with Regex', () => {
      // Arrange
      let expected = 'Error: Invalid e-mail address';
      spyOn(component, 'emailRegexMatching').and.returnValue(false);

      // Act
      component.emailIsInvalid();

      // Assert
      expect(component.emailValidationError).toBe(expected);
    });

    it('should return true If Entered Email is not matching with Regex', () => {
      // Arrange
      let expected = true;
      spyOn(component, 'emailRegexMatching').and.returnValue(false);

      // Act
      let result = component.emailIsInvalid();

      // Assert
      expect(result).toBe(expected);
    });

    it('should return true If Entered Email is Verified and Invalid', () => {
      // Arrange
      let expected = true;
      spyOn(component, 'emailRegexMatching').and.returnValue(true);
      component.emailValidiationState = EmailValidationState.emailVerifiedandInvalid;
      component.model.email = 'TestEmail';
      component.lastVerifiedEmail = component.model.email;

      // Act
      let result = component.emailIsInvalid();

      // Assert
      expect(result).toBe(expected);
    });

    it('should set emailValidationError to lastVerfiedEmailError If Entered Email is Verified and Invalid', () => {
      // Arrange
      let expected = component.lastVerfiedEmailError;
      spyOn(component, 'emailRegexMatching').and.returnValue(true);
      component.emailValidiationState = EmailValidationState.emailVerifiedandInvalid;
      component.model.email = 'TestEmail';
      component.lastVerifiedEmail = component.model.email;

      // Act
      component.emailIsInvalid();

      // Assert
      expect(component.emailValidationError).toBe(expected);
    });

    it('should return false If Entered Email is Verified and Valid', () => {
      // Arrange
      let expected = false;
      spyOn(component, 'emailRegexMatching').and.returnValue(true);
      component.emailValidiationState = EmailValidationState.emailVerifiedandValid;
      component.model.email = 'TestEmail';
      component.lastVerifiedEmail = component.model.email;

      // Act
      let result = component.emailIsInvalid();

      // Assert
      expect(result).toBe(expected);
    });

    it('should return false If Entered Email is Not Verified', () => {
      // Arrange
      let expected = false;
      spyOn(component, 'emailRegexMatching').and.returnValue(true);
      component.emailValidiationState = EmailValidationState.emailNotVerified;
      component.model.email = 'TestEmail';
      component.lastVerifiedEmail = component.model.email;

      // Act
      let result = component.emailIsInvalid();

      // Assert
      expect(result).toBe(expected);
    });

    it('should return false If Last Verified Email is not same as current Entered Email', () => {
      // Arrange
      let expected = false;
      spyOn(component, 'emailRegexMatching').and.returnValue(true);
      component.emailValidiationState = EmailValidationState.emailVerifiedandInvalid;
      component.model.email = 'CurrentTestEmail';
      component.lastVerifiedEmail = 'LastVerifiedTestEmail';

      // Act
      let result = component.emailIsInvalid();

      // Assert
      expect(result).toBe(expected);
    });

    it('should return false If Entered Email is blank', () => {
      // Arrange
      let expected = true;
      spyOn(component, 'emailRegexMatching').and.returnValue(true);
      component.emailValidiationState = EmailValidationState.emailVerifiedandInvalid;

      // Act
      let result = component.emailIsInvalid();

      // Assert
      expect(result).toBe(expected);
    });

    it('should set Default Email Error If Entered Email is blank', () => {
      // Arrange
      let expected = 'Error: Invalid e-mail address';
      spyOn(component, 'emailRegexMatching').and.returnValue(true);
      component.emailValidiationState = EmailValidationState.emailVerifiedandInvalid;

      // Act
      component.emailIsInvalid();

      // Assert
      expect(component.emailValidationError).toBe(expected);
    });
  });

  describe('emailValidationUnderprogress', () => {
    it('should return true If Email Validation is Under progress', () => {
      // Arrange
      let expected = true;
      component.emailValidationInprogress = true;

      // Act
      let result = component.emailValidationUnderprogress();

      // Assert
      expect(result).toBe(expected);
    });

    it('should return false If Email Validation is already done', () => {
      // Arrange
      let expected = false;
      component.emailValidationInprogress = false;

      // Act
      let result = component.emailValidationUnderprogress();

      // Assert
      expect(result).toBe(expected);
    });
  });

  describe('focusOutonEmailField', () => {
    it('should return if Email is not as per Regex defined', () => {
      // Arrange
      let expected = undefined;
      let regExSpy = spyOn(component, 'emailRegexMatching').and.returnValue(false);

      // Act
      let result = component.focusOutonEmailField();

      // Assert
      expect(result).toBe(expected);
    });

    it('should return if Last verified Email and Entered email are same', () => {
      // Arrange
      let expected = undefined;
      let regExSpy = spyOn(component, 'emailRegexMatching').and.returnValue(true);
      component.lastVerifiedEmail = 'E-Mail';
      component.model.email = 'E-Mail';

      // Act
      let result = component.focusOutonEmailField();

      // Assert
      expect(result).toBe(expected);
    });

    it('should return if Email is null', () => {
      // Arrange
      let expected = undefined;
      component.model.email = '';

      // Act
      let result = component.focusOutonEmailField();

      // Assert
      expect(result).toBe(expected);
    });

    it('should use Email Validation service to validate email', () => {
      // Arrange
      component.model.email = 'Email-Test';
      component.lastVerifiedEmail = 'Previous-E-Mail';
      let regExSpy = spyOn(component, 'emailRegexMatching').and.returnValue(true);
      let emailValService = fixture.debugElement.injector.get(EmailValidationService);
      let emailValidationSerSpy = spyOn(emailValService, 'validateEmailAddress').and.
        returnValue(Observable.of(new Response(new ResponseOptions({ body: { 'EmailValidationResponse': 'Correct' } }))));

      // Act
      component.focusOutonEmailField();

      // Assert
      expect(emailValidationSerSpy).toHaveBeenCalledWith(component.model.email);
    });

    it('should set emailValidationInprogress flag to true when Email Validaiton is ongoing', () => {
      // Arrange
      let expected = true;
      component.model.email = 'Email-Test';
      component.lastVerifiedEmail = 'Previous-E-Mail';
      let regExSpy = spyOn(component, 'emailRegexMatching').and.returnValue(true);
      let emailValService = fixture.debugElement.injector.get(EmailValidationService);

      // Act
      component.focusOutonEmailField();

      // Assert
      expect(component.emailValidationInprogress).toBe(expected);
    });

    it('should set emailValidationInprogress flag to false when Email Validation is done', () => {
      // Arrange
      let expected = false;
      component.model.email = 'Email-Test';
      component.lastVerifiedEmail = 'Previous-E-Mail';
      let regExSpy = spyOn(component, 'emailRegexMatching').and.returnValue(true);
      let emailValService = fixture.debugElement.injector.get(EmailValidationService);
      let emailValidationSerSpy = spyOn(emailValService, 'validateEmailAddress').and.
        returnValue(Observable.of(new Response(new ResponseOptions({ body: { 'EmailValidationResponse': 'SUCCESS' } }))));

      // Act
      component.focusOutonEmailField();

      // Assert
      expect(component.emailValidationInprogress).toBe(expected);
    });

    it('should set EmailValidationState to emailNotVerified when Email Validaiton is ongoing', () => {
      // Arrange
      component.model.email = 'Email-Test';
      component.lastVerifiedEmail = 'Previous-E-Mail';
      let regExSpy = spyOn(component, 'emailRegexMatching').and.returnValue(true);
      let emailValService = fixture.debugElement.injector.get(EmailValidationService);

      // Act
      component.focusOutonEmailField();

      // Assert
      expect(component.emailValidiationState).toBe(EmailValidationState.emailNotVerified);
    });

    it('should set EmailValidationState to emailVerifiedandValid when Validation response is SUCCESS', () => {
      // Arrange
      component.model.email = 'Email-Test';
      component.lastVerifiedEmail = 'Previous-E-Mail';
      let regExSpy = spyOn(component, 'emailRegexMatching').and.returnValue(true);
      let emailValService = fixture.debugElement.injector.get(EmailValidationService);
      let mockResponse = {
        status: BackendApiConstants.services.tenant.validateEmail.validationStatus.Success
      };
      let emailValidationSerSpy = spyOn(emailValService, 'validateEmailAddress').and.
        returnValue(Observable.of(new Response(new ResponseOptions({ body: JSON.stringify(mockResponse) }))));

      // Act
      component.focusOutonEmailField();

      // Assert
      expect(component.emailValidiationState).toBe(EmailValidationState.emailVerifiedandValid);
    });

    it('should set EmailValidationState to emailVerifiedandValid when Validation response is SKIPPED', () => {
      // Arrange
      component.model.email = 'Email-Test';
      component.lastVerifiedEmail = 'Previous-E-Mail';
      let regExSpy = spyOn(component, 'emailRegexMatching').and.returnValue(true);
      let emailValService = fixture.debugElement.injector.get(EmailValidationService);
      let mockResponse = {
        status: BackendApiConstants.services.tenant.validateEmail.validationStatus.Skipped
      };
      let emailValidationSerSpy = spyOn(emailValService, 'validateEmailAddress').and.
        returnValue(Observable.of(new Response(new ResponseOptions({ body: JSON.stringify(mockResponse) }))));

      // Act
      component.focusOutonEmailField();

      // Assert
      expect(component.emailValidiationState).toBe(EmailValidationState.emailVerifiedandValid);
    });

    it('should set EmailValidationState to emailVerifiedandInvalid when Validation response is FAIL', () => {
      // Arrange
      component.model.email = 'Email-Test';
      component.lastVerifiedEmail = 'Previous-E-Mail';
      let regExSpy = spyOn(component, 'emailRegexMatching').and.returnValue(true);
      let emailValService = fixture.debugElement.injector.get(EmailValidationService);
      let mockResponse = {
        status: BackendApiConstants.services.tenant.validateEmail.validationStatus.Failed
      };
      let emailValidationSerSpy = spyOn(emailValService, 'validateEmailAddress').and.
        returnValue(Observable.of(new Response(new ResponseOptions({ body: JSON.stringify(mockResponse) }))));

      // Act
      component.focusOutonEmailField();

      // Assert
      expect(component.emailValidiationState).toBe(EmailValidationState.emailVerifiedandInvalid);
    });

    it('should set proper error message when Validation response is FAIL & reason is MailboxFull', () => {
      // Arrange
      let expected = 'Error: Recipient mailbox is full. Please try again later.';
      component.model.email = 'Email-Test';
      component.lastVerifiedEmail = 'Previous-E-Mail';
      let regExSpy = spyOn(component, 'emailRegexMatching').and.returnValue(true);
      let emailValService = fixture.debugElement.injector.get(EmailValidationService);
      let mockResponse = {
        status: BackendApiConstants.services.tenant.validateEmail.validationStatus.Failed,
        reason: BackendApiConstants.services.tenant.validateEmail.validationFailedReason.MailBoxFull
      };
      let emailValidationSerSpy = spyOn(emailValService, 'validateEmailAddress').and.
        returnValue(Observable.of(new Response(new ResponseOptions({ body: JSON.stringify(mockResponse) }))));

      // Act
      component.focusOutonEmailField();

      // Assert
      expect(component.emailValidationError).toBe(expected);
      expect(component.lastVerfiedEmailError).toBe(expected);
    });

    it('should set proper error message when Validation response is FAIL & reason is TransientNetworkFault', () => {
      // Arrange
      let expected = 'Error: A temporary network fault occurred during e-mail validation. Please try again later.';
      component.model.email = 'Email-Test';
      component.lastVerifiedEmail = 'Previous-E-Mail';
      let regExSpy = spyOn(component, 'emailRegexMatching').and.returnValue(true);
      let emailValService = fixture.debugElement.injector.get(EmailValidationService);
      let mockResponse = {
        status: BackendApiConstants.services.tenant.validateEmail.validationStatus.Failed,
        reason: BackendApiConstants.services.tenant.validateEmail.validationFailedReason.TransientNetworkFault
      };
      let emailValidationSerSpy = spyOn(emailValService, 'validateEmailAddress').and.
        returnValue(Observable.of(new Response(new ResponseOptions({ body: JSON.stringify(mockResponse) }))));

      // Act
      component.focusOutonEmailField();

      // Assert
      expect(component.emailValidationError).toBe(expected);
      expect(component.lastVerfiedEmailError).toBe(expected);
    });

    it('should set proper error message when Validation response is FAIL & reason is UnverifiableEmail', () => {
      // Arrange
      let expected = 'Error: Invalid e-mail address';
      component.model.email = 'Email-Test';
      component.lastVerifiedEmail = 'Previous-E-Mail';
      let regExSpy = spyOn(component, 'emailRegexMatching').and.returnValue(true);
      let emailValService = fixture.debugElement.injector.get(EmailValidationService);
      let mockResponse = {
        status: BackendApiConstants.services.tenant.validateEmail.validationStatus.Failed,
        reason: BackendApiConstants.services.tenant.validateEmail.validationFailedReason.UnverifiableEmail
      };
      let emailValidationSerSpy = spyOn(emailValService, 'validateEmailAddress').and.
        returnValue(Observable.of(new Response(new ResponseOptions({ body: JSON.stringify(mockResponse) }))));

      // Act
      component.focusOutonEmailField();

      // Assert
      expect(component.emailValidationError).toBe(expected);
      expect(component.lastVerfiedEmailError).toBe(expected);
    });

    it('should set EmailValidationState to emailVerifiedandInvalid when Error is returned', () => {
      // Arrange
      let expected = false;
      let expectedEmailError = 'Error: Invalid e-mail address';
      component.model.email = 'Email-Test';
      component.lastVerifiedEmail = 'Previous-E-Mail';
      let regExSpy = spyOn(component, 'emailRegexMatching').and.returnValue(true);
      let emailValService = fixture.debugElement.injector.get(EmailValidationService);
      let emailValidationSerSpy = spyOn(emailValService, 'validateEmailAddress').and.
        returnValue(Observable.throw('error'));

      // Act
      component.focusOutonEmailField();

      // Assert
      expect(component.emailValidiationState).toBe(EmailValidationState.emailVerifiedandInvalid);
      expect(component.emailValidationInprogress).toBe(expected);
      expect(component.emailValidationError).toBe(expectedEmailError);
      expect(component.emailValidationError).toBe(component.lastVerfiedEmailError);
    });
  });

});

class MockAccountRegistrationService {
  public createOrganizationAccount(firstName: string, lastName: string, company: string, country: string, email: string): Observable<any> {
    return Observable.of();
  }

  public organizationAccountExist(organization: string): Observable<any> {
    return Observable.of();
  }
}

class MockCountryService {
  public getCountryList(firstCountriesCodes: string[]): Observable<CountryDto[]> {
    return Observable.of(null);
  }
}

class MockRouter {
  public navigateByUrl(url: string) { }
}

class MockConfig {
  public get(key: string) { }
}

class MockControl extends NgControl {
  viewToModelUpdate(newValue: any): void { }
  readonly control = new FormControl("Mock Control");
}

class MockError {
  public getErrorMessage(data: any): string {
    return "some error";
  }
}

class MockEmailValidationService {
  validateEmailAddress(emailAddress: string): Observable<any> {
    return Observable.of();
  }
}