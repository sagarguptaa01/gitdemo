import { Component, OnInit, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgControl } from '@angular/forms';

import { AccountRegistrationService } from '../service/account-registration.service';
import { AccountRegistrationModel } from './account-registration.model';
import { CountryDto } from '../../../global/dto/country.dto';
import { CountryService } from '../../../global/country.service';
import { ErrorExtractorService } from '../../../global/error-extractor.service';
import { ConfigService } from '../../../global/config.service';
import { ConfigKeys } from '../../../global/config-keys.constants';
import { SessionStorageConstants } from '../../../global/session-storage.constants';
import { RouteConstants } from '../../../global/route-constants';
import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { EmailValidationService } from '../service/email-validation-service';
import { ResponseOptions } from '@angular/http';
import { BackendApiConstants } from '../../../global/backend-api.constants';
import { EmailValidationState } from './email-validation.state';
import { Utils } from '../../../global/utils';
import { CreateTenantRequestDto } from '../service/dto/create-tenant-request.dto';
import { UserProfileDto } from '../../../ussp/user-profile/service/dto/user-profile.dto';

declare var jquery:any;
declare var $ :any;

@Component({
  selector: 'app-account-registration',
  templateUrl: './account-registration.component.html',
  styleUrls: ['./account-registration.component.css']
})
export class AccountRegistrationComponent implements OnInit,AfterViewInit {
  @BlockUI('create-account-content') blockUI: NgBlockUI;
  model = new AccountRegistrationModel();

  countries: CountryDto[];

  userPrivacyNoticeLink: string;
  softwareLicenseAgreementLink: string;
  errorMessage: string;
  inProgress: boolean;

  firstNameRegex: string;
  lastNameRegex: string;
  orgNameRegex: string;
  emailRegex: string;
  phoneRegex: string;

  firstNameMaxLength: string;
  lastNameMaxLength: string;
  orgNameMaxLength: string;
  emailMaxLength: string;
  phoneMaxLength: string;

  emailValidationInprogress: boolean;
  emailValidiationState: EmailValidationState;
  lastVerifiedEmail: string;
  emailEncryptionKey: string;
  emailRegexObj: RegExp;
  emailValidationError: string;
  lastVerfiedEmailError: string;
  agreeTo: boolean;
  agreeToExfoCommunication: boolean;
  acceptPrivacyPolicy: boolean;
  acceptLicenseAgreement: boolean;
  acceptExfoCommunication: boolean;

  passwordMaxLength: string;
  passwordMinLength: string;
  passwordRegex: string;
  
  password: string;
  

  constructor(private accountRegistrationService: AccountRegistrationService,
    private countryService: CountryService,
    private router: Router,
    private config: ConfigService,
    private errorService: ErrorExtractorService,
    private emailValidationService: EmailValidationService) { }

  public ngOnInit() {
    this.softwareLicenseAgreementLink = this.config.get(ConfigKeys.softwareLicenseAgreement);
    this.userPrivacyNoticeLink = this.config.get(ConfigKeys.userPrivacyNotice);
    this.inProgress = false;

    this.firstNameRegex = this.config.get(ConfigKeys.firstName.regex);
    this.lastNameRegex = this.config.get(ConfigKeys.lastName.regex);
    this.orgNameRegex = this.config.get(ConfigKeys.orgName.regex);
    this.emailRegex = this.config.get(ConfigKeys.email.regex);
    this.phoneRegex = this.config.get(ConfigKeys.phoneNumber.regex);

    this.firstNameMaxLength = this.config.get(ConfigKeys.firstName.maxLength);
    this.lastNameMaxLength = this.config.get(ConfigKeys.lastName.maxLength);
    this.orgNameMaxLength = this.config.get(ConfigKeys.orgName.maxLength);
    this.emailMaxLength = this.config.get(ConfigKeys.email.maxLength);
    this.phoneMaxLength = this.config.get(ConfigKeys.phoneNumber.maxLength);

    this.emailValidationInprogress = false;
    this.emailValidiationState = EmailValidationState.emailNotVerified;
    this.emailRegexObj = new RegExp(this.emailRegex);
    this.lastVerifiedEmail = '';
    this.emailEncryptionKey = '';
    this.emailValidationError = '';
    this.lastVerfiedEmailError = '';

    this.passwordMaxLength     =     this.config.get(ConfigKeys.password.maxLength);
    this.passwordMinLength     =     this.config.get(ConfigKeys.password.minLength);
    this.passwordRegex         =     this.config.get(ConfigKeys.password.regex);
    
    this.hideServerError();
    this.getCountries();
  }

  public ngAfterViewInit(): void {
    $('.popover-dismiss').popover({
      trigger: 'focus'
      })
  }

  public onSubmit() {
    this.blockUI.start();
    this.inProgress = true;
    this.hideServerError();
    this.agreeTo = this.model.agreeToS;
    this.acceptExfoCommunication = false;
    
    if (this.agreeTo){
      this.acceptPrivacyPolicy = true;
      this.acceptLicenseAgreement = true;
    }
    
    let createTenantdto = new CreateTenantRequestDto;
    createTenantdto.country = this.model.country;
    createTenantdto.organization = Utils.trim(this.model.company);

    let adminUserDto = new UserProfileDto;
    adminUserDto.userName = Utils.trim(this.model.email);
    adminUserDto.firstName = Utils.trim(this.model.firstName);
    adminUserDto.lastName = Utils.trim(this.model.lastName);
    adminUserDto.organization = Utils.trim(this.model.company);
    adminUserDto.country = this.model.country;
    adminUserDto.acceptUserPrivacyNotice = this.acceptPrivacyPolicy;
    adminUserDto.acceptLicenseAgreement = this.acceptLicenseAgreement;
    adminUserDto.acceptReceiveExfoCommunication = this.acceptExfoCommunication;
    let properties = [
      {
        "key" : "emailKey",
        "value" : this.emailEncryptionKey
      }
    ];
    let passwordProperties = [
      {
        "key" : "credential",
        "value" : this.model.password
      }
    ];
    adminUserDto.properties = passwordProperties;
    createTenantdto.properties = properties;
    createTenantdto.adminUser = adminUserDto;
  
    this.accountRegistrationService
      .createOrganizationAccount(createTenantdto)
      .subscribe(() => this.goToAccountConfirmation(),
        error => this.handleError(error));
  }

  public onEmailHelpToggle() {
    $("#emailHelpIcon").popover("toggle");
  }
 
  public hideServerError() {
    this.errorMessage = '';
  }

  public validateOrganizationName(formControl: NgControl) {
    if (this.model.company) {
      this.accountRegistrationService
        .organizationAccountExist(this.model.company)
        .subscribe(data => this.processOrganizationNameValidationResponse(formControl, data),
          error => this.handleControlError(formControl, error));
    }
  }

  public emailIsValid(): boolean {
    if (this.model.email) {
      if (!this.emailRegexMatching()) {
        return false;
      } else if (this.emailValidiationState === EmailValidationState.emailVerifiedandValid &&
                 this.lastVerifiedEmail.toLowerCase() === this.model.email.toLowerCase()) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }

  public emailIsInvalid(): boolean {
    if (this.model.email) {
      if (!this.emailRegexMatching()) {
        this.setDefaultEmailValidationError();
        return true;
      } else if (this.emailValidiationState === EmailValidationState.emailVerifiedandInvalid && 
                 this.lastVerifiedEmail.toLowerCase() === this.model.email.toLowerCase()) {
        this.emailValidationError = this.lastVerfiedEmailError;
        return true;
      } else {
        return false;
      }
    } else {
      this.setDefaultEmailValidationError();
      return true;
    }
  }

  public emailValidationUnderprogress(): boolean {
    return this.emailValidationInprogress;
  }

  public focusOutonEmailField() {
    if (this.model.email) {
      if (!this.emailRegexMatching()) {
        return;
      }

      if (this.lastVerifiedEmail.toLowerCase() === this.model.email.toLowerCase()) {
        return;
      } else {
        this.lastVerifiedEmail = this.model.email;
      }

      this.emailValidationInprogress = true;
      this.emailValidiationState = EmailValidationState.emailNotVerified;

      this.emailValidationService.validateEmailAddress(this.model.email).subscribe(
        response => this.handleEmailValidationResponse(response),
        error => this.handleEmailValidationError(error)
      );
    }
  }

  private getCountries(): void {
    let firstCountries = this.config.get(ConfigKeys.firstCountries);
    this.countryService.getCountryList(firstCountries).subscribe(countries => this.countries = countries);
  }

  private goToAccountConfirmation() {
    this.blockUI.stop();
    sessionStorage.setItem(SessionStorageConstants.newAccountEmail, this.model.email);
    this.router.navigateByUrl('/' + RouteConstants.accountRegistrationConfirmation.path);
  }

  private handleError(error) {
    this.blockUI.stop();
    this.inProgress = false;
    this.errorMessage = this.errorService.getErrorMessage(error);
  }

  private handleControlError(formControl: NgControl, error) {
    formControl.control.setErrors({ 'serverError': this.errorService.getErrorMessage(error) });
  }

  private processOrganizationNameValidationResponse(formControl: NgControl, data: any) {
    let exist = data.json();
    if (exist) {
      formControl.control.setErrors({ 'alreadyExist': true });
    }
  }

  private handleEmailValidationResponse(response) {
    this.emailValidationInprogress = false;
    let result = response.json();

    if (result.status === BackendApiConstants.services.tenant.validateEmail.validationStatus.Success
      || result.status === BackendApiConstants.services.tenant.validateEmail.validationStatus.Skipped) {
      this.emailValidiationState = EmailValidationState.emailVerifiedandValid;
    } else {
      this.emailValidiationState = EmailValidationState.emailVerifiedandInvalid;
      this.setEmailErrorText(result.reason);
    }
    this.emailEncryptionKey = result.validationKey;
  }

  private handleEmailValidationError(error) {
    this.emailValidationInprogress = false;
    this.emailValidiationState = EmailValidationState.emailVerifiedandInvalid;
    this.emailEncryptionKey = '';
    this.setEmailErrorText(BackendApiConstants.services.tenant.validateEmail.validationFailedReason.UnverifiableEmail);
  }

  private setDefaultEmailValidationError(){
    this.emailValidationError = 'Error: Invalid e-mail address';
  }

  public emailRegexMatching(): boolean {
    return this.emailRegexObj.test(this.model.email);
  }

  public isSubmissionBlock(): boolean {
    return !this.emailIsValid() || this.inProgress;
  }

  private setEmailErrorText(reason) {
    if (reason === BackendApiConstants.services.tenant.validateEmail.validationFailedReason.MailBoxFull) {
      this.emailValidationError = 'Error: Recipient mailbox is full. Please try again later.';
    } else if (reason === BackendApiConstants.services.tenant.validateEmail.validationFailedReason.TransientNetworkFault) {
      this.emailValidationError = 'Error: A temporary network fault occurred during e-mail validation. Please try again later.';
    } else {
      this.emailValidationError = 'Error: Invalid e-mail address';
    }
    this.lastVerfiedEmailError = this.emailValidationError;
  }
}
