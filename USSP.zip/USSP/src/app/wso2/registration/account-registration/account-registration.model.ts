export class AccountRegistrationModel {
  firstName: string;
  lastName: string;
  company: string;
  country: string;
  email: string;
  password : string;
  confirmPassword : string;
  agreeToS: boolean;
  exfoCommunication: boolean;
}
