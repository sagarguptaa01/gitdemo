import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MandatoryClaimComponent } from './mandatory-claim.component';
import { ReactiveFormsModule, FormGroup, FormControl, Validators } from '@angular/forms';
import { ClaimText } from '../../model/claim-text';

describe('MandatoryClaimComponent', () => {
  let component: MandatoryClaimComponent;
  let fixture: ComponentFixture<MandatoryClaimComponent>;
  let claimName = 'claimName';

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MandatoryClaimComponent ],
      imports: [
        ReactiveFormsModule
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MandatoryClaimComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    component.model = new ClaimText(claimName);
    component.form = new FormGroup({claimName: new FormControl()});

    fixture.detectChanges();

    expect(component).toBeTruthy();
  });

  describe('isValid', () => {
    it('should return true when the associated formControl\'s value is valid', () => {
      component.model = new ClaimText(claimName);
      component.form = new FormGroup({claimName: new FormControl('', Validators.required)});
      fixture.detectChanges();
      component.form.controls[claimName].setValue('toto');

      fixture.detectChanges();

      expect(component.isValid).toBeTruthy();
    });

    it('should return false when the associated formControl\'s value is not valid', () => {
      component.model = new ClaimText(claimName);
      component.form = new FormGroup({claimName: new FormControl('', Validators.required)});
      fixture.detectChanges();
      component.form.controls[claimName].setValue('');

      fixture.detectChanges();

      expect(component.isValid).toBeFalsy();
    });
  });
});
