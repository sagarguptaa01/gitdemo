import { Injectable, Pipe, PipeTransform } from '@angular/core';
import { Claim, ClaimType } from '../../model/claim';

@Pipe({
 name: 'filterHiddenClaim'
})

@Injectable()
export class FilterHiddenClaimPipe implements PipeTransform {
 transform(claims: Claim[]): Claim[] {
  return claims.filter((claim) => claim.type !== ClaimType.hidden);
 }
}