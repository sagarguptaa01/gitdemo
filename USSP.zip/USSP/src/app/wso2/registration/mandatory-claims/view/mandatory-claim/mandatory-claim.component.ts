import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { Claim, ClaimType } from '../../model/claim';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-mandatory-claim',
  templateUrl: './mandatory-claim.component.html',
  styleUrls: ['./mandatory-claim.component.css']
})
export class MandatoryClaimComponent implements OnInit, OnDestroy {

  @Input()
  model: Claim;

  @Input()
  form: FormGroup;

  claimType = ClaimType;

  constructor() { }

  ngOnInit() {
  }

  ngOnDestroy() {
  }

  get isValid() {
    return this.form.controls[this.model.name].valid;
  }
}
