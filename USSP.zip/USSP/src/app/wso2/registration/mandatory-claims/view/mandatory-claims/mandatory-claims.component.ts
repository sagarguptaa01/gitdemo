import { Component, OnInit, OnDestroy } from '@angular/core';
import { Claim, ClaimType } from '../../model/claim';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { ClaimService } from '../../service/claim.service';
import { ClaimControlService } from '../../service/claim.control.service';
import { Subscription } from 'rxjs/Rx';
import { ActivatedRoute } from '@angular/router';
import { ClaimConstants } from '../../claim.constants';
import { ConfigService } from '../../../../../global/config.service';
import { ConfigKeys } from '../../../../../global/config-keys.constants';
import { Utils } from '../../../../../global/utils';

@Component({
  selector: 'app-mandatory-claims',
  templateUrl: './mandatory-claims.component.html',
  styleUrls: ['./mandatory-claims.component.css']
})
export class MandatoryClaimsComponent implements OnInit, OnDestroy {

  getClaimsSubscription: Subscription;
  claims: Claim[] = [];
  newClaims: Claim[] = [];
  form: FormGroup;
  userPrivacyNoticeLink: string;
  softwareLicenseAgreementLink: string;
  agreeToS = 'agreeToS';
  pageTitle: string;
  showRequiredMandatoryClaimTitle: boolean;
  showPrivacyPolicyAndTermsConditionUpdatedMessage: boolean;
  showAcceptPrivacyPolicyAndTermsConditionCheckBox: boolean;
  showMandatoryClaimFillingPage: boolean;

  public onlyUserConsentClaimPresent: boolean;
  public userConsentClaimPresent: boolean;

  constructor(private claimService: ClaimService,
    private claimControlService: ClaimControlService,
    private activatedRoute: ActivatedRoute,
    private configService: ConfigService) { }

  public ngOnInit() {
    this.showRequiredMandatoryClaimTitle = true;
    this.pageTitle = 'Provide mandatory details';
    this.showPrivacyPolicyAndTermsConditionUpdatedMessage = false;
    this.showMandatoryClaimFillingPage = true;

    this.softwareLicenseAgreementLink = this.configService.get(ConfigKeys.softwareLicenseAgreement);
    this.userPrivacyNoticeLink = this.configService.get(ConfigKeys.userPrivacyNotice);
    let claimUris = this.activatedRoute.snapshot.queryParamMap.getAll(ClaimConstants.queryKeys.claim);
    this.getClaimsSubscription = this.claimService.getClaims(claimUris).subscribe(claims => {
      this.claims = claims;
      this.form = this.claimControlService.toFormGroup(claims);

      this.setUserConsentClaimPresentFlags(claims);

       if (this.userConsentClaimPresent) {
         this.showAcceptPrivacyPolicyAndTermsConditionCheckBox = true;
         this.form.addControl(this.agreeToS, new FormControl('', Validators.requiredTrue));
        if (this.onlyUserConsentClaimPresent) {
          this.showRequiredMandatoryClaimTitle = false;
          this.showPrivacyPolicyAndTermsConditionUpdatedMessage = true;
          this.showMandatoryClaimFillingPage = false;
        }
      } else {
        this.showAcceptPrivacyPolicyAndTermsConditionCheckBox = false;
        this.showPrivacyPolicyAndTermsConditionUpdatedMessage = false;
      }
    });
  }

  public ngOnDestroy() {
    this.getClaimsSubscription.unsubscribe();
  }

  public onSubmit() {
    let sessionDataKey = this.activatedRoute.snapshot.queryParamMap.get(ClaimConstants.queryKeys.sessionDataKey);
    for (let claim of this.claims) {
      if (claim.type !== ClaimType.hidden) {
        claim.value = Utils.trim(claim.value);
      } else if ((this.claimService.claimUriMatches(claim.name, ClaimConstants.uriLicenseAgreement) ||
        this.claimService.claimUriMatches(claim.name, ClaimConstants.uriPrivacyPolicy))
        && this.agreeToS) {
        claim.value = 'true';
      }
      console.log(claim.value);
    }
    this.claimService.submitClaims(this.claims, sessionDataKey);
  }

  private setUserConsentClaimPresentFlags(claims: Claim[]) {
    let userConsentMandatoryClaimsCount = 0;
    for (let claim of claims) {
      if ((this.claimService.claimUriMatches(claim.name, ClaimConstants.uriLicenseAgreement) ||
        this.claimService.claimUriMatches(claim.name, ClaimConstants.uriPrivacyPolicy)) &&
        claim.type === ClaimType.hidden) {
        userConsentMandatoryClaimsCount++;
      }
    }

    if (userConsentMandatoryClaimsCount > 0 && claims.length === userConsentMandatoryClaimsCount) {
      this.onlyUserConsentClaimPresent = true;
      this.userConsentClaimPresent = true;
    } else if (userConsentMandatoryClaimsCount > 0) {
      this.userConsentClaimPresent = true;
      this.onlyUserConsentClaimPresent = false;
    }
  }
}
