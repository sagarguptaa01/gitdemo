import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MandatoryClaimsComponent } from './mandatory-claims.component';
import { Component } from '@angular/core';
import { ReactiveFormsModule, FormGroup } from '@angular/forms';
import { Input } from '@angular/core';
import { ClaimService } from '../../service/claim.service';
import { ClaimControlService } from '../../service/claim.control.service';
import { Observable } from 'rxjs/Rx';
import { ClaimText } from '../../model/claim-text';
import { ClaimDropdown } from '../../model/claim-dropdown';
import { ActivatedRoute } from '@angular/router';
import { ClaimConstants } from '../../claim.constants';
import { ConfigService } from '../../../../../global/config.service';
import { ConfigKeys } from '../../../../../global/config-keys.constants';
import { ClaimHidden } from '../../model/claim-hidden';
import { FilterHiddenClaimPipe } from './filter-hidden-claim.pipe';

describe('MandatoryClaimsComponent', () => {
  let component: MandatoryClaimsComponent;
  let fixture: ComponentFixture<MandatoryClaimsComponent>;
  let claimService: ClaimService;
  let claimControlService: ClaimControlService;
  let activatedRoute: ActivatedRoute;
  let configService: ConfigService;

  let mockActivatedRoute = {
    snapshot: {
      queryParamMap: {
        get: function (key) { },
        getAll: function (key) { }
      }
    }
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        MandatoryClaimsComponent,
        MockMandatoryClaimComponent,
        FilterHiddenClaimPipe
      ],
      imports: [
        ReactiveFormsModule
      ],
      providers: [
        { provide: ClaimService, useClass: MockClaimService },
        { provide: ClaimControlService, useClass: MockClaimControlService },
        { provide: ActivatedRoute, useValue: mockActivatedRoute },
        { provide: ConfigService, useClass: MockConfigService }
      ]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MandatoryClaimsComponent);
    component = fixture.componentInstance;
    claimService = fixture.debugElement.injector.get(ClaimService);
    claimControlService = fixture.debugElement.injector.get(ClaimControlService);
    activatedRoute = fixture.debugElement.injector.get(ActivatedRoute);
    configService = fixture.debugElement.injector.get(ConfigService);
  });

  it('should create', () => {
    fixture.detectChanges();

    expect(component).toBeTruthy();
  });

  describe('init', () => {

    it('should set the showRequiredMandatoryClaimTitle to true', () => {
      fixture.detectChanges();
      expect(component.showRequiredMandatoryClaimTitle).toBeTruthy();
    });

    it('should set the pageTitle to "Provide mandatory details"', () => {
      let title = 'Provide mandatory details';
      fixture.detectChanges();
      expect(component.pageTitle).toEqual(title);
    });

    it('should set the showMandatoryClaimFillingPage to false', () => {
      fixture.detectChanges();
      expect(component.showPrivacyPolicyAndTermsConditionUpdatedMessage).toBeFalsy();
    });

    it('should set the showManadtoryClaimFillingPage to true', () => {
      fixture.detectChanges();
      expect(component.showMandatoryClaimFillingPage).toBeTruthy();
    });

    it('should get the software license agreement link from the Config', () => {
      let expectedSoftwareLicenseAgreementLink = 'LicenseAgreementLink';
      spyOn(configService, 'get').and.callFake(configKey => {
        if (configKey === ConfigKeys.softwareLicenseAgreement) {
          return expectedSoftwareLicenseAgreementLink;
        }
      });
      fixture.detectChanges();
      expect(component.softwareLicenseAgreementLink).toEqual(expectedSoftwareLicenseAgreementLink);
    });

    it('should get the user privacy notice link from the Config', () => {

      let expectedUserPrivacyLink = 'UserPrivacyLink';
      spyOn(configService, 'get').and.callFake(configKey => {
        if (configKey === ConfigKeys.userPrivacyNotice) {
          return expectedUserPrivacyLink;
        }
      });
      fixture.detectChanges();
      expect(component.userPrivacyNoticeLink).toEqual(expectedUserPrivacyLink);
    });


    it('should make a form with the claims from the activated route', () => {
      let claim1Name = 'claim1';
      let claim2Name = 'claim2';
      let claim3Name = 'claim3';
      let claim4Name = 'claim4';
      let value = 'allClaimsPresent';
      let claims = [
        new ClaimText(claim1Name),
        new ClaimDropdown([], claim2Name),
        new ClaimHidden(claim3Name),
        new ClaimHidden(claim4Name)
      ];
      let expectedClaimUris = ['asdf'];
      activatedRoute.snapshot.queryParamMap.getAll = jasmine.createSpy('getAll').and.returnValue(expectedClaimUris);
      spyOn(claimService, 'getClaims').and.callFake(function (claimUris) {
        if (claimUris === expectedClaimUris) {
          return Observable.of(claims);
        }
      });
      spyOn(component, 'setUserConsentClaimPresentFlags').and.callFake(function (claims) {
      });
      let expectedForm = new FormGroup({});
      spyOn(claimControlService, 'toFormGroup').and.callFake(cs => {
        let claimNames = cs.map(c => c.name);
        if (claimNames.includes(claim1Name) && claimNames.includes(claim2Name)) {
          return expectedForm;
        }
      });

      fixture.detectChanges();

      expect(component.form).toEqual(expectedForm);
    });

    it('should add an \'agreeToS\' checkbox to the form', () => {
      let form = new FormGroup({});
      let claims = [
        new ClaimHidden('exfoUserPrivacyNoticeAcceptedOn'),
        new ClaimHidden('exfoLicenseAgreementAcceptedOn')
      ];
      spyOn(claimService, 'getClaims').and.returnValue(Observable.of(claims));
      spyOn(claimControlService, 'toFormGroup').and.returnValue(form);
      spyOn(component, 'setUserConsentClaimPresentFlags').and.callFake(claims => {
        let claimNames = claims.map(c => c.name);
        if (claimNames.includes(ClaimConstants.uriLicenseAgreement) && claimNames.includes(ClaimConstants.uriLicenseAgreement)) {
          component.userConsentClaimPresent = true;
        }
      });

      fixture.detectChanges();

      let formControl = form.get(component.agreeToS);
      expect(formControl).toBeTruthy();
    });

    it('it should not add an \'agreeToS\' checkbox to the form', () => {
      let form = new FormGroup({});
      let claims = [
        new ClaimText('abc'),
        new ClaimDropdown([], 'xyz')
      ];
      spyOn(claimService, 'getClaims').and.returnValue(Observable.of(claims));
      spyOn(claimControlService, 'toFormGroup').and.returnValue(form);
      spyOn(component, 'setUserConsentClaimPresentFlags').and.callFake(claims => {
        let claimNames = claims.map(c => c.name);
        if (claimNames.includes(ClaimConstants.uriLicenseAgreement) && claimNames.includes(ClaimConstants.uriLicenseAgreement)) {
          component.userConsentClaimPresent = true;
        } else {
          component.userConsentClaimPresent = false;
        }
      });

      fixture.detectChanges();

      let formControl = form.get(component.agreeToS);
      expect(formControl).toBeFalsy();
    });

    it('the \'agreeToS\' checkbox should have a RequiredTrue validator', () => {
      let form = new FormGroup({});
      let claims = [
        new ClaimHidden('exfoUserPrivacyNoticeAcceptedOn'),
        new ClaimHidden('exfoLicenseAgreementAcceptedOn')
      ];
      spyOn(claimService, 'getClaims').and.returnValue(Observable.of(claims));
      spyOn(component, 'setUserConsentClaimPresentFlags').and.callFake(claims => {
        let claimNames = claims.map(c => c.name);
        if (claimNames.includes(ClaimConstants.uriLicenseAgreement) && claimNames.includes(ClaimConstants.uriLicenseAgreement)) {
          component.userConsentClaimPresent = true;
        }
      });
      spyOn(claimControlService, 'toFormGroup').and.returnValue(form);
      fixture.detectChanges();

      let formControl = form.get(component.agreeToS);
      formControl.setValue(false);
      expect(formControl.valid).toBeFalsy();
    });
  });

  describe('destroy', () => {
    beforeEach(() => {
      fixture.detectChanges();
    });

    it('should unsubscribe from ClaimService', () => {
      component.ngOnDestroy();

      expect(component.getClaimsSubscription.closed).toBeTruthy();
    });
  });

  describe('submit', () => {
    beforeEach(() => {
      fixture.detectChanges();
    });

    it('should submit the claims with the sessionDataKey', () => {
      let claims = [new ClaimText('toto')];
      claims[0].value = "test";
      component.claims = claims;
      let submitClaimsSpy = spyOn(claimService, 'submitClaims');
      let sessionDataKey = 'abcd1234';
      activatedRoute.snapshot.queryParamMap.get = jasmine.createSpy('get').and.callFake(function (key) {
        if (key === ClaimConstants.queryKeys.sessionDataKey) {
          return sessionDataKey;
        }
      });

      component.onSubmit();

      expect(submitClaimsSpy).toHaveBeenCalledWith(claims, sessionDataKey);
    });

    it('should trim extra space in claims', () => {
      // Arrange

      let trimmedClaims = 'test';
      let claims = [new ClaimText('toto')];
      claims[0].value = ' test ';
      component.claims = claims;

      // Arrange & Define Assert
      spyOn(claimService, 'submitClaims').and.callFake(data => {
        expect(component.claims[0].value).toBe(trimmedClaims);
        return new Observable<any>(observer => observer.next(new Response()));
      });

      // Act
      component.onSubmit();
    });

    it('should not trim NULL field in claims', () => {
      // Arrange
      let trimmedClaims = null;
      let claims = [new ClaimText('toto')];
      claims[0].value = null;
      component.claims = claims;

      // Arrange & Define Assert
      spyOn(claimService, 'submitClaims').and.callFake(data => {
        expect(component.claims[0].value).toBe(trimmedClaims);
        return new Observable<any>(observer => observer.next(new Response()));
      });

      // Act
      component.onSubmit();
    });

    it('should not trim UNDEFINED field in claims', () => {
      // Arrange
      let trimmedClaims = undefined;
      let claims = [new ClaimText('toto')];
      claims[0].value = undefined;
      component.claims = claims;

      // Arrange & Define Assert
      spyOn(claimService, 'submitClaims').and.callFake(data => {
        expect(component.claims[0].value).toBe(trimmedClaims);
        return new Observable<any>(observer => observer.next(new Response()));
      });

      // Act
      component.onSubmit();
    });

  });
});

@Component({
  selector: 'app-mandatory-claim',
  template: '',
})
class MockMandatoryClaimComponent {
  @Input() model;
  @Input() form;
}

class MockClaimService {
  getClaims(claimUris) {
    return Observable.of();
  }
  getClaimDetails(claims: string[]) {
    return '';
  }
  submitClaims() { }
}

class MockClaimControlService {
  toFormGroup() { }
}
class MockConfigService {
  public get(key: string) { }
}

