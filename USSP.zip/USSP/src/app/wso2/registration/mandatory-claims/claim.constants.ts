export const ClaimConstants = {
    urlSymbols: {
        paramsStart: '?',
        equal: '=',
        separator: '&'
    },
    queryKeys: {
        claim: 'claim',
        value: 'value',
        sessionDataKey: 'sessionDataKey',
        submit: 'submit'
    },
    queryValues: {
        true: true
    },
    uriCountry: 'country',
    uriPrivacyPolicy: 'exfoUserPrivacyNoticeAcceptedOn',
    uriLicenseAgreement: 'exfoLicenseAgreementAcceptedOn',
};
