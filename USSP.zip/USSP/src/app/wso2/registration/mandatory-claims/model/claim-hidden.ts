import { Claim, ClaimType } from './claim';

export class ClaimHidden extends Claim {

    constructor(name?: string, displayName?: string, regex?: string, displayOrder?: number) {
        super(ClaimType.hidden, name, displayName, regex, displayOrder);
    }
}
