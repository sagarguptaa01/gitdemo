export class Claim {
    type: string;
    name: string;
    displayName: string;
    regex: string;
    displayOrder: number;
    value: string;

    constructor(type: string, name?: string, displayName?: string, regex?: string, displayOrder?: number) {
        this.type = type;
        this.name = name;
        this.displayName = displayName;
        this.regex = regex || '.*';
        this.displayOrder = displayOrder;
    }
}

export const ClaimType = {
    text: 'text',
    dropdown: 'dropdown',
    hidden : 'hidden'
};
