import { Claim, ClaimType } from './claim';

export class ClaimDropdown extends Claim {

    options: string[] = [];

    constructor(options: string[], name?: string, displayName?: string, regex?: string, displayOrder?: number) {
        super(ClaimType.dropdown, name, displayName, regex, displayOrder);
        this.options = [''].concat(options);
    }
}
