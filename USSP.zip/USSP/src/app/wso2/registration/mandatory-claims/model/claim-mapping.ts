export class ClaimMapping {
    uri: string;
    displayName: string;
    regex: string;
    displayOrder: number;

    constructor(uri: string, displayName: string, regex: string, displayOrder: number) {
        this.uri = uri;
        this.displayName = displayName;
        this.regex = regex;
        this.displayOrder = displayOrder;
    }
}