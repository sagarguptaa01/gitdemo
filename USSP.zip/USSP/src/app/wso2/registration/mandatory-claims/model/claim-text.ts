import { Claim, ClaimType } from './claim';

export class ClaimText extends Claim {

    constructor(name?: string, displayName?: string, regex?: string, displayOrder?: number) {
        super(ClaimType.text, name, displayName, regex, displayOrder);

    }
}