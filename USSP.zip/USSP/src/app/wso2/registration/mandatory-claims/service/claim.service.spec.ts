import { TestBed, inject } from '@angular/core/testing';

import { ClaimService } from './claim.service';
import { CountryService } from '../../../../global/country.service';
import { ConfigService } from '../../../../global/config.service';
import { Http, BaseRequestOptions, Response, ResponseOptions } from '@angular/http';
import { MockBackend } from '@angular/http/testing';
import { Wso2ApiConstants } from '../../../../global/wso2-api.constants';
import { Claim, ClaimType } from '../model/claim';
import { ClaimText } from '../model/claim-text';
import { BackendApiConstants } from '../../../../global/backend-api.constants';
import { Observable } from 'rxjs/Rx';
import { ClaimConstants } from '../claim.constants';
import { WindowService } from '../../../../global/window.service';
import { ClaimDropdown } from '../model/claim-dropdown';
import { CountryDto } from '../../../../global/dto/country.dto';
import { ConfigKeys } from '../../../../global/config-keys.constants';
import { exec } from 'child_process';


describe('ClaimService', () => {

  let countryService: CountryService;
  let configService: ConfigService;
  let windowService: WindowService;
  let mockBackend: MockBackend;
  let baseRequestOptions: BaseRequestOptions;
  let http: Http;
  let service: ClaimService;

  let baseClaimMappingsUrl = BackendApiConstants.baseUrl + BackendApiConstants.services.claim.name + ClaimConstants.urlSymbols.paramsStart;

  beforeEach(() => {
    countryService = new MockCountryService();
    configService = new MockConfigService();
    windowService = new WindowService();
    mockBackend = new MockBackend();
    baseRequestOptions = new BaseRequestOptions();
    http = new Http(mockBackend, baseRequestOptions);
    service = new ClaimService(countryService, configService, http, windowService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('getClaims', () => {
    it('when a claim uri is in the parameters, should build a claim with display name, regex and display order from it', () => {
      let claimUri = 'claimUri1';
      let claimName = 'claimName1';
      let claimRegex = '[a]';
      let claimDisplayOrder = 1337;
      mockBackend.connections.subscribe(connection => {
        let claimParam = ClaimConstants.queryKeys.claim + ClaimConstants.urlSymbols.equal + claimUri;
        if (connection.request.url.includes(baseClaimMappingsUrl + claimParam)) {
          let body = {
            claims: [{
                uri: claimUri,
                displayName: claimName,
                regex: claimRegex,
                displayOrder: claimDisplayOrder
              }]
          };
          connection.mockRespond(new Response(new ResponseOptions({body: JSON.stringify(body)})));
        }
      });

      service.getClaims([claimUri]).subscribe(result => {
        expect(result.length).toEqual(1);
        expect(result[0].name).toEqual(claimUri);
        expect(result[0].displayName).toEqual(claimName);
        expect(result[0].regex).toEqual(claimRegex);
        expect(result[0].displayOrder).toEqual(claimDisplayOrder);
      });
    });

    it('when many claim uris are in the parameters, should build a claim with display name for each of them', () => {
      let claim1Uri = 'claim1';
      let claim1Name = 'claim1Name';
      let claim2Uri = 'claim2';
      let claim2Name = 'claim2Name';
      let claim3Uri = 'claim3';
      let claim3Name = 'claim3Name';
      mockBackend.connections.subscribe(connection => {
        let claimParam = ClaimConstants.queryKeys.claim + ClaimConstants.urlSymbols.equal + claim1Uri;
        if (connection.request.url.includes(baseClaimMappingsUrl + claimParam)) {
          let body = {
            claims: [
              { uri: claim1Uri, displayName: claim1Name },
              { uri: claim2Uri, displayName: claim2Name },
              { uri: claim3Uri, displayName: claim3Name },
            ]
          };
          connection.mockRespond(new Response(new ResponseOptions({body: JSON.stringify(body)})));
        }
      });

      service.getClaims([claim1Uri, claim2Uri, claim3Uri]).subscribe(result => {
        expect(result.length).toEqual(3);
        expect(result[0].displayName).toEqual(claim1Name);
        expect(result[1].displayName).toEqual(claim2Name);
        expect(result[2].displayName).toEqual(claim3Name);
      });
    });

    it('when a claim uri containing the word \'country\' is in the parameters, should build a ClaimDropdown', () => {
      let claimUri = 'claimcountryuri';
      mockBackend.connections.subscribe(connection => {
        let claimParam = ClaimConstants.queryKeys.claim + ClaimConstants.urlSymbols.equal + claimUri;
        if (connection.request.url.includes(baseClaimMappingsUrl + claimParam)) {
          let body = {
            claims: [{ uri: claimUri }]
          };
          connection.mockRespond(new Response(new ResponseOptions({body: JSON.stringify(body)})));
        }
      });

      service.getClaims([claimUri]).subscribe(result => {
        expect(result.length).toEqual(1);
        expect(result[0]).toEqual(jasmine.any(ClaimDropdown));
      });
    });

    it('when a claim is a country, the ClaimDropdown should include a country list as options', () => {
      let claimUri = 'claimcountryuri';
      let countryName = 'India';
      let configFirstCountries = ['IN'];
      spyOn(configService, 'get').and.callFake(function(key) {
        if (key === ConfigKeys.firstCountries) {
          return configFirstCountries;
        }
      });
      let countries = [new CountryDto(null, countryName)];
      spyOn(countryService, 'getCountryList').and.callFake(function(firstCountries) {
        if (firstCountries === configFirstCountries) {
          return Observable.of(countries);
        }
      });
      mockBackend.connections.subscribe(connection => {
        let claimParam = ClaimConstants.queryKeys.claim + ClaimConstants.urlSymbols.equal + claimUri;
        if (connection.request.url.includes(baseClaimMappingsUrl + claimParam)) {
          let body = {
            claims: [{ uri: claimUri }]
          };
          connection.mockRespond(new Response(new ResponseOptions({body: JSON.stringify(body)})));
        }
      });

      service.getClaims([claimUri]).subscribe(result => {
        expect((<ClaimDropdown>result[0]).options).toContain(countryName);
      });
    });

    it('should sort the claims by display order', () => {
      let claim1Uri = 'claim1';
      let claim1DisplayOrder = 3;
      let claim2Uri = 'claim2';
      let claim2DisplayOrder = 88;
      let claim3Uri = 'claim3';
      let claim3DisplayOrder = 1;
      mockBackend.connections.subscribe(connection => {
        let claimParam = ClaimConstants.queryKeys.claim + ClaimConstants.urlSymbols.equal + claim1Uri;
        if (connection.request.url.includes(baseClaimMappingsUrl + claimParam)) {
          let body = {
            claims: [
              { uri: claim1Uri, displayOrder: claim1DisplayOrder },
              { uri: claim2Uri, displayOrder: claim2DisplayOrder },
              { uri: claim3Uri, displayOrder: claim3DisplayOrder },
            ]
          };
          connection.mockRespond(new Response(new ResponseOptions({body: JSON.stringify(body)})));
        }
      });

      service.getClaims([claim1Uri, claim2Uri, claim3Uri]).subscribe(result => {
        expect(result[0].name).toEqual(claim3Uri);
        expect(result[1].name).toEqual(claim1Uri);
        expect(result[2].name).toEqual(claim2Uri);
      });
    });

    it('should put the claims with a displayOrder of 0 at the end of the returned array', () => {
      let claim1Uri = 'claim1';
      let claim1DisplayOrder = 88;
      let claim2Uri = 'claim2';
      let claim2DisplayOrder = 0;
      let claim3Uri = 'claim3';
      let claim3DisplayOrder = 5;
      mockBackend.connections.subscribe(connection => {
        let claimParam = ClaimConstants.queryKeys.claim + ClaimConstants.urlSymbols.equal + claim1Uri;
        if (connection.request.url.includes(baseClaimMappingsUrl + claimParam)) {
          let body = {
            claims: [
              { uri: claim1Uri, displayOrder: claim1DisplayOrder },
              { uri: claim2Uri, displayOrder: claim2DisplayOrder },
              { uri: claim3Uri, displayOrder: claim3DisplayOrder },
            ]
          };
          connection.mockRespond(new Response(new ResponseOptions({body: JSON.stringify(body)})));
        }
      });

      service.getClaims([claim1Uri, claim2Uri, claim3Uri]).subscribe(result => {
        expect(result[0].name).toEqual(claim3Uri);
        expect(result[1].name).toEqual(claim1Uri);
        expect(result[2].name).toEqual(claim2Uri);
      });
    });
  });

  describe('claimUriMatches', () => {
    let claimUri = 'exfoLicenseAgreementAcceptedOn';
    let claimUri1 = 'claimcountryuri';
    let claimtype;
    it('check the Url matches to new added consent claims' , () => {
      spyOn(service, 'claimUriMatches').and.callFake(function (claimUri) {
       expect(claimUri).toEqual(ClaimConstants.uriLicenseAgreement);
      });
    });

    it('it should check the claims type  dropdown for claim Url', () => {
      spyOn(service, 'claimUriMatches').and.callFake(function (claimUri1) {
        if (claimUri1.includes(ClaimConstants.uriCountry)) {
              claimtype = 'dropdown';
        }
        expect(claimtype).toEqual(ClaimType.dropdown);
     });
    });
    it('it should check the claims type hidden for claim Url', () => {
      spyOn(service, 'claimUriMatches').and.callFake(function (claimUri) {
        if (claimUri.endsWith(ClaimConstants.uriLicenseAgreement) || claimUri.endsWith(ClaimConstants.uriPrivacyPolicy)) {
              claimtype = 'hidden';
        }
        expect(claimtype).toEqual(ClaimType.hidden);
     });
    });
  });

  describe('submitClaims', () => {
    it('should redirect to WSO2 claims endpoint', () => {
      let usedUrl;
      let window = {
        location: {
          replace: jasmine.createSpy('replace').and.callFake(function(url) {
            usedUrl = url;
          })
        }
      };
      spyOn(windowService, 'getWindow').and.returnValue(window);
      let expectedUrl = Wso2ApiConstants.realUrl +
                        Wso2ApiConstants.authentication.baseEndpoint +
                        Wso2ApiConstants.authentication.claims + '?';

      service.submitClaims([], null);

      expect(usedUrl).toContain(expectedUrl);
    });

    it('should pass the \'sessionDataKey\' parameter to the redirection', () => {
      let usedUrl;
      let window = {
        location: {
          replace: jasmine.createSpy('replace').and.callFake(function(url) {
            usedUrl = url;
          })
        }
      };
      spyOn(windowService, 'getWindow').and.returnValue(window);
      let sessionDataKey = 'abcd1234';
      let expectedSessionDatKeyQuery = ClaimConstants.queryKeys.sessionDataKey + ClaimConstants.urlSymbols.equal + sessionDataKey;

      service.submitClaims([], sessionDataKey);

      expect(usedUrl).toContain(expectedSessionDatKeyQuery);
    });

    it('should pass a \'submit\' parameter set to true to the redirection', () => {
      let usedUrl;
      let window = {
        location: {
          replace: jasmine.createSpy('replace').and.callFake(function(url) {
            usedUrl = url;
          })
        }
      };
      spyOn(windowService, 'getWindow').and.returnValue(window);
      let expectedSubmitQuery = ClaimConstants.queryKeys.submit + ClaimConstants.urlSymbols.equal + ClaimConstants.queryValues.true;

      service.submitClaims([], null);

      expect(usedUrl).toContain(expectedSubmitQuery);
    });

    it('when called with one claim, should pass the claim name and its value to the redirection', () => {
      let claimName = 'claim1';
      let claimValue = 'value1';
      let claim = new ClaimText(claimName);
      claim.value = claimValue;
      let usedUrl;
      let window = {
        location: {
          replace: jasmine.createSpy('replace').and.callFake(function(url) {
            usedUrl = url;
          })
        }
      };
      spyOn(windowService, 'getWindow').and.returnValue(window);
      let expectedClaimNameQuery = ClaimConstants.queryKeys.claim + ClaimConstants.urlSymbols.equal + claim.name;
      let expectedClaimValueQuery = ClaimConstants.queryKeys.value + ClaimConstants.urlSymbols.equal + claim.value;

      service.submitClaims([claim], null);

      expect(usedUrl).toContain(expectedClaimNameQuery + ClaimConstants.urlSymbols.separator + expectedClaimValueQuery);
    });

    it('when called with two claims, should pass each claim\'s value successively to the redirection', () => {
      let claim1Name = 'claim1';
      let claim1Value = 'value1';
      let claim1 = new ClaimText(claim1Name);
      claim1.value = claim1Value;
      let claim2Name = 'claim2';
      let claim2Value = 'value2';
      let claim2 = new ClaimText(claim2Name);
      claim2.value = claim2Value;
      let usedUrl;
      let window = {
        location: {
          replace: jasmine.createSpy('replace').and.callFake(function(url) {
            usedUrl = url;
          })
        }
      };
      spyOn(windowService, 'getWindow').and.returnValue(window);
      let expectedClaim1NameQuery = ClaimConstants.queryKeys.claim + ClaimConstants.urlSymbols.equal + claim1.name;
      let expectedClaim1ValueQuery = ClaimConstants.queryKeys.value + ClaimConstants.urlSymbols.equal + claim1.value;
      let expectedClaim2NameQuery = ClaimConstants.queryKeys.claim + ClaimConstants.urlSymbols.equal + claim2.name;
      let expectedClaim2ValueQuery = ClaimConstants.queryKeys.value + ClaimConstants.urlSymbols.equal + claim2.value;

      service.submitClaims([claim1, claim2], null);

      expect(usedUrl).toContain(expectedClaim1NameQuery + ClaimConstants.urlSymbols.separator + expectedClaim1ValueQuery +
                                ClaimConstants.urlSymbols.separator +
                                expectedClaim2NameQuery + ClaimConstants.urlSymbols.separator + expectedClaim2ValueQuery);
    });

    it('should encode claim values that use characters typically used in URL parameters', () => {
      let claimName = 'claim1';
      let claimValue = ClaimConstants.urlSymbols.equal + ClaimConstants.urlSymbols.paramsStart + ClaimConstants.urlSymbols.separator;
      let claim = new ClaimText(claimName);
      claim.value = claimValue;
      let usedUrl;
      let window = {
        location: {
          replace: jasmine.createSpy('replace').and.callFake(function(url) {
            usedUrl = url;
          })
        }
      };
      spyOn(windowService, 'getWindow').and.returnValue(window);
      let encodedClaimValue = encodeURIComponent(claimValue);

      service.submitClaims([claim], null);

      expect(usedUrl).toContain(encodedClaimValue);
    });

  });

});

class MockCountryService extends CountryService {
  constructor() {
    super(null);
  }
  getCountryList(firstCountries) {
    return Observable.of([]);
   }
}

class MockConfigService extends ConfigService {
  constructor() {
    super(null);
  }
  get() { }
}

class MockWindowService extends WindowService {
  constructor() {
    super();
  }
  getWindow(): Window {
    return null;
  }
}
