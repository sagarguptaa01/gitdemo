import { Injectable, Inject } from '@angular/core';
import { Claim, ClaimType } from '../model/claim';
import { ClaimText } from '../model/claim-text';
import { ClaimDropdown } from '../model/claim-dropdown';
import { CountryService } from '../../../../global/country.service';
import { ConfigService } from '../../../../global/config.service';
import { ConfigKeys } from '../../../../global/config-keys.constants';
import { Observable } from 'rxjs/Rx';
import { Http, Response, URLSearchParams } from '@angular/http';
import { Wso2ApiConstants } from '../../../../global/wso2-api.constants';
import { ClaimMapping } from '../model/claim-mapping';
import { BackendApiConstants } from '../../../../global/backend-api.constants';
import { ClaimConstants } from '../claim.constants';
import { WindowService } from '../../../../global/window.service';
import { ClaimHidden } from '../model/claim-hidden';

@Injectable()
export class ClaimService {

  constructor(private countryService: CountryService,
              private configService: ConfigService,
              private http: Http,
              private windowService: WindowService) { }

  public getClaims(claimUris: string[]): Observable<Claim[]> {
    return Observable.forkJoin(this.getCountries(),
                               this.getClaimMappings(claimUris))
                      .map(data => {
                        return this.buildClaims(data[0], data[1]);
                      });
  }

  private getCountries(): Observable<string[]> {
    let firstCountries = this.configService.get(ConfigKeys.firstCountries);
    return this.countryService.getCountryList(firstCountries).map(countries => countries.map(country => country.name));
  }

  private getClaimMappings(claimUris: string[]): Observable<ClaimMapping[]> {
    let url = BackendApiConstants.baseUrl + BackendApiConstants.services.claim.name + ClaimConstants.urlSymbols.paramsStart;
    let params = new URLSearchParams();
    claimUris.forEach(claim => {
      params.append(ClaimConstants.queryKeys.claim, claim);
    });
    url += params.toString();
    return this.http.get(url).map(response => this.toClaimMappings(response));
  }

  private toClaimMappings(response: Response): ClaimMapping[] {
    let claimMappings = [];
    let responseObj = response.json();
    let claimsFromResponse = response.json().claims;
    claimsFromResponse.forEach(claim => {
      claimMappings.push(new ClaimMapping(claim.uri, claim.displayName, claim.regex, claim.displayOrder));
    });
    return claimMappings;
  }

  private buildClaims(countries: string[], claimMappings: ClaimMapping[]): Claim[] {
    let claims = new Array<Claim>();

    claimMappings.forEach(claim => {
      if (this.getClaimTypeFromClaimUri(claim.uri) === ClaimType.hidden) {
        claims.push(new ClaimHidden(claim.uri, claim.displayName, claim.regex, claim.displayOrder));
      } else if (this.getClaimTypeFromClaimUri(claim.uri) === ClaimType.dropdown) {
        claims.push(new ClaimDropdown(countries, claim.uri, claim.displayName, claim.regex, claim.displayOrder));
      } else {
        claims.push(new ClaimText(claim.uri, claim.displayName, claim.regex, claim.displayOrder));
      }
    });
    return claims.sort(this.compareDisplayOrder);
  }

  private compareDisplayOrder(claimA: Claim, claimB: Claim): number {
    let sortValue = 0;

    if (claimA.displayOrder === 0 && claimB.displayOrder > 0) {
      sortValue = 1;
    } else if (claimA.displayOrder > 0 && claimB.displayOrder === 0) {
      sortValue = -1;
    } else {
      sortValue = claimA.displayOrder - claimB.displayOrder;
    }

    return sortValue;
  }

  public claimUriMatches(uri: String, claim: String): Boolean {
    if (uri !== null && (uri.toLowerCase().endsWith('/' + claim.toLowerCase()) || uri.toLowerCase() === claim.toLowerCase())) {
      return true;
    }
    return false;
  }

  private getClaimTypeFromClaimUri(claimUri: String): String {
    if (this.claimUriMatches(claimUri, ClaimConstants.uriLicenseAgreement) ||
        this.claimUriMatches(claimUri, ClaimConstants.uriPrivacyPolicy)) {
      return ClaimType.hidden;
    }

    if (claimUri.includes(ClaimConstants.uriCountry)) {
      return ClaimType.dropdown;
    }

    return ClaimType.text;
  }

  public submitClaims(claims: Claim[], sessionDataKey: string): void {
    let url = Wso2ApiConstants.realUrl +
              Wso2ApiConstants.authentication.baseEndpoint +
              Wso2ApiConstants.authentication.claims +
              ClaimConstants.urlSymbols.paramsStart;

    claims.forEach(claim => {
      url += ClaimConstants.queryKeys.claim + ClaimConstants.urlSymbols.equal +
             claim.name + ClaimConstants.urlSymbols.separator;
      url += ClaimConstants.queryKeys.value + ClaimConstants.urlSymbols.equal +
             encodeURIComponent(claim.value) + ClaimConstants.urlSymbols.separator;
    });
    url += ClaimConstants.queryKeys.sessionDataKey + ClaimConstants.urlSymbols.equal + sessionDataKey + ClaimConstants.urlSymbols.separator;
    url += ClaimConstants.queryKeys.submit + ClaimConstants.urlSymbols.equal + ClaimConstants.queryValues.true;

    this.windowService.getWindow().location.replace(url);
  }
}
