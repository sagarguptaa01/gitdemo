import { Injectable } from '@angular/core';
import { Claim, ClaimType } from '../model/claim';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Injectable()
export class ClaimControlService {

  constructor() { }

  public toFormGroup(claims: Claim[]): FormGroup {
    let group = {};
    claims.forEach(claim => {
      if (claim.type !== ClaimType.hidden) {
        group[claim.name] = new FormControl('', [Validators.required, Validators.pattern(claim.regex)]);
      }
    });

    return new FormGroup(group);
  }
}
