import { TestBed, inject } from '@angular/core/testing';

import { ClaimControlService } from './claim.control.service';
import { ClaimText } from '../model/claim-text';
import { ClaimDropdown } from '../model/claim-dropdown';

describe('ClaimControlService', () => {
  let service: ClaimControlService;

  beforeEach(() => {
    service = new ClaimControlService();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('toFormGroup', () => {
    it('should create a FormGroup with a FormControl for each passed claim', () => {
      let claim1Name = 'claim1';
      let claim2Name = 'claim2';
      let claims = [
        new ClaimText(claim1Name),
        new ClaimDropdown([], claim2Name)
      ];

      let formGroup = service.toFormGroup(claims);

      expect(formGroup.contains(claim1Name)).toBeTruthy();
      expect(formGroup.contains(claim2Name)).toBeTruthy();
    });

    it('should assign a Required validator to the form controls', () => {
      let claim1Name = 'claim1';
      let claim2Name = 'claim2';
      let claims = [
        new ClaimText(claim1Name),
        new ClaimText(claim2Name)
      ];

      let formGroup = service.toFormGroup(claims);
      formGroup.controls[claim2Name].setValue('asdf');

      expect(formGroup.controls[claim1Name].valid).toBeFalsy();
      expect(formGroup.controls[claim2Name].valid).toBeTruthy();
    });

    it('should assign a Regex validator to the form controls with the passed claim\'s regex value', () => {
      let claim1Name = 'claim1';
      let claim2Name = 'claim2';
      let regexOnlyLowercaseA = '[a]';
      let claims = [
        new ClaimText(claim1Name, '', regexOnlyLowercaseA),
        new ClaimText(claim2Name, '', regexOnlyLowercaseA)
      ];

      let formGroup = service.toFormGroup(claims);
      formGroup.controls[claim1Name].setValue('a');
      formGroup.controls[claim2Name].setValue('b');

      expect(formGroup.controls[claim1Name].valid).toBeTruthy();
      expect(formGroup.controls[claim2Name].valid).toBeFalsy();
    });
  });

});
