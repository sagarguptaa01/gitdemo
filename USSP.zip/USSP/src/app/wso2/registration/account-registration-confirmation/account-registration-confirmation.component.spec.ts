import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountRegistrationConfirmationComponent } from './account-registration-confirmation.component';

describe('AccountRegistrationConfirmationComponent', () => {
  let component: AccountRegistrationConfirmationComponent;
  let fixture: ComponentFixture<AccountRegistrationConfirmationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AccountRegistrationConfirmationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountRegistrationConfirmationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
