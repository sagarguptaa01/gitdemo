import { Component, OnInit } from '@angular/core';
import { AccountRegistrationConstants } from '../account-registration.constants';

@Component({
  selector: 'app-account-registration-confirmation',
  templateUrl: './account-registration-confirmation.component.html',
  styleUrls: ['./account-registration-confirmation.component.css']
})
export class AccountRegistrationConfirmationComponent implements OnInit {

  email: string;
  contactUsLink: string;

  constructor() { }

  ngOnInit() {
    this.email = sessionStorage.getItem('newAccountEmail');
    this.contactUsLink = AccountRegistrationConstants.ExfoLinks.ContactUs;
  }

}
