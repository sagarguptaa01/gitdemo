import { TestBed, inject } from '@angular/core/testing';
import { MockBackend } from '@angular/http/testing';
import { BaseRequestOptions, Http } from '@angular/http';
import { BackendApiConstants } from '../../../global/backend-api.constants';
import { Wso2ApiConstants } from '../../../global/wso2-api.constants';
import { EmailValidationService } from './email-validation-service';

describe('EmailValidationService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        MockBackend,
        BaseRequestOptions,
        {
          provide: Http,
          useFactory: (backendInstance: MockBackend, defaultOptions: BaseRequestOptions) => {
            return new Http(backendInstance, defaultOptions);
          },
          deps: [MockBackend, BaseRequestOptions]
        },
        EmailValidationService
      ]
    });
  });

  describe('validateEmailAdress', () => {
    it('should make a POST request to USSP-BE for Email Validation', inject([EmailValidationService, MockBackend],
      (service: EmailValidationService, mockBackend: MockBackend) => {
      // Arrange
      let emailAddress = 'email-test@abcd.com';

      // Act
      service.validateEmailAddress(emailAddress);

      // Assert
      mockBackend.connections.subscribe(connection => {
        expect(connection.request.url).toEqual(BackendApiConstants.baseUrl
          + BackendApiConstants.services.tenant.validateEmail.Endpoint);
      });

    }));

    it('should include the Email-Address in the POST request body', inject([EmailValidationService, MockBackend],
      (service: EmailValidationService, mockBackend: MockBackend) => {
      // Arrange
      let emailAddress = 'email-test@abcd.com';

      // Act
      service.validateEmailAddress(emailAddress);

      // Assert
      mockBackend.connections.subscribe(connection => {
        let body = connection.request.json();
        expect(body.key).toEqual(emailAddress);
      });

    }));

    it('should include a Content-Type:application/json header', inject([EmailValidationService, MockBackend],
      (service: EmailValidationService, mockBackend: MockBackend) => {
      // Arrange
      let emailAddress = 'email-test@abcd.com';

      // Act
      service.validateEmailAddress(emailAddress);

      // Assert
      mockBackend.connections.subscribe((connection) => {
        expect(connection.request.headers.get('Content-Type')).toEqual('application/json');
      });

    }));
  });
});
