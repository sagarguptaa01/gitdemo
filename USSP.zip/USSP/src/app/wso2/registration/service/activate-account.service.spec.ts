import { TestBed, inject } from '@angular/core/testing';
import { Observable } from 'rxjs/Rx';
import { ActivateAccountService } from './activate-account.service';
import { MockBackend } from '@angular/http/testing';
import { BaseRequestOptions, Http, Response, ResponseOptions } from '@angular/http';
import { BackendApiConstants } from '../../../global/backend-api.constants';
import { IdentityRecoveryService } from '../../authentication/service/identity-recovery.service';

describe('ActivateAccountService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        MockBackend,
        BaseRequestOptions,
        {
          provide: Http,
          useFactory: (backendInstance: MockBackend, defaultOptions: BaseRequestOptions) => {
            return new Http(backendInstance, defaultOptions);
          },
          deps: [MockBackend, BaseRequestOptions]
        },
        { provide: IdentityRecoveryService, useClass: MockIdentityRecoveryService },
        ActivateAccountService
      ]
    });
  });

  it('should be created', inject([ActivateAccountService], (service: ActivateAccountService) => {
    expect(service).toBeTruthy();
  }));

  describe('activateAccount', () => {

    it('should make a request to the backend\'s password-status endpoint', inject([ActivateAccountService, MockBackend],
      (service: ActivateAccountService, mockBackend: MockBackend) => {
        let username = 'username';

        mockBackend.connections.subscribe(connection => {

          expect(connection.request.url).toContain(BackendApiConstants.services.User.BaseEndpoint + username +
                                                   BackendApiConstants.services.User.PasswordStatus.Endpoint);
        });
    }));

    it('should return true when the password is updated', inject([ActivateAccountService, MockBackend, IdentityRecoveryService],
      (service: ActivateAccountService, mockBackend: MockBackend, identityRecoveryService: IdentityRecoveryService) => {
      let username = 'username';
      let confirmation = 'confirmation';
      let mockResponse = {
        status: BackendApiConstants.services.User.PasswordStatus.Updated
      };
      mockBackend.connections.subscribe(connection => {
        connection.mockRespond(new Response(new ResponseOptions({
          body: JSON.stringify(mockResponse)
        })));
      });
      spyOn(identityRecoveryService, 'addUser').and.returnValue(Observable.of());

      service.activateAccount(username, confirmation).subscribe(result => {
        expect(result).toBeTruthy();
      });
    }));

    it('should addUser with IdentityRecoveryService when the password is updated',
      inject([ActivateAccountService, MockBackend, IdentityRecoveryService],
      (service: ActivateAccountService, mockBackend: MockBackend, identityRecoveryService: IdentityRecoveryService) => {
      let username = 'username';
      let confirmation = 'confirmation';
      let mockResponse = {
        status: BackendApiConstants.services.User.PasswordStatus.Updated
      };
      mockBackend.connections.subscribe(connection => {
        connection.mockRespond(new Response(new ResponseOptions({
          body: JSON.stringify(mockResponse)
        })));
      });
      let identityRecoverySpy = spyOn(identityRecoveryService, 'addUser').and.returnValue(Observable.of());

      service.activateAccount(username, confirmation).subscribe(result => {
        expect(identityRecoverySpy).toHaveBeenCalledWith(confirmation);
      });
    }));

    it('should return false when the password is pending', inject([ActivateAccountService, MockBackend],
      (service: ActivateAccountService, mockBackend: MockBackend) => {
      let username = 'username';
      let confirmation = 'confirmation';
      let mockResponse = {
        status: BackendApiConstants.services.User.PasswordStatus.Pending
      };
      mockBackend.connections.subscribe(connection => {
        connection.mockRespond(new Response(new ResponseOptions({
          body: JSON.stringify(mockResponse)
        })));
      });

      service.activateAccount(username, confirmation).subscribe(result => {
        expect(result).toBeFalsy();
      });
    }));
  });
});

class MockIdentityRecoveryService {
  addUser(confirmation) { }
}
