import { Injectable, Inject } from '@angular/core';
import { Http, Headers, URLSearchParams, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { AddTenantDto } from './dto/add-tenant.dto';
import { BackendApiConstants } from '../../../global/backend-api.constants';
import { PlusSignQueryEncoder } from '../../../global/PlusSignQueryEncoder';
import { EmailEncryptionKeyDto } from './dto/email-key.dto';
import { CreateTenantRequestDto } from './dto/create-tenant-request.dto';

@Injectable()
export class AccountRegistrationService {

  constructor(private http: Http) { }

  public createOrganizationAccount(createTenantdto: CreateTenantRequestDto): Observable<any> {
    let params = new URLSearchParams('', new PlusSignQueryEncoder());
    this.setLanguage(params);

    let requestOptions = new RequestOptions();
    requestOptions.params = params;
    requestOptions.headers = this.getHeaders();

    let url = BackendApiConstants.baseUrl + BackendApiConstants.services.tenant.createWithFirstUser.name;
    console.log("url is "+url);
    console.log(createTenantdto);
    return this.http.post(url, createTenantdto, requestOptions);
  }

  public organizationAccountExist(organization: string): Observable<any> {
    let params = new URLSearchParams();
    params.set('organization', organization);
    this.setLanguage(params);

    let requestOptions = new RequestOptions();
    requestOptions.params = params;
    requestOptions.headers = this.getHeaders();

    let url = BackendApiConstants.baseUrl + BackendApiConstants.services.tenant.exist.name;

    return this.http.get(url, requestOptions);
  }

  private getHeaders() {
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
    return headers;
  }

  private setLanguage(params: URLSearchParams) {
    // Get from global location once implemented in UI
    params.set('lang', 'en');
  }
}
