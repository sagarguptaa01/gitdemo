import { TestBed, inject } from '@angular/core/testing';

import { ActivateAccountGuardService } from './activate-account-guard.service';
import { MockBackend } from '@angular/http/testing';
import { BaseRequestOptions, Http } from '@angular/http';
import { ActivatedRouteSnapshot, Router } from '@angular/router';
import { ActivateAccountService } from './activate-account.service';
import { Observable } from 'rxjs/Rx';
import { RouteConstants } from '../../../global/route-constants';

describe('ActivateAccountGuardService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        ActivateAccountGuardService,
        { provide: ActivateAccountService, useClass: MockActivateAccountService },
        { provide: Router, useClass: MockRouter }
      ]
    });
  });

  it('should be created', inject([ActivateAccountGuardService], (service: ActivateAccountGuardService) => {
    expect(service).toBeTruthy();
  }));

  it('should return true when the user\'s password is updated', inject([ActivateAccountGuardService, ActivateAccountService],
    (service: ActivateAccountGuardService, activateAccountService: ActivateAccountService) => {
    let username = 'username';
    let confirmation = 'confirmation';
    let route = new MockActivatedRouteSnapshot();
    route.setQueryParams({
      username: username,
      confirmation: confirmation
    });
    let activateAccountSpy = spyOn(activateAccountService, 'activateAccount').and.returnValue(Observable.of(true));

    let result = service.canActivate(route, null);

    expect(activateAccountSpy).toHaveBeenCalledWith(username, confirmation);
    expect(result).toBeTruthy();
  }));

  it('should navigate to /change-password with confirmation code in parameters when the user\'s password is not updated',
    inject([ActivateAccountGuardService, ActivateAccountService, Router],
    (service: ActivateAccountGuardService, activateAccountService: ActivateAccountService, router: Router) => {
    let username = 'username';
    let confirmationCode = 'confirmation-code';
    let route = new MockActivatedRouteSnapshot();
    route.setQueryParams({
      username: username,
      confirmation: confirmationCode
    });
    spyOn(activateAccountService, 'activateAccount').and.returnValue(Observable.of(false));
    let routerSpy = spyOn(router, 'navigate');

    service.canActivate(route, null).subscribe((result) => {

      expect(routerSpy).toHaveBeenCalledWith([RouteConstants.createPassword.path], { queryParams: { confirmation: confirmationCode} } );
    });
  }));

  it('should navigate to /error when activateAccount returns an error',
    inject([ActivateAccountGuardService, ActivateAccountService, Router],
    (service: ActivateAccountGuardService, activateAccountService: ActivateAccountService, router: Router) => {
    let username = 'username';
    let route = new MockActivatedRouteSnapshot();
    route.setQueryParams({username: username});
    spyOn(activateAccountService, 'activateAccount').and.returnValue(Observable.throw(''));
    let routerSpy = spyOn(router, 'navigateByUrl');

    service.canActivate(route, null).subscribe((result) => {

      expect(routerSpy).toHaveBeenCalledWith(RouteConstants.error.path);
    });
  }));
});

class MockActivatedRouteSnapshot extends ActivatedRouteSnapshot {
  queryParams: any;

    setQueryParams(queryParams: any): void {
      this.queryParams = queryParams;
    }
}

class MockActivateAccountService {
  activateAccount(username, confirmation) { }
}

class MockRouter {
  public navigate(url, options) { }
  public navigateByUrl(url: string) { }
}
