import { TestBed, inject } from '@angular/core/testing';

import { AccountRegistrationService } from './account-registration.service';
import { MockBackend } from '@angular/http/testing';
import { BaseRequestOptions, Http } from '@angular/http';
import { BackendApiConstants } from '../../../global/backend-api.constants';

describe('AccountRegistrationService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        MockBackend,
        BaseRequestOptions,
        {
          provide: Http,
          useFactory: (backendInstance: MockBackend, defaultOptions: BaseRequestOptions) => {
            return new Http(backendInstance, defaultOptions);
          },
          deps: [MockBackend, BaseRequestOptions]
        },
        AccountRegistrationService
      ]
    });
  });

  it('should be created', inject([AccountRegistrationService], (service: AccountRegistrationService) => {
    expect(service).toBeTruthy();
  }));

  describe('createOrganizationAccount', () => {
    it('should make a call to the createTenantWithFirstUser service endpoint', inject([AccountRegistrationService, MockBackend],
       (service: AccountRegistrationService, mockBackend: MockBackend) => {
      mockBackend.connections.subscribe(connection => {
        expect(connection.request.url).toContain(BackendApiConstants.services.tenant.createWithFirstUser.name);
      });

      service.createOrganizationAccount('', '', '', '', '', '', false, false);
    }));

    it('should include the passed firstName in the request body', inject([AccountRegistrationService, MockBackend],
       (service: AccountRegistrationService, mockBackend: MockBackend) => {
      let firstName = 'thisIsFirstName';

      mockBackend.connections.subscribe(connection => {
        expect(connection.request.url).toContain(`firstName=${firstName}`);
      });

      service.createOrganizationAccount(firstName, '', '', '', '', '', false, false);
    }));

    it('should include the passed lastName in the request body', inject([AccountRegistrationService, MockBackend],
       (service: AccountRegistrationService, mockBackend: MockBackend) => {
      let lastName = 'thisIsLastName';

      mockBackend.connections.subscribe(connection => {
        expect(connection.request.url).toContain(`lastName=${lastName}`);
      });
      
      service.createOrganizationAccount('', lastName, '', '', '', '', false, false);
    }));

    it('should include the passed company with the tenant domain extension appended to it in the request body', inject([AccountRegistrationService, MockBackend],
       (service: AccountRegistrationService, mockBackend: MockBackend) => {
      let company = 'thisIsOrganization';

      mockBackend.connections.subscribe(connection => {
        expect(connection.request.url).toContain(`organization=${company}`);
      });
      
      service.createOrganizationAccount('', '', company, '', '', '', false, false);
    }));

    it('should include the passed email in the request body', inject([AccountRegistrationService, MockBackend],
       (service: AccountRegistrationService, mockBackend: MockBackend) => {
      let email = 'thisIsEmail';

      mockBackend.connections.subscribe(connection => {
        expect(connection.request.url).toContain(`email=${email}`);
      });
      
      service.createOrganizationAccount('', '', '', '', email, '', false, false);
    }));
    it('should include the acceptPrivacyNotice in the request body', inject([AccountRegistrationService, MockBackend],
      (service: AccountRegistrationService, mockBackend: MockBackend) => {
     let acceptPrivacyPolicy = true;

     mockBackend.connections.subscribe(connection => {
       expect(connection.request.url).toContain(`exfoUserPrivacyNoticeAccepted=${acceptPrivacyPolicy}`);
     });
     service.createOrganizationAccount('', '', '', '', '', '', acceptPrivacyPolicy, false);
    }));
    it('should include the acceptLicenseAgreement in the request body', inject([AccountRegistrationService, MockBackend],
      (service: AccountRegistrationService, mockBackend: MockBackend) => {
     let acceptLicenseAgreement = true;

     mockBackend.connections.subscribe(connection => {
       expect(connection.request.url).toContain(`exfoSoftwareLicenseAgreementAccepted=${acceptLicenseAgreement}`);
     });
     service.createOrganizationAccount('', '', '', '', '', '', false, acceptLicenseAgreement);
    }));

  });


  describe('organizationAccountExist', () => {
    it('should make a call to the organizationAccountExist service endpoint', inject([AccountRegistrationService, MockBackend],
       (service: AccountRegistrationService, mockBackend: MockBackend) => {
      mockBackend.connections.subscribe(connection => {
        expect(connection.request.url).toContain(BackendApiConstants.services.tenant.exist.name);
      });

      service.organizationAccountExist('');
    }));

    it('should include the passed organization name in the request body', inject([AccountRegistrationService, MockBackend],
       (service: AccountRegistrationService, mockBackend: MockBackend) => {
      let orgName = 'thisIsOrganization';

      mockBackend.connections.subscribe(connection => {
        expect(connection.request.url).toContain(`organization=${orgName}`);
      });

      service.organizationAccountExist(orgName);
    }));
  });
});
