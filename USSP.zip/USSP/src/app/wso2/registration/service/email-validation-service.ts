import { Injectable, Inject } from '@angular/core';
import { Http, Headers, RequestOptions, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { BackendApiConstants } from '../../../global/backend-api.constants';
import { AuthHttp } from '../../../ussp/service/auth-http.service';
import { AuthenticationService } from '../../../ussp/auth/service/authentication.service';
import { OrgAccountProfileDto } from '../../../ussp/manage-org-account/service/dto/org-account-profile.dto';
import { EmailValidationDto } from './dto/email-validation.dto';

@Injectable()
export class EmailValidationService {

  constructor(private http: Http) { }

  public validateEmailAddress(emailAddress: string): Observable<any> {

    let url = BackendApiConstants.baseUrl + BackendApiConstants.services.tenant.validateEmail.Endpoint;
    let options = {
      headers: this.getHeaders()
    };
    let body = new EmailValidationDto(emailAddress);
    return this.http.post(url, JSON.stringify(body), options);
  }

  private getHeaders() {
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
    return headers;
  }

}