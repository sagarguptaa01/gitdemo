export class PropertyDto {
    key: string;
    value: string;
  }
  