import { UserProfileDto } from "../../../../ussp/user-profile/service/dto/user-profile.dto";
import { PropertyDto } from "./property.dto";

export class CreateTenantRequestDto {
    organization: string;
    country: string;
    adminUser: UserProfileDto;
    properties:PropertyDto[] = [];
  }
  