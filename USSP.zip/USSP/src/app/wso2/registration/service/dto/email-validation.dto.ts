export class EmailValidationDto {
  emailIdToValidate: string;

  constructor(emailIdToValidate: string) {
    this.emailIdToValidate = emailIdToValidate;
}
}
