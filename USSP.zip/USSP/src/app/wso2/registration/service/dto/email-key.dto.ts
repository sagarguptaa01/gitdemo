export class EmailEncryptionKeyDto {
  emailEncryptionKey: string;

  constructor(emailEncryptionKey: string) {
    this.emailEncryptionKey = emailEncryptionKey;
}
}
