export class AddTenantDto {
  admin: string;
  adminPassword: string;
  email: string;
  firstName: string;
  lastName: string;
  tenantDomain: string;
}
