import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs/Rx';
import { ActivateAccountService } from './activate-account.service';
import { RouteConstants } from '../../../global/route-constants';

@Injectable()
export class ActivateAccountGuardService implements CanActivate {

  constructor(private activateAccountService: ActivateAccountService, private router: Router) { }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
    let username = route.queryParams.username;
    let confirmation = route.queryParams.confirmation;
    return this.activateAccountService.activateAccount(username, confirmation)
      .map(response => this.handleResponse(response, confirmation))
      .catch(error => this.handleError(error));
  }

  private handleResponse(response, confirmation): boolean {
    if (response === false) {
      this.router.navigate([RouteConstants.createPassword.path], { queryParams: { confirmation: confirmation } } );
    }
    return response;
  }

  private handleError(error) {
    this.router.navigateByUrl(RouteConstants.error.path);
    return Observable.of(false);
  }
}
