import { Injectable } from '@angular/core';
import { BackendApiConstants } from '../../../global/backend-api.constants';
import { Http } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { IdentityRecoveryService } from '../../authentication/service/identity-recovery.service';

@Injectable()
export class ActivateAccountService {

  constructor(private http: Http, private identityRecoveryService: IdentityRecoveryService) { }

  activateAccount(username: string, confirmation: string): Observable<boolean> {
    let url = BackendApiConstants.baseUrl +
    BackendApiConstants.services.User.BaseEndpoint + username + BackendApiConstants.services.User.PasswordStatus.Endpoint;

    return this.http.get(url).mergeMap(response => this.handlePasswordStatus(response, confirmation));
  }

  private handlePasswordStatus(response, confirmation): Observable<boolean> {
    let isPasswordUpdated = this.isPasswordUpdated(response);
    if (isPasswordUpdated) {
      return this.identityRecoveryService.addUser(confirmation).map(
        result => {
          return isPasswordUpdated;
        });
    } else {
      return Observable.of(isPasswordUpdated);
    }
  }

  private isPasswordUpdated(response): boolean {
    let result = response.json();
    return result.status && result.status === BackendApiConstants.services.User.PasswordStatus.Updated;
  }
}
