import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-activate-account',
  templateUrl: './activate-account.component.html',
  styleUrls: ['./activate-account.component.css']
})
export class ActivateAccountComponent implements OnInit, OnDestroy {
  timeoutSeconds: number;
  private redirectTimer: NodeJS.Timer;

  constructor(private router: Router) {
  }

  ngOnInit() {
    this.timeoutSeconds = 5;
    this.redirectTimer = setInterval(() => this.tryRedirectToLoginPageCallback(), 1000);
  }

  ngOnDestroy() {
    this.destroyRedirectTimer();
  }

  private destroyRedirectTimer() {
    if (this.redirectTimer !== null) {
      clearInterval(this.redirectTimer);
      this.redirectTimer = null;
    }
  }


  private tryRedirectToLoginPageCallback(): void {
    if (this.redirectTimer === null) { return; }

    if (this.timeoutSeconds === 1) {
      this.timeoutSeconds = 0;
      this.destroyRedirectTimer();
      this.router.navigateByUrl('/home');
    } else if (this.timeoutSeconds > 0) {
      this.timeoutSeconds--;
    }
  }
}