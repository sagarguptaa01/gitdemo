import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivateAccountComponent } from './activate-account.component';
import { Router } from '@angular/router';

describe('ActivateAccountComponent', () => {
  let component: ActivateAccountComponent;
  let fixture: ComponentFixture<ActivateAccountComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ActivateAccountComponent],
      providers: [
        { provide: Router, useClass: MockRouter },
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivateAccountComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should redirect to login page after 5 seconds of timeout.', () => {
    let router = fixture.debugElement.injector.get(Router);
    let routerSpy = spyOn(router, 'navigateByUrl');

    jasmine.clock().install();

    component.ngOnInit();

    jasmine.clock().tick(5000);

    expect(routerSpy).toHaveBeenCalledWith('/home');

    jasmine.clock().uninstall();

    component.ngOnDestroy();
  });
});

class MockRouter {
  public navigateByUrl(url: string) { }
}
