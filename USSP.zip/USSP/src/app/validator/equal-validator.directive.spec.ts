import { EqualValidatorDirective } from './equal-validator.directive';
import { Component } from '@angular/core';
import { FormsModule, ValidatorFn, AbstractControl, NgForm} from '@angular/forms';
import { TestBed, async } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { dispatchEvent } from '@angular/platform-browser/testing/src/browser_util';


@Component({
  selector: 'test-component',
  template: `	
  					<form>
    <div>	
        <input class="" type="password" name="newPassword" id="newPassword" 
        [(ngModel)]="password" required validateEqual="confirmPassword" reverse="true"
        #newPassword="ngModel">
        <input class="" type="password" name="confirmPassword" id="confirmPassword" 
        [(ngModel)]="verifyPassword" required validateEqual="newPassword" reverse="false"
        #confirmPassword="ngModel"> 
    </div></form>`
})
export class TestComponent {
  public password: string;
  public verifyPassword: string;
};

describe('EqualValidatorDirective', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [FormsModule],
      declarations: [TestComponent, EqualValidatorDirective]
    })
  })
  it('should create an instance', () => {
    const directive = new EqualValidatorDirective("test", 'false');
    expect(directive).toBeTruthy();
  });
  it('Should the form is invalide when the two field is not same',  async(() => {
    let fixture = TestBed.createComponent(TestComponent);
    let comp = fixture.componentInstance;
    comp.password = "test";
    comp.verifyPassword = "test2";
    let debug = fixture.debugElement;
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      let form: NgForm = debug.children[0].injector.get(NgForm);
      expect(form.control.valid).toEqual(false);

    });
  }));
   it('Should the form is invalide when the two field is empty',  async(() => {
    let fixture = TestBed.createComponent(TestComponent);
    let comp = fixture.componentInstance;
    comp.password = "";
    comp.verifyPassword = "";
    let debug = fixture.debugElement;
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      let form: NgForm = debug.children[0].injector.get(NgForm);
      expect(form.control.valid).toEqual(false);

    });
  }));
  it('Should the form is valide when the two field is same',  async(() => {
    let fixture = TestBed.createComponent(TestComponent);
    let comp = fixture.componentInstance;
    comp.password = "test";
    comp.verifyPassword = "test";
    let debug = fixture.debugElement;
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      let form: NgForm = debug.children[0].injector.get(NgForm);
      expect(form.control.valid).toEqual(true);

    });
  }));
});
