
import { BrowserModule, Title } from '@angular/platform-browser';
import { NgModule, APP_INITIALIZER, CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app.routing.module';
import { ConfigService } from './global/config.service';
import { CountryService } from './global/country.service';
import { ErrorExtractorService } from './global/error-extractor.service';
import { NotFoundComponent } from './ussp/other-view/not-found/not-found.component';
import { AccountRegistrationService } from './wso2/registration/service/account-registration.service';
import { AccountRegistrationComponent } from './wso2/registration/account-registration/account-registration.component';
import { CreatePasswordComponent } from './wso2/authentication/view/create-password/create-password.component';
import { ResetPasswordComponent } from './wso2/authentication/view/reset-password/reset-password.component';
import { RecoverPasswordComponent } from './wso2/authentication/view/recover-password/recover-password.component';
// tslint:disable-next-line:max-line-length
import { RecoverPasswordConfirmationComponent } from './wso2/authentication/view/recover-password-confirmation/recover-password-confirmation.component';
import { EqualValidatorDirective } from './validator/equal-validator.directive';
// tslint:disable-next-line:max-line-length
import { AccountRegistrationConfirmationComponent } from './wso2/registration/account-registration-confirmation/account-registration-confirmation.component';
import { UserPortalComponent } from './ussp/user-portal/user-portal.component';
import { ChangePasswordSOAPTemplate } from './ussp/reset-password-from-portal/service/change-password.soap-template';
// tslint:disable-next-line:max-line-length
import { ResetPasswordFromPortalComponent } from './ussp/reset-password-from-portal/reset-password-from-portal.component';
import { UserAdminService } from './ussp/reset-password-from-portal/service/user-admin.service';
import { UserProfileComponent } from './ussp/user-profile/user-profile.component';
import { UserProfileService } from './ussp/user-profile/service/user-profile.service';
import { UserPortalHeaderComponent } from './ussp/user-portal/user-portal-header/user-portal-header.component';
import { UserPortalFooterComponent } from './ussp/user-portal/user-portal-footer/user-portal-footer.component';
import { UserPortalNavigationComponent } from './ussp/user-portal/user-portal-navigation/user-portal-navigation.component';
import { ManageOrgAccountComponent } from './ussp/manage-org-account/manage-org-account.component';
import { ManageOrgAccountService } from './ussp/manage-org-account/service/manage-org-account.service';
import { AuthGuardService } from './ussp/auth/service/auth-guard.service';
import { AuthenticationService } from './ussp/auth/service/authentication.service';
import { AuthorizationService } from './ussp/auth/service/authorization.service';
import { OAuthModule } from 'angular-oauth2-oidc';
import { ActivateAccountComponent } from './wso2/registration/activate-account/activate-account.component';
import { ActivateAccountGuardService } from './wso2/registration/service/activate-account-guard.service';
import { ActivateAccountService } from './wso2/registration/service/activate-account.service';
import { ErrorComponent } from './wso2/other-view/error/error.component';
import { IdentityRecoveryService } from './wso2/authentication/service/identity-recovery.service';
import { SetPasswordComponent } from './global/component/set-password/set-password.component';
import { ExfoAppsService } from './ussp/exfo-apps/service/exfo-apps.service';
import { ExfoAppsComponent } from './ussp/exfo-apps/view/exfo-apps/exfo-apps.component';
import { ExfoAppComponent } from './ussp/exfo-apps/view/exfo-app/exfo-app.component';
import { MandatoryClaimsComponent } from './wso2/registration/mandatory-claims/view/mandatory-claims/mandatory-claims.component';
import { MandatoryClaimComponent } from './wso2/registration/mandatory-claims/view/mandatory-claim/mandatory-claim.component';
import { ClaimService } from './wso2/registration/mandatory-claims/service/claim.service';
import { ClaimControlService } from './wso2/registration/mandatory-claims/service/claim.control.service';
import { WindowService } from './global/window.service';
import { AuthHttp } from './ussp/service/auth-http.service';
import { BlockUIModule } from 'ng-block-ui';
import { CreatePasswordGuardService } from './wso2/authentication/service/create-password-guard.service';
import { ResetPasswordGuardService } from './wso2/authentication/service/reset-password-guard.service';
import { EmailValidationService } from './wso2/registration/service/email-validation-service';
import { FilterHiddenClaimPipe } from './wso2/registration/mandatory-claims/view/mandatory-claims/filter-hidden-claim.pipe';
import { PasswordPolicyComponent } from './global/component/password-policy/password-policy.component';
@NgModule({
  declarations: [
    AppComponent,
    AccountRegistrationComponent,
    NotFoundComponent,
    UserPortalComponent,
    CreatePasswordComponent,
    EqualValidatorDirective,
    AccountRegistrationConfirmationComponent,
    ResetPasswordFromPortalComponent,
    UserPortalHeaderComponent,
    UserPortalFooterComponent,
    UserPortalNavigationComponent,
    AccountRegistrationConfirmationComponent,
    UserProfileComponent,
    ExfoAppsComponent,
    ExfoAppComponent,
    ManageOrgAccountComponent,
    ActivateAccountComponent,
    MandatoryClaimsComponent,
    MandatoryClaimComponent,
    ErrorComponent,
    RecoverPasswordComponent,
    RecoverPasswordConfirmationComponent,
    SetPasswordComponent,
    ResetPasswordComponent,
    FilterHiddenClaimPipe,
    PasswordPolicyComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    AppRoutingModule,
    OAuthModule.forRoot(),
    BlockUIModule
  ],
  providers: [
    AccountRegistrationService,
    CountryService,
    ConfigService,
    UserAdminService,
    {
      provide: APP_INITIALIZER,
      useFactory: initConfig,
      deps: [ConfigService],
      multi: true
    },
    AuthenticationService,
    AuthGuardService,
    ChangePasswordSOAPTemplate,
    UserProfileService,
    ManageOrgAccountService,
    IdentityRecoveryService,
    ErrorExtractorService,
    ExfoAppsService,
    Title,
    ActivateAccountGuardService,
    ActivateAccountService,
    AuthorizationService,
    ClaimService,
    ClaimControlService,
    WindowService,
    AuthHttp,
    CreatePasswordGuardService,
    ResetPasswordGuardService,
    EmailValidationService
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  bootstrap: [AppComponent]
})
export class AppModule { }

export function initConfig(config: ConfigService) {
  return () => config.load();
}
