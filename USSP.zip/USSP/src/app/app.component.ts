import { Component, OnInit } from '@angular/core';
import { OAuthService } from 'angular-oauth2-oidc';
import { NullValidationHandler } from 'angular-oauth2-oidc';
import { environment } from '../environments/environment';
import { Wso2ApiConstants } from './global/wso2-api.constants';
import { Title } from '@angular/platform-browser';
import { Router, NavigationEnd, ActivatedRoute } from '@angular/router';
import { RouteConstants } from './global/route-constants';
import { authConfig } from './global/auth.config';
import { BlockUI, NgBlockUI } from 'ng-block-ui';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  constructor(private oauthService: OAuthService,
              private router: Router,
              private activatedRoute: ActivatedRoute,
              private titleService: Title) {

    this.oauthService.configure(authConfig);

    this.oauthService.tokenValidationHandler = new NullValidationHandler();

    this.oauthService.tryLogin();
  }

  ngOnInit() {
    this.router.events
      .filter((event) => this.isNavigationEnd(event))
      .map(() => this.activatedRoute)
      .map((route) => this.getDeepestChild(route))
      .filter((route) => this.isPrimaryOutlet(route))
      .mergeMap((route) => route.data)
      .subscribe((event) => this.setTitle(event));
  }

  private isNavigationEnd(event): boolean {
    return event instanceof NavigationEnd;
  }

  private getDeepestChild(route) {
    while (route.firstChild) {
      route = route.firstChild;
    }
    return route;
  }

  private isPrimaryOutlet(route: ActivatedRoute) {
    return route.outlet === 'primary';
  }

  private setTitle(event): void {
    this.titleService.setTitle(event[RouteConstants.data.title] || RouteConstants.defaultTitle);
  }
}
