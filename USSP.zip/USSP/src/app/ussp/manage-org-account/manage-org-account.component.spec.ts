import { Observable } from 'rxjs/Rx';
import { Response, ResponseOptions } from '@angular/http';
import { CountryService } from '../../global/country.service';
import { CountryDto } from '../../global/dto/country.dto';
import { ConfigService } from '../../global/config.service';
import { ConfigKeys } from '../../global/config-keys.constants';
import { ErrorExtractorService } from '../../global/error-extractor.service';
import { ManageOrgAccountComponent } from './manage-org-account.component';
import { ManageOrgAccountService } from './service/manage-org-account.service';
import { OrgAccountProfileDto } from './service/dto/org-account-profile.dto';

describe('ManageOrgAccountComponent', () => {
  let component: ManageOrgAccountComponent;
  let configServiceMock: ConfigService;
  let countryServiceMock: CountryService;
  let manageOrgAccountServiceMock: ManageOrgAccountService;
  let errorExtractorServiceMock: ErrorExtractorService;

  class MockManageOrgAccountService extends ManageOrgAccountService {
    constructor() {
      super(null, null);
    }

    public getTenant(): Observable<any> {
      return Observable.of(new Response(new ResponseOptions({body: {"name":"Ang Test","address":"some street","postalCode":"some code","country":"Canada","contactNumber":"44419","email":"mike@hawkins.com"}})));
    }

    public updateTenant(dto: OrgAccountProfileDto): Observable<any> {
      return Observable.of();
    }
  }

  class MockCountryService extends CountryService {
    constructor() {
      super(null);
    }
  }

  class MockConfigService extends ConfigService {
    constructor() {
      super(null);
    }
  }

  class MockErrorExtractorService extends ErrorExtractorService {
    constructor() {
      super();
    }

    public getErrorMessage(data: any): string {
      return 'error';
    }
  }

  beforeEach(() => {
    manageOrgAccountServiceMock = new MockManageOrgAccountService();
    countryServiceMock = new MockCountryService();
    configServiceMock = new MockConfigService();
    errorExtractorServiceMock = new MockErrorExtractorService();
    component = new ManageOrgAccountComponent(manageOrgAccountServiceMock,
      countryServiceMock,
      configServiceMock,
      errorExtractorServiceMock);

    // Default values
    component.form = new Object();
    component.form.reset = function () { };

    component.countries = [new CountryDto('CA', 'CANADA')];
    component.model.country = 'CA';
    component.model.orgID = "";
    component.model.address = "";
    component.model.company = "";
    component.model.contactNumber = "";
    component.model.email = "";
    component.model.postalCode = ""; 
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should set the "message" to ""', () => {
    let firstCountriesCodes = ['US', 'CA'];
    let configServiceSpy = spyOn(configServiceMock, 'get').and.callFake(configKey => {
      if (configKey === ConfigKeys.firstCountries) {
        return firstCountriesCodes;
      }
    });

    let countryServiceSpy = spyOn(countryServiceMock, 'getCountryList').and.returnValue(Observable.of(['']));

    component.ngOnInit();
    expect(component.message).toEqual('');
  });

  it('should set the "isErrorMessage" flag to "false"', () => {
    expect(component.isErrorMessage).toBeFalsy();
  });

  it('should call CountryService to get the country list the first countries provided by Config', () => {
    let firstCountriesCodes = ['US', 'CA'];
    let configServiceSpy = spyOn(configServiceMock, 'get').and.callFake(configKey => {
      if (configKey === ConfigKeys.firstCountries) {
        return firstCountriesCodes;
      }
    });

    let countryServiceSpy = spyOn(countryServiceMock, 'getCountryList').and.returnValue(Observable.of(['']));

    component.ngOnInit();
    expect(countryServiceSpy).toHaveBeenCalledWith(['US', 'CA']);
  });

  it('should call ManageOrgAccountService to get the tenant profile at startup', () => {
    let firstCountriesCodes = ['US', 'CA'];
    let configServiceSpy = spyOn(configServiceMock, 'get').and.callFake(configKey => {
      if (configKey === ConfigKeys.firstCountries) {
        return firstCountriesCodes;
      }
    });

    let countryServiceSpy = spyOn(countryServiceMock, 'getCountryList').and.returnValue(Observable.of(['']));
    let spy = spyOn(manageOrgAccountServiceMock, 'getTenant').and.callThrough();

    component.ngOnInit();
    expect(spy).toHaveBeenCalledTimes(1);
  });

  it('should format the creation date at startup', () => {
    let firstCountriesCodes = ['US', 'CA'];
    let configServiceSpy = spyOn(configServiceMock, 'get').and.callFake(configKey => {
      if (configKey === ConfigKeys.firstCountries) {
        return firstCountriesCodes;
      }
    });
    let countryServiceSpy = spyOn(countryServiceMock, 'getCountryList').and.returnValue(Observable.of(['']));
    let spyTenant = spyOn(manageOrgAccountServiceMock, 'getTenant').and.callThrough();
    let spy = spyOn(component, 'formatTime').and.callThrough();
    component.ngOnInit();
    expect(spy).toHaveBeenCalledTimes(1);
  });

  describe('onSubmit', () => {
    describe('when the call to ManageOrgAccountService is successful', () => {
      it('should set the flag "isErrorMessage" to "false"', () => {
        spyOn(manageOrgAccountServiceMock, 'updateTenant').and.returnValue(Observable.of(true));
        component.onSubmit();
        expect(component.isErrorMessage).toBeFalsy();
      });

      it('should set the "message" to the "Saved"', () => {
        spyOn(manageOrgAccountServiceMock, 'updateTenant').and.returnValue(Observable.of(true));
        component.onSubmit();
        expect(component.message).toEqual('Saved');
      });
    });

    it('should use ManageOrgAccountService to update the tenant', () => {
      let spy = spyOn(manageOrgAccountServiceMock, 'updateTenant').and.callThrough();
      component.onSubmit();
      expect(spy).toHaveBeenCalledTimes(1);
    });

    describe('when the call to ManageOrgAccountService returns an error', () => {
      it('should set the flag "isErrorMessage" to "true"', () => {
        spyOn(manageOrgAccountServiceMock, 'updateTenant').and.returnValue(Observable.throw(new Response(new ResponseOptions({body: `<?xml version='1.0' encoding='UTF-8'?><soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"><soapenv:Body><soapenv:Fault><faultcode>soapenv:Server</faultcode><faultstring>Error in adding claims to the user.</faultstring><detail><ns:TenantMgtAdminServiceException xmlns:ns="http://services.mgt.tenant.carbon.wso2.org"><ns:TenantMgtAdminServiceException><axis2ns2:Message xmlns:axis2ns2="http://services.mgt.tenant.carbon.wso2.org">Error in adding claims to the user.</axis2ns2:Message></ns:TenantMgtAdminServiceException></ns:TenantMgtAdminServiceException></detail></soapenv:Fault></soapenv:Body></soapenv:Envelope>`}))));
        component.onSubmit();
        expect(component.isErrorMessage).toBeTruthy();
      });

      it('should set the "message" to the error', () => {
        spyOn(manageOrgAccountServiceMock, 'updateTenant').and.returnValue(Observable.throw(new Response(new ResponseOptions({body: `<?xml version='1.0' encoding='UTF-8'?><soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"><soapenv:Body><soapenv:Fault><faultcode>soapenv:Server</faultcode><faultstring>Error in adding claims to the user.</faultstring><detail><ns:TenantMgtAdminServiceException xmlns:ns="http://services.mgt.tenant.carbon.wso2.org"><ns:TenantMgtAdminServiceException><axis2ns2:Message xmlns:axis2ns2="http://services.mgt.tenant.carbon.wso2.org">Error in adding claims to the user.</axis2ns2:Message></ns:TenantMgtAdminServiceException></ns:TenantMgtAdminServiceException></detail></soapenv:Fault></soapenv:Body></soapenv:Envelope>`}))));
        component.onSubmit();
        expect(component.message).toEqual('error');
      });
    });

    it('should set the organization in the server data', () => {
      let expected = 'myOrganization';
      let spy = spyOn(manageOrgAccountServiceMock, 'updateTenant').and.callFake((dto) => {
        expect(dto.name).toBe(expected);
        return new Observable<any>(observer => observer.next(new Response(new ResponseOptions())));
      });
      component.model.company = expected;
      component.onSubmit();
    });

    it('should set the email in the server data', () => {
      let expected = 'myEmail@myOrg.com';
      let spy = spyOn(manageOrgAccountServiceMock, 'updateTenant').and.callFake((dto) => {
        expect(dto.email).toBe(expected);
        return new Observable<any>(observer => observer.next(new Response(new ResponseOptions())));
      });
      component.model.email = expected;
      component.onSubmit();
    });

    it('should set the address in the server data', () => {
      let expected = 'my address';
      let spy = spyOn(manageOrgAccountServiceMock, 'updateTenant').and.callFake((dto) => {
        expect(dto.address).toBe(expected);
        return new Observable<any>(observer => observer.next(new Response(new ResponseOptions())));
      });
      component.model.address = expected;
      component.onSubmit();
    });

    it('should not set the country in the server data', () => {
      let code = component.countries[0].code;
      let expected = component.countries[0].name;
      let spy = spyOn(manageOrgAccountServiceMock, 'updateTenant').and.callFake((dto) => {
        expect(dto.country).toBe(expected);
        return new Observable<any>(observer => observer.next(new Response(new ResponseOptions())));
      });
      component.model.country = code;
      component.onSubmit();
    });

    it('should not set the contact number in the server data', () => {
      let expected = 'my contact #';
      let spy = spyOn(manageOrgAccountServiceMock, 'updateTenant').and.callFake((dto) => {
        expect(dto.contactNumber).toBe(expected);
        return new Observable<any>(observer => observer.next(new Response(new ResponseOptions())));
      });
      component.model.contactNumber = expected;
      component.onSubmit();
    });

    it('should not set the postal code in the server data', () => {
      let expected = 'my postal #';
      let spy = spyOn(manageOrgAccountServiceMock, 'updateTenant').and.callFake((dto) => {
        expect(dto.postalCode).toBe(expected);
        return new Observable<any>(observer => observer.next(new Response(new ResponseOptions())));
      });
      component.model.postalCode = expected;
      component.onSubmit();
    });

    it('should not set the orgID in the server data', () => {
      let expected = '123123';
      let spy = spyOn(manageOrgAccountServiceMock, 'updateTenant').and.callFake((dto) => {
        expect(dto.orgID).toBe(expected);
        return new Observable<any>(observer => observer.next(new Response(new ResponseOptions())));
      });
      component.model.orgID = expected;
      component.onSubmit();
    });

  [{ modelElement: 'orgID',          updateTenantDtoElement: 'orgID',         value: ' orgID ',        expectedResult: 'orgID' },
   { modelElement: 'address',        updateTenantDtoElement: 'address',       value: ' address ',      expectedResult: 'address' },
   { modelElement: 'company',        updateTenantDtoElement: 'name',          value: ' 111111 ',       expectedResult: '111111' },
   { modelElement: 'contactNumber',  updateTenantDtoElement: 'contactNumber', value: ' 9999999999 ',   expectedResult: '9999999999' },
   { modelElement: 'email',          updateTenantDtoElement: 'email',         value: ' email ',        expectedResult: 'email' },
   { modelElement: 'postalCode',     updateTenantDtoElement: 'postalCode',    value: ' 111111 ',       expectedResult: '111111' }
  ].forEach(function (run) {
      it('should trim when "' + run.modelElement + '" have extra spaces', function () {
      // Arrange & Define Assert
      component.model[run.modelElement] = run.value;
      spyOn(manageOrgAccountServiceMock, 'updateTenant').and.callFake((dto) => {
        expect(dto[run.updateTenantDtoElement]).toBe(run.expectedResult);
        return new Observable<any>(observer => observer.next(new Response(new ResponseOptions())));
      });

      // Act
      component.onSubmit();
      });
    });

      [{modelElement: 'orgID',          updateTenantDtoElement: 'orgID',         value: undefined,           expectedResult: undefined },
      { modelElement: 'address',        updateTenantDtoElement: 'address',       value: null,                expectedResult: null },
      { modelElement: 'company',        updateTenantDtoElement: 'name',          value: undefined,           expectedResult: undefined },
      { modelElement: 'contactNumber',  updateTenantDtoElement: 'contactNumber', value: ' 9999999999 ',      expectedResult: '9999999999' },
      { modelElement: 'email',          updateTenantDtoElement: 'email',         value: ' test@exfo.com ',   expectedResult: 'test@exfo.com' },
      { modelElement: 'postalCode',     updateTenantDtoElement: 'postalCode',    value: '',                  expectedResult: '' }
     ].forEach(function (run) {
         it('should NOT trim when "' + run.modelElement + '" is NULL or UNDEFINED', function () {
         // Arrange & Define Assert
         component.model[run.modelElement] = run.value;
         spyOn(manageOrgAccountServiceMock, 'updateTenant').and.callFake((dto) => {
           expect(dto[run.updateTenantDtoElement]).toBe(run.expectedResult);
           return new Observable<any>(observer => observer.next(new Response(new ResponseOptions())));
         });
   
         // Act
         component.onSubmit();
         });
       }); 

       [{modelElement: 'orgID',          updateTenantDtoElement: 'orgID',         value: ' orgID ',        expectedResult: 'orgID' },
       { modelElement: 'address',        updateTenantDtoElement: 'address',       value: ' address ',      expectedResult: 'address' },
       { modelElement: 'company',        updateTenantDtoElement: 'name',          value: ' 111111 ',       expectedResult: '111111' },
       { modelElement: 'contactNumber',  updateTenantDtoElement: 'contactNumber', value: ' 9999999999 ',   expectedResult: '9999999999' },
       { modelElement: 'email',          updateTenantDtoElement: 'email',         value: ' email ',        expectedResult: 'email' },
       { modelElement: 'postalCode',     updateTenantDtoElement: 'postalCode',    value: ' 111111 ',       expectedResult: '111111' }
      ].forEach(function (run) {
          it('should set "' + run.modelElement + '" to its trimmed value after successful submit operation', function () {
          // Arrange & Define Assert
          component.model[run.modelElement] = run.value;
          spyOn(manageOrgAccountServiceMock, 'updateTenant').and.callFake((data) => {
            expect(data[run.updateTenantDtoElement]).toBe(run.expectedResult);
            return new Observable<any>(observer => observer.next(new Response(new ResponseOptions())));
          });
          
          // Act
          component.onSubmit();
          });
        }); 

  });
});
