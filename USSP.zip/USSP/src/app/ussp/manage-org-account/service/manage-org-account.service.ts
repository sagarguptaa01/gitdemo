import { Injectable, Inject } from '@angular/core';
import { Http, Headers, RequestOptions, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { BackendApiConstants } from '../../../global/backend-api.constants';
import { OrgAccountProfileDto } from './dto/org-account-profile.dto';
import { AuthenticationService } from '../../auth/service/authentication.service';
import { AuthHttp } from '../../service/auth-http.service';

@Injectable()
export class ManageOrgAccountService {

  constructor(private authHttp: AuthHttp, private authService: AuthenticationService) {}

  public getTenant(): Observable<any> {
    let requestOptions = new RequestOptions();
    requestOptions.headers = this.getHeaders();
    let url = BackendApiConstants.baseUrl + BackendApiConstants.services.tenant.getProfile.name;

    return this.authHttp.get(url, requestOptions);
  }

  private getHeaders() {
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
    headers.append('Authorization', `Bearer ${this.authService.getJwtToken()}`);
    return headers;
  }

  public updateTenant(dto: OrgAccountProfileDto): Observable<any> {
    let requestOptions = new RequestOptions();
    requestOptions.headers = this.getHeaders();
    let url = BackendApiConstants.baseUrl + BackendApiConstants.services.tenant.updateProfile.name;

    return this.authHttp.post(url, dto, requestOptions);
  }
}