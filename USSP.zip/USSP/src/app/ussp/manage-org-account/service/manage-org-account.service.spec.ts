import { TestBed, inject } from '@angular/core/testing';

import { ManageOrgAccountService } from './manage-org-account.service';
import { RequestOptions } from '@angular/http';
import { BackendApiConstants } from '../../../global/backend-api.constants';
import { AuthenticationService } from '../../auth/service/authentication.service';
import { OrgAccountProfileDto } from './dto/org-account-profile.dto';
import { AuthHttp } from '../../service/auth-http.service';
import { Observable } from 'rxjs/Rx';

describe('ManageOrgAccountService', () => {
  let service: ManageOrgAccountService;
  let authHttp: AuthHttp;
  let authService: AuthenticationService;

  beforeEach(() => {
    authHttp = new MockAuthHttp();
    authService = new MockAuthService();
    service = new ManageOrgAccountService(authHttp, authService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('getTenant', () => {
    it('should make a call to the USSP backend service endpoint', () => {
      let actualUrl: string;
      let authHttpGetSpy = spyOn(authHttp, 'get').and.callFake((url, options) => {
        actualUrl = url;
      });

      service.getTenant();

      expect(actualUrl).toContain(BackendApiConstants.baseUrl + BackendApiConstants.services.tenant.getProfile.name);
    });

    it('should include the jwt auth token in the request header', () => {
      const bearerTokenValue = 'BearerVALUE';
      spyOn(authService, 'getJwtToken').and.returnValue(bearerTokenValue);
      let actualOptions: RequestOptions;
      let authHttpGetSpy = spyOn(authHttp, 'get').and.callFake((url, options) => {
        actualOptions = options;
      });

      service.getTenant();

      let authHeader = actualOptions.headers.get('Authorization');
      expect(authHeader).toEqual('Bearer ' + bearerTokenValue);
    });
  });

  describe('updateTenant', () => {
    it('should make a call to the USSP backend service endpoint', () => {
      let actualUrl: string;
      let authHttpGetSpy = spyOn(authHttp, 'post').and.callFake((url, body, options) => {
        actualUrl = url;
      });

      service.updateTenant(new OrgAccountProfileDto());

      expect(actualUrl).toContain(BackendApiConstants.baseUrl + BackendApiConstants.services.tenant.getProfile.name);
    });

    it('should include the jwt auth token in the request header', () => {
      const bearerTokenValue = 'BearerVALUE';
      spyOn(authService, 'getJwtToken').and.returnValue(bearerTokenValue);
      let actualOptions: RequestOptions;
      let authHttpGetSpy = spyOn(authHttp, 'post').and.callFake((url, body, options) => {
        actualOptions = options;
      });

      service.updateTenant(new OrgAccountProfileDto());

      let authHeader = actualOptions.headers.get('Authorization');
      expect(authHeader).toEqual('Bearer ' + bearerTokenValue);
    });

    it('should send the OrgAccountProfileDto to the endpoint', () => {
      let dto = new OrgAccountProfileDto();
      dto.email = 'myEmail@myDomain.com';
      dto.name = 'My Tenant Name';
      dto.address = 'my tenant address';
      dto.postalCode = 'myPostalCode';
      dto.country = 'my country';
      dto.contactNumber = 'my number';

      let actualBody: OrgAccountProfileDto;
      spyOn(authHttp, 'post').and.callFake((url, body, options) => {
        actualBody = body;
      });
      service.updateTenant(dto);

      expect(actualBody).toEqual(dto);
    });
  });
});

class MockAuthService extends AuthenticationService {

  constructor() {
    super(null);
  }

  public getJwtToken(): string {
    return '';
  }
}

class MockAuthHttp extends AuthHttp {

  constructor() {
    super(null, null);
  }

  public post(url: string, body: any, options?: RequestOptions): Observable<any> {
    return Observable.of();
  }

  public get(url: string, options?: RequestOptions): Observable<any> {
    return Observable.of();
  }
}
