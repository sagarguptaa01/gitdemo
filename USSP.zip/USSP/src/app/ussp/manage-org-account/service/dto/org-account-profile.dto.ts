export class OrgAccountProfileDto {
    name: string;
    orgID: string;
    address: string;
    postalCode: string;
    country: string;
    contactNumber: string;
    email: string;
    creationTimestamp: string;
}