import { Component, OnInit, ViewChild } from '@angular/core';
import { Observable } from 'rxjs/Rx';

import { ConfigService } from '../../global/config.service';
import { ConfigKeys } from '../../global/config-keys.constants';
import { CountryDto } from '../../global/dto/country.dto';
import { CountryService } from '../../global/country.service';
import { ErrorExtractorService } from '../../global/error-extractor.service';
import { ManageOrgAccountModel } from './manage-org-account.model';
import { ManageOrgAccountService } from './service/manage-org-account.service';
import { OrgAccountProfileDto } from './service/dto/org-account-profile.dto';
import { Utils } from '../../global/utils';

@Component({
  selector: 'app-manage-org-account',
  templateUrl: './manage-org-account.component.html',
  styleUrls: ['./manage-org-account.component.css']
})
export class ManageOrgAccountComponent implements OnInit {
  model = new ManageOrgAccountModel();

  countries: CountryDto[];

  message: string;
  isErrorMessage: boolean;
  disableForm: boolean;

  orgNameRegex: string;
  addressRegex: string;
  postalCodeRegex: string;
  phoneRegex: string;
  emailRegex: string;

  orgNameMaxLength: string;
  addressMaxLength: string;
  postalCodeMaxLength: string;
  phoneMaxLength: string;
  emailMaxLength: string;

  @ViewChild('manageOrgAccountForm') form;

  constructor(private manageOrgAccountService: ManageOrgAccountService,
              private countryService: CountryService,
              private config: ConfigService,
              private errorService: ErrorExtractorService) { }

  ngOnInit() {
    this.disableForm = false;
    this.hideServerError();

    this.orgNameRegex         =     this.config.get(ConfigKeys.orgName.regex);
    this.addressRegex         =     this.config.get(ConfigKeys.address.regex);
    this.postalCodeRegex      =     this.config.get(ConfigKeys.postalCode.regex);
    this.phoneRegex           =     this.config.get(ConfigKeys.phoneNumber.regex);
    this.emailRegex           =     this.config.get(ConfigKeys.email.regex);

    this.orgNameMaxLength     =     this.config.get(ConfigKeys.orgName.maxLength);
    this.addressMaxLength     =     this.config.get(ConfigKeys.address.maxLength);
    this.postalCodeMaxLength  =     this.config.get(ConfigKeys.postalCode.maxLength);
    this.phoneMaxLength       =     this.config.get(ConfigKeys.phoneNumber.maxLength);
    this.emailMaxLength       =     this.config.get(ConfigKeys.email.maxLength);

    Observable.forkJoin(this.getCountries(), this.manageOrgAccountService.getTenant())
    .subscribe((results) => {
      this.countries = results[0];
      this.restoreData(results[1]);
    },
    error => {
      this.handleError(error);
      this.disableForm = true;
    });
  }

  onSubmit() {
    let dto: OrgAccountProfileDto = new OrgAccountProfileDto();
    dto.orgID = Utils.trim(this.model.orgID);
    dto.address = Utils.trim(this.model.address);
    dto.name = Utils.trim(this.model.company);
    dto.contactNumber = Utils.trim(this.model.contactNumber);
    dto.country = this.getCountryName(this.model.country);
    dto.email = Utils.trim(this.model.email);
    dto.postalCode = Utils.trim(this.model.postalCode);

    this.manageOrgAccountService.updateTenant(dto)
        .subscribe(
          response => this.onSubmitted(response),
          error => this.handleError(error)
        );
  }

  hideServerError() {
    this.message = '';
  }

  private getCountries(): Observable<CountryDto[]> {
    let firstCountries = this.config.get(ConfigKeys.firstCountries);
    return this.countryService.getCountryList(firstCountries);
  }

  private onSubmitted(response) {
    if (response) {
      this.trimWhiteSpacesInModel();
      this.resetForm();
      this.isErrorMessage = false;
      this.message = 'Saved';
    }
  }

  private handleError(error) {
    this.isErrorMessage = true;
    this.message = this.errorService.getErrorMessage(error);
  }

  private resetForm() {
    this.form.reset({
      address: this.model.address,
      organizationname: this.model.company,
      orgID: this.model.orgID,
      contactnumber: this.model.contactNumber,
      country: this.model.country,
      email: this.model.email,
      postalcode: this.model.postalCode,
      creationtime: this.model.creationTime
    });
  }

  private restoreData(data) {
    let dto: OrgAccountProfileDto = data.json();
    if (dto) {
      this.model.address = dto.address || '';
      this.model.company = dto.name || '';
      this.model.orgID = dto.orgID || '';
      this.model.contactNumber = dto.contactNumber || '';
      this.model.country = this.getCountryCode(dto.country);
      this.model.email = dto.email || '';
      this.model.postalCode = dto.postalCode || '';
      this.model.creationTime = this.formatTime(dto.creationTimestamp);
      this.resetForm();
    } else {
      this.disableForm = true;
      this.isErrorMessage = true;
      this.message = 'Your account is not linked to any organization account';
    }
  }

  private getCountryCode(countryName: string): string {
    let countryDto = null;
    if (countryName) {
      countryDto = this.countries.find(c => c.name === countryName);
    }
    return countryDto ? countryDto.code : '';
  }

  private getCountryName(countryCode: string): string {
    let country = this.countries.find(c => c.code === this.model.country);
    if (country !== undefined) {
      return country.name;
    }

    return '';
  }

  private formatTime(time: string): string {
    let d = new Date(time);
    // null time gives 0, invalid string gives NaN, both <= 0
    if (d.valueOf() > 0) {
      let day = this.addZeroPrefix(d.getUTCDate());
      let month = this.addZeroPrefix(d.getUTCMonth() + 1);
      let year = d.getUTCFullYear();
      let hour = this.addZeroPrefix(d.getUTCHours());
      let minute = this.addZeroPrefix(d.getUTCMinutes());
      let second = this.addZeroPrefix(d.getUTCSeconds());
      return `${year}-${month}-${day} ${hour}:${minute}:${second} UTC`;
    } else {
      return 'Invalid or not available';
    }
  }

  private addZeroPrefix(value: number): string {
    return `${value < 10 ? 0 : ''}${value}`;
  }

  private trimWhiteSpacesInModel() {
    this.model.orgID = Utils.trim(this.model.orgID);
    this.model.address = Utils.trim(this.model.address);
    this.model.company = Utils.trim(this.model.company);
    this.model.contactNumber = Utils.trim(this.model.contactNumber);
    this.model.email = Utils.trim(this.model.email);
    this.model.postalCode = Utils.trim(this.model.postalCode);
  }
}
