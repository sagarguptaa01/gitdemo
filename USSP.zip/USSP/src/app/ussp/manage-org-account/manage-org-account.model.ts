export class ManageOrgAccountModel {
    company: string;
    orgID: string;
    address: string;
    postalCode: string;
    country: string;
    contactNumber: string;
    email: string;
    creationTime: string;
}