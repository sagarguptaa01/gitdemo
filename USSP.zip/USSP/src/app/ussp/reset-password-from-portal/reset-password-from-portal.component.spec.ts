import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ResetPasswordFromPortalComponent } from './reset-password-from-portal.component';
import { UserAdminService } from './service/user-admin.service';
import { PasswordChangeModel } from './password-change.model';
import { ConfigService } from '../../global/config.service';
import { Observable } from 'rxjs/Rx';
import { Router, ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';
import { Response, ResponseOptions, ResponseType } from '@angular/http';
import { AuthenticationService } from '../auth/service/authentication.service';
import { WSO2UserInfo } from '../auth/model/wso2userInfo.model';
import { ErrorExtractorService } from '../../global/error-extractor.service';

describe('ResetPasswordFromPortalComponent', () => {
  let sut: ResetPasswordFromPortalComponent;

  let userAdminServiceMock: MockUserAdminService;
  let authServiceMock: MockAuthService;
  let errorService: MockErrorExtractorService;

  beforeEach(() => {
    userAdminServiceMock = new MockUserAdminService();
    authServiceMock = new MockAuthService();
    errorService = new MockErrorExtractorService();
    sut = new ResetPasswordFromPortalComponent(userAdminServiceMock, authServiceMock, errorService);
    sut.ngOnInit();
  });

  it('should create', () => {
    expect(sut).toBeTruthy();
  });

  it('should have a valid model', () => {
    expect(sut.passwordChangeModel).toBeTruthy();
  });

  describe('subscription', () => {
    describe('destroy', () => {
      it('should release the savePassword subscription', () => {
        sut.savePassword = new Subscription();
        sut.ngOnDestroy();
        expect(sut.savePassword.closed).toBeTruthy();
      });
    });
  });

  describe('Save', () => {
    beforeEach(() => {
      let userInfo = new WSO2UserInfo();
      spyOn(authServiceMock, 'getUserInfo').and.returnValue(userInfo);
    });

    it('should use UserAdminService to change password', () => {
      let password = 'this-is-password';
      sut.changePasswordForm = {
        value: {
          newPassword: password
        }
      };
      let changePasswordSpy = spyOn(userAdminServiceMock, 'changePassword').and.returnValue(Observable.of(null));

      sut.save();

      expect(sut.passwordChangeModel.newPassword).toEqual(password);
      expect(changePasswordSpy).toHaveBeenCalledWith(sut.passwordChangeModel);
    });

    describe('when the call to changePassword returns an error', () => {
      let password;

      beforeEach(() => {
        password = 'this-is-password';
        sut.changePasswordForm = {
          value: {
            newPassword: password
          }
        };
      });

      it('should show the errorMessage', () => {
        sut.isErrorMessage = false;
        let changePasswordSpy = spyOn(userAdminServiceMock, 'changePassword').and.returnValue(Observable.throw({ 'status': 404 }));
        sut.save();

        expect(sut.isErrorMessage).toBeTruthy();
      });

      it('should set the errorMessage', () => {
        let changePasswordSpy = spyOn(userAdminServiceMock, 'changePassword').and.returnValue(Observable.throw({ 'status': 404 }));
        sut.save();

        expect(sut.message).toEqual('error');
      });
    });

    describe('when the call to changePassword returns a success', () => {
      let password;

      beforeEach(() => {
        password = 'this-is-password';
        sut.changePasswordForm = {
          value: {
            newPassword: password
          }
        };
      });

      it('should show the success message', () => {
        sut.isErrorMessage = true;
        spyOn(userAdminServiceMock, 'changePassword').and.returnValue(Observable.of({ 'status': 200 }));
        sut.save();

        expect(sut.isErrorMessage).toBeFalsy();
      });

      it('should set the success message', () => {
        sut.isErrorMessage = true;
        spyOn(userAdminServiceMock, 'changePassword').and.returnValue(Observable.of({ 'status': 200 }));

        sut.save();

        expect(sut.message).toEqual('Saved');
      });
    });
  });
});

class MockUserAdminService extends UserAdminService {
  constructor() {
    super(null, null);
  }
  public changePassword(passwordChangeModel: PasswordChangeModel): Observable<any> {
    return Observable.of();
  }
}

class MockAuthService extends AuthenticationService {
  constructor() {
    super(null);
  }
}

class MockErrorExtractorService extends ErrorExtractorService {
  constructor() {
    super();
  }

  public getErrorMessage(data: any): string {
    return 'error';
  }
}

