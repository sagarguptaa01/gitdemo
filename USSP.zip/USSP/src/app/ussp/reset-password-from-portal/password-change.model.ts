export interface PasswordChangeModel {
    email: string;
    oldPassword: string;
    newPassword: string;
    token: string;
}
