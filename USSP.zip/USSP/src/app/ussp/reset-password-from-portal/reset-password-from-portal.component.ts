import { PasswordChangeModel } from './password-change.model';
import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';
import { UserAdminService } from './service/user-admin.service';
import { AuthenticationService } from '../auth/service/authentication.service';
import { ErrorExtractorService } from '../../global/error-extractor.service';

@Component({
  selector: 'app-reset-password-from-portal',
  templateUrl: './reset-password-from-portal.component.html',
  styleUrls: ['./reset-password-from-portal.component.css']
})

export class ResetPasswordFromPortalComponent implements OnInit, OnDestroy {

  @ViewChild('changePasswordForm') changePasswordForm;

  public passwordChangeModel: PasswordChangeModel;
  savePassword: Subscription;
  message: string;
  isErrorMessage: boolean;

  constructor(private userAdminService: UserAdminService,
              private authService: AuthenticationService,
              private errorService: ErrorExtractorService) {

  }

  ngOnInit() {
    this.passwordChangeModel = {
      token: '',
      email: '',
      oldPassword: '',
      newPassword: ''
    };
    this.hideMessages();
  }

  ngOnDestroy() {
    if (this.savePassword) {
      this.savePassword.unsubscribe();
    }
  }

  save() {
    this.passwordChangeModel.email = this.authService.getUserInfo().email;
    this.passwordChangeModel.newPassword = this.changePasswordForm.value.newPassword;
    this.savePassword = this.userAdminService.changePassword(this.passwordChangeModel)
      .subscribe(
        response =>  this.passwordUpdated(response),
        error => this.handleError(error)
      );
  }

  private passwordUpdated(response) {
    if (response) {
      this.isErrorMessage = false;
      this.message = 'Saved';
    }
  }

  protected handleError(error) {
    this.isErrorMessage = true;
    this.message = this.errorService.getErrorMessage(error);
  }

  public hideMessages() {
    this.message = '';
  }
}
