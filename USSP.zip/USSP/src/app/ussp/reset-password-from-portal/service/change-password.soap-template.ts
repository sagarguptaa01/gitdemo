import { Wso2ApiConstants } from '../../../global/wso2-api.constants';
import { Injectable } from '@angular/core';

@Injectable()
export class ChangePasswordSOAPTemplate {

    getContentTypeHeader(): string {
        return `text/xml;charset=UTF-8`;
    }

    getActionHeader(): string {
        return `urn:${Wso2ApiConstants.services.userAdminService.action.changePasswordByUser.soapAction}`;
    }

    getSoapBody(username: string, oldPassword: string, newPassword: string): string {
        return `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsd="http://org.apache.axis2/xsd">
            <soapenv:Header/>
            <soapenv:Body>
                <xsd:changePasswordByUser>
                    <xsd:userName>${this.encodeForXmlBody(username)}</xsd:userName>
                    <xsd:oldPassword>${this.encodeForXmlBody(oldPassword)}</xsd:oldPassword>
                    <xsd:newPassword>${this.encodeForXmlBody(newPassword)}</xsd:newPassword>
                </xsd:changePasswordByUser>
            </soapenv:Body>
        </soapenv:Envelope>`;
    }

    private encodeForXmlBody(parameter: string): string {
        parameter=parameter.replace(/&/g, '&amp;');
        parameter=parameter.replace(/>/g, '&gt;');
        parameter=parameter.replace(/</g, '&lt;');
        return parameter;
    }
}
