import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { Wso2ApiConstants } from '../../../global/wso2-api.constants';
import { ChangePasswordSOAPTemplate } from './change-password.soap-template'
import { PasswordChangeModel } from '../password-change.model'
import { AuthHttp } from '../../service/auth-http.service';

@Injectable()
export class UserAdminService {

  constructor(private authHttp: AuthHttp, private changePasswordSoapTemplate: ChangePasswordSOAPTemplate) {}

  public changePassword(passwordChangeModel: PasswordChangeModel): Observable<any> {
    let url = Wso2ApiConstants.proxyUrl + Wso2ApiConstants.services.baseEndpoint + Wso2ApiConstants.services.userAdminService.name;
    let body = this.changePasswordSoapTemplate.getSoapBody(passwordChangeModel.email,
                                                           passwordChangeModel.oldPassword,
                                                           passwordChangeModel.newPassword);
    let options = new RequestOptions();
    options.headers = this.getHeaders();

    return this.authHttp.post(url, body, options);
  }

  private getHeaders() {
    let headers = new Headers();

    headers.append('Content-Type', this.changePasswordSoapTemplate.getContentTypeHeader());
    headers.append('SOAPAction', this.changePasswordSoapTemplate.getActionHeader());
    headers.append('Accept', 'text/xml');

    return headers;
  }
}
