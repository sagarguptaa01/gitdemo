import { TestBed, inject } from '@angular/core/testing';
import { UserAdminService } from './user-admin.service';
import { RequestOptions } from '@angular/http';
import { Wso2ApiConstants } from '../../../global/wso2-api.constants';
import { ChangePasswordSOAPTemplate } from './change-password.soap-template';
import { PasswordChangeModel } from '../password-change.model'
import { AuthHttp } from '../../service/auth-http.service';
import { Observable } from 'rxjs/Rx';

describe('UserAdminService', () => {
  let service: UserAdminService;
  let authHttp: AuthHttp;
  let changePasswordSoapTemplate: ChangePasswordSOAPTemplate;

  beforeEach(() => {
    authHttp = new MockAuthHttp();
    changePasswordSoapTemplate = new MockSoapTemplate();
    service = new UserAdminService(authHttp, changePasswordSoapTemplate);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('changePassword', () => {

    it('should make a call to the userAdmin service endpoint', () => {
      let actualUrl: string;
      let authHttpGetSpy = spyOn(authHttp, 'post').and.callFake((url, body, options) => {
        actualUrl = url;
      });
      let passwordChangeModel: PasswordChangeModel = {
        token: 'asdf',
        email: 'dsfds',
        oldPassword: 'fdsfds',
        newPassword: 'dsfds'
      };

      service.changePassword(passwordChangeModel);

      expect(actualUrl).toContain(Wso2ApiConstants.services.userAdminService.name);
      });

    it('should include the passed PasswordChangeModel object in the request body', () => {
      let passwordChangeModel: PasswordChangeModel = {
        token: '123456',
        email: 'to@too.com',
        oldPassword: 'oldPassword',
        newPassword: 'newPassword'
      };
      let changePasswordSOAPTemplateSpy = spyOn(changePasswordSoapTemplate, 'getSoapBody');

      service.changePassword(passwordChangeModel);

      expect(changePasswordSOAPTemplateSpy.calls.mostRecent().args)
             .toEqual([passwordChangeModel.email, passwordChangeModel.oldPassword, passwordChangeModel.newPassword]);
    });
  });
});

class MockSoapTemplate extends ChangePasswordSOAPTemplate {

  getContentTypeHeader(): string {
        return '';
  }

  getActionHeader(): string {
        return '';
  }

  getSoapBody( email: string, oldpassword: string, newPassword: string): string {
    return '';
  }
}

class MockAuthHttp extends AuthHttp {

  constructor() {
    super(null, null);
  }

  public post(url: string, body: any, options?: RequestOptions): Observable<any> {
    return Observable.of();
  }

  public get(url: string, options?: RequestOptions): Observable<any> {
    return Observable.of();
  }
}
