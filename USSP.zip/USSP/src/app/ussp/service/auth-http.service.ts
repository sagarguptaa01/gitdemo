import { Injectable } from '@angular/core';
import { Http, ConnectionBackend, Response, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { AuthenticationService } from '../auth/service/authentication.service';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

@Injectable()
export class AuthHttp {

  constructor(private http: Http, private authService: AuthenticationService) { }

  public post(url: string, body: any, options?: RequestOptions): Observable<any> {
    return Observable.fromPromise(this.authService.authenticateOrRefreshToken())
                     .concatMap(isLoggedIn => this.postIfLoggedIn(isLoggedIn, url, body, options))
                     .catch(error => Observable.throw(error));
  }

  private postIfLoggedIn(isLoggedIn: boolean, url: string, body: any, options?: RequestOptions): Observable<any> {
    if (isLoggedIn) {
      return this.http.post(url, body, options);
    } else {
      return Observable.of(isLoggedIn);
    }
  }

  public get(url: string, options?: RequestOptions): Observable<any> {
    return Observable.fromPromise(this.authService.authenticateOrRefreshToken())
                     .concatMap(isLoggedIn => isLoggedIn && this.http.get(url, options));
  }

  private getIfLoggedIn(isLoggedIn: boolean, url: string, options?: RequestOptions): Observable<any> {
    if (isLoggedIn) {
      return this.http.get(url, options);
    } else {
      return Observable.of(isLoggedIn);
    }
  }
}
