import { TestBed, inject } from '@angular/core/testing';

import { AuthHttp } from './auth-http.service';
import { Http, BaseRequestOptions } from '@angular/http';
import { MockBackend } from '@angular/http/testing';
import { AuthenticationService } from '../auth/service/authentication.service';

describe('AuthHttp', () => {

  let mockBackend: MockBackend;
  let baseRequestOptions: BaseRequestOptions;
  let http: Http;
  let authService: AuthenticationService;
  let service: AuthHttp;

  beforeEach(() => {
    mockBackend = new MockBackend();
    baseRequestOptions = new BaseRequestOptions();
    http = new Http(mockBackend, baseRequestOptions);
    authService = new MockAuthService();
    service = new AuthHttp(http, authService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

class MockAuthService extends AuthenticationService {

  constructor() {
    super(null);
  }

  public getJwtToken(): string {
    return '';
  }
}
