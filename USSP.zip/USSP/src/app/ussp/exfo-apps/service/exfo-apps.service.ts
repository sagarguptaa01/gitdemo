import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { ExfoApp } from '../model/exfo-app.model';
import { Http } from '@angular/http';

@Injectable()
export class ExfoAppsService {

  constructor(private http: Http) { }

  public getExfoApps(): Observable<ExfoApp[]> {
    return this.http.get('../../assets/json/exfo-apps.json')
      .map(response => this.parseResponse(response).sort(this.compareAppsByName));
  }

  private parseResponse(response): ExfoApp[] {
    return response.json().map(app => new ExfoApp(app.name, app.logoPath, app.url));
  }

  private compareAppsByName(appA: ExfoApp, appB: ExfoApp) {
    let value = 0;
    if (appA.name < appB.name) {
      value = -1;
    } else if (appA.name > appB.name) {
      value = 1;
    }
    return value;
  }
}
