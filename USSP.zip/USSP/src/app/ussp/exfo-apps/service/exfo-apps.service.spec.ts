import { TestBed, inject } from '@angular/core/testing';

import { ExfoAppsService } from './exfo-apps.service';
import { MockBackend } from '@angular/http/testing';
import { BaseRequestOptions, Http, Response, ResponseOptions } from '@angular/http';

describe('ExfoAppsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        MockBackend,
        BaseRequestOptions,
        {
          provide: Http,
          useFactory: (backendInstance: MockBackend, defaultOptions: BaseRequestOptions) => {
            return new Http(backendInstance, defaultOptions);
          },
          deps: [MockBackend, BaseRequestOptions]
        },
      ExfoAppsService
      ]
    });
  });

  it('should be created', inject([ExfoAppsService], (service: ExfoAppsService) => {
    expect(service).toBeTruthy();
  }));

  describe('getExfoApps', () => {
    it('should return a list of ExfoApp built from the json file from assets', inject([ExfoAppsService, MockBackend],
      (service: ExfoAppsService,  mockBackend: MockBackend) => {
      let appName0 = 'poutine';
      let appPath0 = 'p/a/t/h';
      let appUrl0 = 'url0';
      let appName1 = 'sauce';
      let appPath1 = 'q/b/u/i';
      let appUrl1 = 'url1';
      let mockResponse =  [
        {name: appName0, logoPath: appPath0, url: appUrl0},
        {name: appName1, logoPath: appPath1, url: appUrl1},
      ];

      mockBackend.connections.subscribe((connection) => {
        connection.mockRespond(new Response(new ResponseOptions({
          body: JSON.stringify(mockResponse)
        })));
      });

      service.getExfoApps().subscribe( result => {
        expect(result.length).toEqual(2);
        expect(result[0].name).toEqual(appName0);
        expect(result[0].logoPath).toEqual(appPath0);
        expect(result[0].url).toEqual(appUrl0);
        expect(result[1].name).toEqual(appName1);
        expect(result[1].logoPath).toEqual(appPath1);
        expect(result[1].url).toEqual(appUrl1);
      });
    }));

    it('the list of ExfoApp should be in alphabetical order', inject([ExfoAppsService, MockBackend],
      (service: ExfoAppsService,  mockBackend: MockBackend) => {
      let appName1 = 'poutine';
      let appName2 = 'sauce';
      let appName0 = 'frites';
      let logoPath = '';
      let url = '';
      let mockResponse =  [
        {name: appName1, logoPath: logoPath, url: url},
        {name: appName2, logoPath: logoPath, url: url},
        {name: appName0, logoPath: logoPath, url: url}
      ];

      mockBackend.connections.subscribe((connection) => {
        connection.mockRespond(new Response(new ResponseOptions({
          body: JSON.stringify(mockResponse)
        })));
      });

      service.getExfoApps().subscribe( result => {
        expect(result[0].name).toEqual(appName0);
        expect(result[1].name).toEqual(appName1);
        expect(result[2].name).toEqual(appName2);
      });
    }));
  });
});
