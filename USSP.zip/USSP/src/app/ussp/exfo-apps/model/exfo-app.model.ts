export class ExfoApp {
    name: String;
    logoPath: String;
    url: String;

    constructor(name?: String, logoPath?: String, url?: String) {
        this.name = name;
        this.logoPath = logoPath;
        this.url = url;
    }
}
