import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Observable } from 'rxjs/Rx';
import { ExfoAppsComponent } from './exfo-apps.component';
import { ExfoAppsService } from '../../service/exfo-apps.service';
import { Component, Input } from '@angular/core';
import { ExfoApp } from '../../model/exfo-app.model';

describe('ExfoAppsComponent', () => {
  let component: ExfoAppsComponent;
  let fixture: ComponentFixture<ExfoAppsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        ExfoAppsComponent,
        MockExfoAppComponent
      ],
      providers: [
        { provide: ExfoAppsService, useClass: MockExfoAppsService }
      ]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExfoAppsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

class MockExfoAppsService {
  getExfoApps() {
    return Observable.of();
   }
}

@Component({
  selector: 'app-exfo-app',
  template: ''
})
class MockExfoAppComponent {
  @Input()
  exfoApp: ExfoApp;
}
