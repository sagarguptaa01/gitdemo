import { Component, OnInit } from '@angular/core';
import { ExfoAppsService } from '../../service/exfo-apps.service';
import { ExfoApp } from '../../model/exfo-app.model';
import { OnDestroy } from '@angular/core/src/metadata/lifecycle_hooks';

@Component({
  selector: 'app-exfo-apps',
  templateUrl: './exfo-apps.component.html',
  styleUrls: ['./exfo-apps.component.css']
})
export class ExfoAppsComponent implements OnInit, OnDestroy {

  exfoApps: ExfoApp[];

  constructor(private exfoAppsService: ExfoAppsService) { }

  ngOnInit() {
    this.exfoAppsService.getExfoApps().subscribe(exfoApps => {
      this.exfoApps = exfoApps;
    });
  }

  ngOnDestroy() {

  }

}
