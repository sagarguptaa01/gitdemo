import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExfoAppComponent } from './exfo-app.component';
import { ExfoApp } from '../../model/exfo-app.model';

describe('ExfoAppComponent', () => {
  let component: ExfoAppComponent;
  let fixture: ComponentFixture<ExfoAppComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExfoAppComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExfoAppComponent);
    component = fixture.componentInstance;
    component.exfoApp = new ExfoApp();
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
