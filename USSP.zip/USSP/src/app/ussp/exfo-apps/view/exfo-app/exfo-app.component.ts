import { Component, OnInit, Input } from '@angular/core';
import { ExfoApp } from '../../model/exfo-app.model';

@Component({
  selector: 'app-exfo-app',
  templateUrl: './exfo-app.component.html',
  styleUrls: ['./exfo-app.component.css']
})
export class ExfoAppComponent implements OnInit {

  @Input()
  exfoApp: ExfoApp;

  constructor() { }

  ngOnInit() {
  }

}
