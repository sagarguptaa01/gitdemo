import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Observable } from 'rxjs/Rx';
import { Response, ResponseOptions } from '@angular/http';

import { UserPortalNavigationComponent } from './user-portal-navigation.component';
import { AuthorizationService } from '../../auth/service/authorization.service';
import { WSO2UserInfo } from '../../auth/model/wso2userInfo.model';

describe('UserPortalNavigationComponent', () => {
  let component: UserPortalNavigationComponent;
  let fixture: ComponentFixture<UserPortalNavigationComponent>;
  let authServiceMock: MockAuthService;

  beforeEach(() => {
    authServiceMock = new MockAuthService();
    component = new UserPortalNavigationComponent(authServiceMock);
    component.ngOnInit();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should set default menu toggle class', () => {
    expect(component.menuToggleClass).toEqual('no-bullet menu menu-toggle');
  });

  it('should remove menu-toggle from toggle class when hambuger is click and menu is not open', () => {
    component.menuToggleClass = '';
    component.menuIsOpen = false;
    component.onHamburgerClick();

    expect(component.menuToggleClass).toEqual('no-bullet menu');
  });

  it('should add menu-toggle from toggle class when hambuger is click and menu is open', () => {
    component.menuToggleClass = '';
    component.menuIsOpen = true;
    component.onHamburgerClick();

    expect(component.menuToggleClass).toEqual('no-bullet menu menu-toggle');
  });

  describe('checkAccessToMenu', () => {
    it('should disable ManageOrganization if not allowed', () => {
      authServiceMock.org = new MockResponse(false);
      component.ngOnInit();
      expect(component.canManageOrganization).toEqual(false);
    });
    it('should disable ManageOrganization if not allowed', () => {
      authServiceMock.user = new MockResponse(false);
      component.ngOnInit();
      expect(component.canManageProfile).toEqual(false);
    });
    it('should disable ManageOrganization if not allowed', () => {
      authServiceMock.app = new MockResponse(false);
      component.ngOnInit();
      expect(component.canUseApplication).toEqual(false);
    });
    it('should enable ManageOrganization if allowed', () => {
      authServiceMock.org = new MockResponse(true);
      component.ngOnInit();
      expect(component.canManageOrganization).toEqual(true);
    });
    it('should enable ManageOrganization if allowed', () => {
      authServiceMock.user = new MockResponse(true);
      component.ngOnInit();
      expect(component.canManageProfile).toEqual(true);
    });
    it('should enable ManageOrganization if allowed', () => {
      authServiceMock.app = new MockResponse(true);
      component.ngOnInit();
      expect(component.canUseApplication).toEqual(true);
    });
  });
});

class MockResponse {
  value: boolean;

  constructor(value) {
    this.value = value;
  }

  json() {
    return {
      isUserAuthorizedResponse: {
        return: this.value
      }
    };
  }
}

class MockAuthService extends AuthorizationService {

  public user = new MockResponse(false);
  public org = new MockResponse(false);
  public app = new MockResponse(false);

  constructor() {
    super(null, null);
  }

  public canAccessUserProfile() {
    return Observable.of(this.user);
  }

  public canAccessOrgProfile() {
    return Observable.of(this.org);
  }

  public canAccessApplications() {
    return Observable.of(this.app);
  }
}

