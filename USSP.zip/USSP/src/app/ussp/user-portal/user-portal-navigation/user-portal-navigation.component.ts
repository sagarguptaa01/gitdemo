import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { environment } from '../../../../environments/environment';
import { AuthorizationService } from '../../auth/service/authorization.service';

@Component({
  selector: 'app-user-portal-navigation',
  templateUrl: './user-portal-navigation.component.html',
  styleUrls: ['./user-portal-navigation.component.css']
})
export class UserPortalNavigationComponent implements OnInit {

  menuIsOpen: Boolean;
  menuToggleClass: String;
  canManageProfile: Boolean;
  canUseApplication: Boolean;
  canManageOrganization: Boolean;

  constructor(private authService: AuthorizationService) { }

  onHamburgerClick() {
    this.menuIsOpen = !this.menuIsOpen;
    if (this.menuIsOpen) {
      this.menuToggleClass = 'no-bullet menu';
    } else {
      this.menuToggleClass = 'no-bullet menu menu-toggle';
    }
  }

  toggleNavigationBar(){
    this.onHamburgerClick();
  }
  ngOnInit() {
    this.canManageOrganization = false;
    this.menuIsOpen = false;
    this.canManageProfile = false;
    this.canUseApplication = false;
    this.canManageOrganization = false;
    this.menuToggleClass = 'no-bullet menu menu-toggle';

    Observable.forkJoin(this.authService.canAccessUserProfile(),
                        this.authService.canAccessApplications(),
                        this.authService.canAccessOrgProfile()
                      ).subscribe(data => {
                        this.canManageProfile = this.getAuthorization(data[0]);
                        this.canUseApplication = this.getAuthorization(data[1]);
                        this.canManageOrganization = this.getAuthorization(data[2]);
                      });
  }

  
  getAuthorization(data): Boolean {
    let response = data.json();
    return response.isUserAuthorizedResponse.return;
  }
}
