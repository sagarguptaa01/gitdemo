import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Observable } from 'rxjs/Rx';
import { Response, ResponseOptions } from '@angular/http';

import { UserPortalComponent } from './user-portal.component';
import { APP_BASE_HREF } from '@angular/common';
import { RouterTestingModule } from '@angular/router/testing';
import { UserProfileService } from '../user-profile/service/user-profile.service';
import { Component } from '@angular/core';
import { ExfoAppsComponent } from '../exfo-apps/view/exfo-apps/exfo-apps.component';
import { ExfoAppComponent } from '../exfo-apps/view/exfo-app/exfo-app.component';


describe('UserPortalComponent', () => {
  let component: UserPortalComponent;
  let fixture: ComponentFixture<UserPortalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        UserPortalComponent,
        MockUserPortalHeaderComponent,
        MockUserPortalFooterComponent,
        MockUserPortalNavigationComponent,
        ExfoAppsComponent,
        ExfoAppComponent
      ],
      providers: [
        { provide: APP_BASE_HREF, useValue: '' },
        { provide: UserProfileService, useClass: MockUserProfileService }
      ],
      imports: [RouterTestingModule]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserPortalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

});

class MockUserProfileService {
  public getUserName(): Observable<any> {
    return Observable.of();
  }
}

@Component({
  selector: 'app-user-portal-header',
  template: ''
})
class MockUserPortalHeaderComponent {

}

@Component({
  selector: 'app-user-portal-footer',
  template: ''
})
class MockUserPortalFooterComponent {

}

@Component({
  selector: 'app-user-portal-navigation',
  template: ''
})
class MockUserPortalNavigationComponent {

}
