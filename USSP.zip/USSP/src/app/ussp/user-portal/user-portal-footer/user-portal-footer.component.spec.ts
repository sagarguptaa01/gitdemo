import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserPortalFooterComponent } from './user-portal-footer.component';
import { ConfigService } from '../../../global/config.service';
import { ConfigKeys } from '../../../global/config-keys.constants';
import { Component, Input } from '@angular/core';

describe('UserPortalFooterComponent', () => {
  let component: UserPortalFooterComponent;
  let fixture: ComponentFixture<UserPortalFooterComponent>;
  let configService: ConfigService;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserPortalFooterComponent,
        MockUserPortalFooterComponent ],
	    providers: [
        { provide: ConfigService, useClass: MockConfigService }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserPortalFooterComponent);
    component = fixture.componentInstance;
    configService  = fixture.debugElement.injector.get(ConfigService);
    //fixture.detectChanges();
  });

  it('should be created', () => {
    fixture.detectChanges();
    expect(component).toBeTruthy();
  });
  it('should get the user privacy notice link from the Config', () => {

    let expectedUserPrivacyLink = 'UserPrivacyLink';
    spyOn(configService, 'get').and.callFake(configKey => {
      if (configKey === ConfigKeys.userPrivacyNotice) {
        return expectedUserPrivacyLink;
      }
    });
   fixture.detectChanges();
   expect(component.userPrivacyNoticeLink).toEqual(expectedUserPrivacyLink);
  });
});
class MockConfigService {
  public get(key: string) { }
}
@Component({
  selector: 'app-user-portal-footer',
  template: '',
})
class MockUserPortalFooterComponent {
  @Input() model; 
}

