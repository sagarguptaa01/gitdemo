import { Component, OnInit } from '@angular/core';
import { ConfigService } from '../../../global/config.service';
import { ConfigKeys } from '../../../global/config-keys.constants';

@Component({
  selector: 'app-user-portal-footer',
  templateUrl: './user-portal-footer.component.html',
  styleUrls: ['./user-portal-footer.component.css']
})
export class UserPortalFooterComponent implements OnInit {  
  userPrivacyNoticeLink: string;
  constructor(private configService: ConfigService) { }

  ngOnInit() {
    this.userPrivacyNoticeLink = this.configService.get(ConfigKeys.userPrivacyNotice);
  }

}
