import { ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { UserPortalHeaderComponent } from './user-portal-header.component';
import { Observable } from 'rxjs/Rx';
import { AuthenticationService } from '../../auth/service/authentication.service';
import { WSO2UserInfo } from '../../auth/model/wso2userInfo.model';
import { Router } from '@angular/router';
import { WindowService } from '../../../global/window.service';

describe('UserPortalHeaderComponent', () => {
  let component: UserPortalHeaderComponent;
  let fixture: ComponentFixture<UserPortalHeaderComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ UserPortalHeaderComponent ],
      providers: [
        { provide: AuthenticationService, useClass: MockAuthService },
        { provide: WindowService, useClass: MockWindowService },
        { provide: Router, useClass: MockRouter }
      ]
    });
  });

  describe('UserPortalHeaderComponent', () => {
    beforeEach(() => {
      fixture = TestBed.createComponent(UserPortalHeaderComponent);
      component = fixture.componentInstance;
    });

    describe('ngOnInit', () => {
      it('should assign first name to given name', inject([AuthenticationService], (authServiceMock: AuthenticationService) => {
        let expectedName = 'test';
        let userInfo = new WSO2UserInfo();
        userInfo.firstName = expectedName;
        component.givenName = userInfo.firstName;

        spyOn(authServiceMock, 'getUserInfoAsync').and.returnValue(Observable.of(userInfo));

        component.ngOnInit();
        component.ngOnDestroy();

        expect(component.givenName).toBe(expectedName);
      }));
    });

    describe('logOut', () => {
      it('should use authService to log out', inject([AuthenticationService, WindowService], (authServiceMock: AuthenticationService, windowService: WindowService) => {
        let window = {
          location: {
            origin: ''
          }
        };

        spyOn(authServiceMock, 'getUserInfoAsync').and.returnValue(Observable.of(new WSO2UserInfo()));
        spyOn(windowService, 'getWindow').and.returnValue(window);
        let logOutSpy = spyOn(authServiceMock, 'logOut');

        component.ngOnInit();
        component.logOut();
        component.ngOnDestroy();

        expect(logOutSpy).toHaveBeenCalled();
      }));
    });
  });
});

class MockAuthService {
  logOut(): void { }

  getUserInfoAsync(): Observable<WSO2UserInfo> {
    return Observable.of<WSO2UserInfo>();
  }
}

class MockRouter {
  routerState = {
    snapshot : {
      url: ''
    }
  };
}

class MockWindowService {
  public getWindow() {}
}
