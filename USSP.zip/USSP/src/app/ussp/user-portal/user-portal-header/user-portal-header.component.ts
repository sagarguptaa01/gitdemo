import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../../auth/service/authentication.service';
import { WindowService } from '../../../global/window.service';
import { Router } from '@angular/router';
import { OnDestroy } from "@angular/core";
import { ISubscription } from "rxjs/Subscription";

declare function require(moduleName: string): any;
const { version: appVersion } = require('../../../../../package.json');

@Component({
  selector: 'app-user-portal-header',
  templateUrl: './user-portal-header.component.html',
  styleUrls: ['./user-portal-header.component.css']
})
export class UserPortalHeaderComponent implements OnInit,OnDestroy {

  appVersion: string;
  givenName: string;
  private subscription: ISubscription;

  constructor(private authService: AuthenticationService,
              private windowService: WindowService,
              private router: Router) { }

  ngOnInit() {
    this.appVersion = appVersion;
    this.subscription = this.authService.getUserInfoAsync().subscribe(
      (value) => this.givenName = value.firstName
    )
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  logOut() {
    let callback = this.windowService.getWindow().location.origin + this.router.routerState.snapshot.url;
    this.authService.logOut(callback);
  }
}
