export class WSO2UserInfo {
    constructor() {
        this.roles = [];
    }
    userName: string;
    userId: string;
    firstName: string;
    lastName: string;
    country: string;
    company: string;
    email: string;
    roles: string[];
    workPhone: string;
    mobilePhone: string;
    organization: string;
}