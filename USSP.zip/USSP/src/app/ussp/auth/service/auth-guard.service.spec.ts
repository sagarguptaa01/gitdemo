import { TestBed, inject } from '@angular/core/testing';
import { AuthGuardService } from './auth-guard.service';
import { AuthenticationService } from './authentication.service';
import { Router, RouterStateSnapshot } from '@angular/router';
import { OAuthService } from 'angular-oauth2-oidc';
import { UserProfileService } from '../../user-profile/service/user-profile.service';
import { WindowService } from '../../../global/window.service';

describe('AuthGuardService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        AuthGuardService,
        { provide: AuthenticationService, useClass: MockAuthService },
        { provide: WindowService, useClass: MockWindowService }
      ]
    });
  });

  it('should be created', inject([AuthGuardService],
    (service: AuthGuardService) => {
    expect(service).toBeTruthy();
  }));

  describe('canActivate', () => {
    let mockSnapshot: RouterStateSnapshot;
    mockSnapshot = jasmine.createSpyObj<RouterStateSnapshot>('RouterStateSnapshot', ['toString']);

    it('should authenticate', inject([AuthGuardService, AuthenticationService, WindowService],
      (service: AuthGuardService, authService: AuthenticationService, windowService: WindowService) => {
      let origin = 'http://origin:4200';
      let window = {
        location: {
          origin: origin
        }
      };
      spyOn(windowService, 'getWindow').and.returnValue(window);
      let url = '/home/user-profile';
      mockSnapshot.url = url;
      let authServiceSpy = spyOn(authService, 'authenticate');

      service.canActivate(null, mockSnapshot);

      expect(authServiceSpy).toHaveBeenCalledWith(origin + url);
    }));
  });

  describe('canActivateChild', () => {
    it('should authenticate', inject([AuthGuardService, AuthenticationService],
      (service: AuthGuardService, authService: AuthenticationService) => {
      let authServiceSpy = spyOn(authService, 'authenticateOrRefreshToken');

      service.canActivateChild(null, null);

      expect(authServiceSpy).toHaveBeenCalled();
    }));
  });

});

class MockAuthService {
  authenticate(callback: string) { }
  authenticateOrRefreshToken() { }
}

class MockWindowService {
  getWindow() { }
}
