import { Injectable } from '@angular/core';
import { AuthenticationService } from './authentication.service';
import { CanActivate, RouterStateSnapshot, ActivatedRouteSnapshot, CanActivateChild } from '@angular/router';
import { Observable } from 'rxjs/Rx';
import { WindowService } from '../../../global/window.service';

@Injectable()
export class AuthGuardService implements CanActivate, CanActivateChild {

  constructor(private authService: AuthenticationService, private windowService: WindowService) { }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | Observable<boolean> | Promise<boolean> {
    let callback = this.windowService.getWindow().location.origin + state.url;
    return this.authService.authenticate(callback);
  }

  canActivateChild(childRoute: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | Observable<boolean> | Promise<boolean> {
    return this.authService.authenticateOrRefreshToken();
  }
}
