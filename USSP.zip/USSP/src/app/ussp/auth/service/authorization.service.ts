import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { Wso2ApiConstants } from '../../../global/wso2-api.constants';
import { AuthenticationService } from '../../auth/service/authentication.service';

@Injectable()
export class AuthorizationService {

  constructor(private http: Http, private authService: AuthenticationService) {}

  public canAccessUserProfile() {
    return this.isUserAuthorized(this.authService.getUserInfo().userName, '/permission/admin/ussp/user_profile');
  }

  public canAccessOrgProfile() {
    return this.isUserAuthorized(this.authService.getUserInfo().userName, '/permission/admin/ussp/org_profile');
  }

  public canAccessApplications() {
    return this.isUserAuthorized(this.authService.getUserInfo().userName, '/permission/admin/ussp/applications');
  }

  private isUserAuthorized(username: String, permission: String): Observable<any> {
    let body =
        `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="http://service.ws.um.carbon.wso2.org">
            <soapenv:Header/>
            <soapenv:Body>
            <ser:isUserAuthorized>
                <ser:userName>${this.removeTenantFromUserName(username)}</ser:userName>
                <ser:resourceId>${permission}</ser:resourceId>
                <ser:action>ui.execute</ser:action>
            </ser:isUserAuthorized>
            </soapenv:Body>
        </soapenv:Envelope>`;

    let url = Wso2ApiConstants.proxyAuthorizationUrl + Wso2ApiConstants.services.baseEndpoint + Wso2ApiConstants.services.remoteAuthorizationManagerService.name;
    let headers = new Headers();
    headers.append('Content-Type', 'text/xml');
    headers.append('SOAPAction', `"urn:${Wso2ApiConstants.services.remoteAuthorizationManagerService.actionIsUserAuthorized}"`);
    headers.append('Authorization', `Bearer ${this.authService.getJwtToken()}`);
    let options = { headers: headers };

    return this.http.post(url, body, options);
  }

  private removeTenantFromUserName(userName: String): String {
    let parts = userName.split('@');  
    return `${parts[0]}@${parts[1]}`;
  }
}