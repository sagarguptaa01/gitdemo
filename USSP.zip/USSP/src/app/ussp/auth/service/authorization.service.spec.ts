import { TestBed, inject } from '@angular/core/testing';
import { BaseRequestOptions, Http } from '@angular/http';
import { MockBackend } from '@angular/http/testing';

import { AuthorizationService } from './authorization.service';
import { AuthenticationService } from './authentication.service';
import { OAuthService } from 'angular-oauth2-oidc';
import { AuthConstants } from './auth.constants';
import { Wso2ApiConstants } from '../../../global/wso2-api.constants';

describe('AuthorizationService', () => {
  let mockAuthService: MockAuthService;

  beforeEach(() => {
    mockAuthService = new MockAuthService();
    TestBed.configureTestingModule({
      providers: [
        MockBackend,
        BaseRequestOptions,
        {
          provide: Http,
          useFactory: (backendInstance: MockBackend, defaultOptions: BaseRequestOptions) => {
            return new Http(backendInstance, defaultOptions);
          },
          deps: [MockBackend, BaseRequestOptions]
        },
        { provide: AuthenticationService, useValue: mockAuthService },
        AuthorizationService
      ]
    });
  });

  it('should be created', inject([AuthorizationService], (service: AuthorizationService) => {
    expect(service).toBeTruthy();
  }));

  describe('canAccessApplications', () => {
      it('should call the secured endpoint', inject([AuthorizationService, MockBackend], (service: AuthorizationService, mockBackend: MockBackend) => {
        mockBackend.connections.subscribe(connection => {
            expect(connection.request.url).toContain(Wso2ApiConstants.proxyAuthorizationUrl + Wso2ApiConstants.services.baseEndpoint + Wso2ApiConstants.services.remoteAuthorizationManagerService.name);
          });
          service.canAccessApplications();          
      }));
      it('should query the permission', inject([AuthorizationService, MockBackend], (service: AuthorizationService, mockBackend: MockBackend) => {
        mockBackend.connections.subscribe(connection => {
            expect(connection.request.getBody()).toContain('/permission/admin/ussp/applications');
          });
          service.canAccessApplications();
      }));
  });

  describe('canAccessUserProfile', () => {
    it('should call the secured endpoint', inject([AuthorizationService, MockBackend], (service: AuthorizationService, mockBackend: MockBackend) => {
        mockBackend.connections.subscribe(connection => {
            expect(connection.request.url).toContain(Wso2ApiConstants.proxyAuthorizationUrl + Wso2ApiConstants.services.baseEndpoint + Wso2ApiConstants.services.remoteAuthorizationManagerService.name);
          });
          service.canAccessUserProfile();          
      }));
      it('should query the permission', inject([AuthorizationService, MockBackend], (service: AuthorizationService, mockBackend: MockBackend) => {
        mockBackend.connections.subscribe(connection => {
            expect(connection.request.getBody()).toContain('/permission/admin/ussp/user_profile');
          });
          service.canAccessUserProfile();
      }));
  });

  describe('canAccessOrgProfile', () => {
    it('should call the secured endpoint', inject([AuthorizationService, MockBackend], (service: AuthorizationService, mockBackend: MockBackend) => {
        mockBackend.connections.subscribe(connection => {
            expect(connection.request.url).toContain(Wso2ApiConstants.proxyAuthorizationUrl + Wso2ApiConstants.services.baseEndpoint + Wso2ApiConstants.services.remoteAuthorizationManagerService.name);
          });
          service.canAccessOrgProfile();          
      }));
      it('should query the permission', inject([AuthorizationService, MockBackend], (service: AuthorizationService, mockBackend: MockBackend) => {
        mockBackend.connections.subscribe(connection => {
            expect(connection.request.getBody()).toContain('/permission/admin/ussp/org_profile');
          });
          service.canAccessOrgProfile();
      }));
  });
        
});

class MockAuthService {
    public getJwtToken(): string {
      return '{}';
    }

    public getUserInfo() {
        return {userName: 'user@email.com@tenant.exfo'};
    }
  }