import { Injectable } from '@angular/core';
import { OAuthService } from 'angular-oauth2-oidc';
import { AuthConstants } from './auth.constants';
import { WSO2UserInfo } from '../model/wso2userInfo.model';
import { Observable } from 'rxjs/Observable';
import { BehaviorSubject } from 'rxjs';

@Injectable()
export class AuthenticationService {

  private userInfo: BehaviorSubject<WSO2UserInfo>;

  constructor(private oAuthService: OAuthService) {
    this.userInfo = new BehaviorSubject<WSO2UserInfo>(new WSO2UserInfo())
  }

  public authenticate(callback?: string): boolean {
    if (callback !== undefined) {
      this.oAuthService.redirectUri = this.remove_hash_from_url(callback);
    }

    let isLoggedIn = this.validateLoginStatus();
    if (!isLoggedIn) {
      this.oAuthService.initImplicitFlow();
    }
    return isLoggedIn;
  }

  public async authenticateOrRefreshToken(): Promise<boolean> {
    let isLoggedIn = this.authenticate();
    if (isLoggedIn) {
      isLoggedIn = await this.refreshAuthenticationToken();
    }
    return isLoggedIn;
  }

  public validateLoginStatus(): boolean {
    if (this.oAuthService.hasValidAccessToken()) {
      return true;
    } else {
      this.clearLoginData();
      return false;
    }
  }

  public getHeaderAuthorization(): string {
    return 'Bearer ' + this.getAuthToken();
  }

  public getAuthToken(): string {
    return this.oAuthService.getAccessToken();
  }

  public logOut(callback?: string): void {
    if (callback !== undefined) {
      this.oAuthService.redirectUri = this.remove_hash_from_url(callback);
    }
    this.oAuthService.logOut();
  }

  public getUserInfo(): WSO2UserInfo {
    return this.fetchUserInfoFromIdentityClaims();
  }

  public getUserInfoAsync(): Observable<WSO2UserInfo> {
    return this.userInfo.asObservable();
  }

  public getJwtToken(): String {
    return this.oAuthService.getIdToken();
  }

  private async refreshAuthenticationToken(): Promise<boolean> {
    return this.oAuthService.silentRefresh()
      .then(info => {
        this.userInfo.next(this.fetchUserInfoFromIdentityClaims());
        return true; 
      })
      .catch(err => {
          if (err.type && err.type === 'silent_refresh_timeout') {
            // console.log('SilentRefresh : ' + JSON.stringify(err));
            return true;
          } else {
            // console.log('SilentRefresh : ' + JSON.stringify(err));
            this.clearLoginData();
            this.oAuthService.initImplicitFlow();
            return false;
          }
      });
  }

  private clearLoginData(): void {
    AuthConstants.loginDataKeys.forEach(key => {
      sessionStorage.removeItem(key);
    });
  }

  private remove_hash_from_url(url: string): string {
    if (url.indexOf('#') > 0) {
      return url.substring(0, url.indexOf('#'));
    } else {
      return url;
    }
  }

  private fetchUserInfoFromIdentityClaims(): WSO2UserInfo {
    let claims: any = this.oAuthService.getIdentityClaims();

    let userInfo: WSO2UserInfo = new WSO2UserInfo();
    userInfo.userName = claims.sub;
    userInfo.email = claims.email;
    userInfo.firstName = claims.given_name;
    userInfo.lastName = claims.family_name;
    userInfo.country = claims.country;
    userInfo.roles = claims.role instanceof Array ? claims.role : new Array<string>(claims.role);
    userInfo.organization = claims.organization;
    userInfo.workPhone = claims.workphone;
    userInfo.mobilePhone = claims.mobile;
    return userInfo;
  }
}
