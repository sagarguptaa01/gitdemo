import { TestBed, inject } from '@angular/core/testing';

import { AuthenticationService } from './authentication.service';
import { OAuthService } from 'angular-oauth2-oidc';
import { AuthConstants } from './auth.constants';
import { WSO2UserInfo } from '../model/wso2userInfo.model';

describe('AuthenticationService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        AuthenticationService,
        { provide: OAuthService, useClass: MockOAuthService }
      ]
    });
  });

  it('should be created', inject([AuthenticationService], (service: AuthenticationService) => {
    expect(service).toBeTruthy();
  }));

  describe('authenticate', () => {
    it('should initialize oAuth implicit flow when an access_token is available',
      inject([AuthenticationService, OAuthService], (service: AuthenticationService, oAuthService: OAuthService) => {
        spyOn(oAuthService, 'getAccessToken').and.returnValue(null);
        let initImplicitFlowSpy = spyOn(oAuthService, 'initImplicitFlow');

        let result = service.authenticate();

        expect(initImplicitFlowSpy).toHaveBeenCalled();
      }));
  });

  describe('authenticate with callback', () => {
    it('should set callback to parameter', inject([AuthenticationService, OAuthService],
      (service: AuthenticationService, oauthService: OAuthService) => {
      let callback = 'user-profile';

      service.authenticate(callback);

      expect(oauthService.redirectUri).toEqual(callback);
    }));

    it('should authenticate', inject([AuthenticationService, OAuthService],
      (service: AuthenticationService, oauthService: OAuthService) => {
      let callback = 'user-profile';
      let authenticateSpy = spyOn(service, 'authenticate');

      service.authenticate(callback);

      expect(authenticateSpy).toHaveBeenCalled();
    }));
  });

  describe('authenticateOrRefreshToken', () => {
    it('should authenticate', inject([AuthenticationService], (service: AuthenticationService) => {
      let authentiateSpy = spyOn(service, 'authenticate');

      service.authenticateOrRefreshToken();

      expect(authentiateSpy).toHaveBeenCalled();
    }));

    it('should silently refresh if the user is logged in',
      inject([AuthenticationService, OAuthService], (service: AuthenticationService, oAuthService: OAuthService) => {
      spyOn(service, 'authenticate').and.returnValue(true);
      let silentRefreshSpy = spyOn(oAuthService, 'silentRefresh').and.returnValue(new Promise(null));

      let result = service.authenticateOrRefreshToken();

      expect(result).toBeTruthy();
      expect(silentRefreshSpy).toHaveBeenCalled();
    }));

    it('should not silently refresh if the user is logged in',
      inject([AuthenticationService, OAuthService], (service: AuthenticationService, oAuthService: OAuthService) => {
        spyOn(service, 'authenticate').and.returnValue(false);
        let silentRefreshSpy = spyOn(oAuthService, 'silentRefresh');

        service.authenticateOrRefreshToken().then(
        (result) => {
          expect(result).toBeFalsy();
          expect(silentRefreshSpy).toHaveBeenCalledTimes(0);
        });
    }));
  });

  describe('validateLoginStatus', () => {

    beforeEach(function () {
      jasmine.clock().install();
    });

    afterEach(function () {
      jasmine.clock().uninstall();
    });

    it('should return true when an access_token is available and is not expired', inject([AuthenticationService, OAuthService],
      (service: AuthenticationService, oAuthService: OAuthService) => {
        spyOn(oAuthService, 'hasValidAccessToken').and.returnValue(true);
        let result = service.validateLoginStatus();
        expect(result).toBeTruthy();
      }));

    it('should return false when an access_token is available but is expired', inject([AuthenticationService, OAuthService],
      (service: AuthenticationService, oAuthService: OAuthService) => {
        spyOn(oAuthService, 'hasValidAccessToken').and.returnValue(false);
        let result = service.validateLoginStatus();
        expect(result).toBeFalsy();
      }));

    it('should remove login data from sessionStorage when an access_token is available but is expired', inject([AuthenticationService, OAuthService],
      (service: AuthenticationService, oAuthService: OAuthService) => {
        spyOn(oAuthService, 'hasValidAccessToken').and.returnValue(false);
        let sessionStorageSpy = spyOn(sessionStorage, 'removeItem');
        let result = service.validateLoginStatus();

        AuthConstants.loginDataKeys.forEach(key => {
          expect(sessionStorageSpy).toHaveBeenCalledWith(key);
        });
      }));

    it('should return false when an access_token is not available', inject([AuthenticationService, OAuthService],
      (service: AuthenticationService, oAuthService: OAuthService) => {
        spyOn(oAuthService, 'hasValidAccessToken').and.returnValue(false);
        let result = service.validateLoginStatus();
        expect(result).toBeFalsy();
      }));
  });

  describe('logOut', () => {
    it('should use the oAuthService to log out',
      inject([AuthenticationService, OAuthService], (service: AuthenticationService, oAuthService: OAuthService) => {
        let logOutSpy = spyOn(oAuthService, 'logOut');

        let result = service.logOut();

        expect(logOutSpy).toHaveBeenCalled();
      }));
  });

  describe('getHeaderAuthorization', () => {
    it('should return a string containing "Bearer " and the access_token from sessionStorage',
      inject([AuthenticationService, OAuthService], (service: AuthenticationService, oAuthService: OAuthService) => {
        let accessToken = 'access tokenerino';
        spyOn(oAuthService, 'getAccessToken').and.returnValue(accessToken);

        let headerAuthorization = service.getHeaderAuthorization();

        expect(headerAuthorization).toEqual('Bearer ' + accessToken);
      }));
  });
  
});

describe('AuthService2', () => {

  describe('getUserInfo', () => {

    let component: AuthenticationService;
    let oAuthServiceMock: OAuthService;

    beforeEach(function () {
      oAuthServiceMock = new MockOAuthService();
      component = new AuthenticationService(oAuthServiceMock);
    });

    it('should map sub to username', () => {

      let claims: any = {
        sub: 'ads'
      };

      spyOn(oAuthServiceMock, 'getIdentityClaims').and.returnValue(claims);
      let result = component.getUserInfo();

      expect(result.userName).toEqual(claims.sub);
    });

    it('should map role to an array of roles if claims.role is a string and not an array', () => {

      let claims: any = {
        role: 'admin'
      };

      spyOn(oAuthServiceMock, 'getIdentityClaims').and.returnValue(claims);
      let result = component.getUserInfo();

      expect(result.roles[0]).toEqual(claims.role);
    });

    it('should map role to roles when claims.role is an array', () => {

      let claims: any = {
        role: ['admin', 'admin2']
      };

      spyOn(oAuthServiceMock, 'getIdentityClaims').and.returnValue(claims);
      let result = component.getUserInfo();

      expect(result.roles[0]).toEqual('admin');
      expect(result.roles[1]).toEqual('admin2');
    });

    it('should map email to email ', () => {

      let claims: any = {
        email: 'test@test.com'
      };

      spyOn(oAuthServiceMock, 'getIdentityClaims').and.returnValue(claims);
      let result = component.getUserInfo();

      expect(result.email).toEqual(claims.email);

    });

    it('should map given_name to fistName ', () => {

      let claims: any = {
        given_name: 'test@test.com'
      };

      spyOn(oAuthServiceMock, 'getIdentityClaims').and.returnValue(claims);
      let result = component.getUserInfo();

      expect(result.firstName).toEqual(claims.given_name);

    });

    it('should map family_name to lastName ', () => {

      let claims: any = {
        family_name: 'test'
      };

      spyOn(oAuthServiceMock, 'getIdentityClaims').and.returnValue(claims);
      let result = component.getUserInfo();

      expect(result.lastName).toEqual(claims.family_name);
    });

    it('should map country to country ', () => {

      let claims: any = {
        country: 'Kébec'
      };

      spyOn(oAuthServiceMock, 'getIdentityClaims').and.returnValue(claims);
      let result = component.getUserInfo();

      expect(result.country).toEqual(claims.country);
    });

    it('should map organization to organization ', () => {

      let claims: any = {
        organization: 'test'
      };

      spyOn(oAuthServiceMock, 'getIdentityClaims').and.returnValue(claims);
      let result = component.getUserInfo();

      expect(result.organization).toEqual(claims.organization);
    });

    it('should map workphone to workPhone ', () => {

      let claims: any = {
        workphone: '11111111111'
      };

      spyOn(oAuthServiceMock, 'getIdentityClaims').and.returnValue(claims);
      let result = component.getUserInfo();

      expect(result.workPhone).toEqual(claims.workphone);
    });

    it('should map mobile to mobilePhone ', () => {

      let claims: any = {
        mobile: '222222222'
      };

      spyOn(oAuthServiceMock, 'getIdentityClaims').and.returnValue(claims);
      let result = component.getUserInfo();

      expect(result.mobilePhone).toEqual(claims.mobile);
    });
  });

  describe('getUserInfoAsync', () => {
    it('should fetch latest user info when called authenticateOrRefreshToken', () => {
      // Arrange
      let service: AuthenticationService;
      let oAuthServiceMock: OAuthService;
      oAuthServiceMock = new MockOAuthService();
      service = new AuthenticationService(oAuthServiceMock);

      let userInfo: WSO2UserInfo = new WSO2UserInfo();
      userInfo.userName = '11111111111';
      userInfo.email = 'test@exfo.com';
      userInfo.firstName = 'test';
      userInfo.lastName = 'test';
      userInfo.country = 'Kébec';
      userInfo.roles = ['admin', 'admin2'];
      userInfo.organization = 'test';
      userInfo.workPhone = '11111111111';
      userInfo.mobilePhone = '11111111111';

      let claims: any = {
        sub: '11111111111',
        email: 'test@exfo.com',
        given_name: 'test',
        family_name: 'test',
        country: 'Kébec',
        role: ['admin', 'admin2'],
        organization: 'test',
        workPhone: '11111111111',
        mobile: '11111111111',
      };
    
      let hasValidAccessTokenSpy = spyOn(oAuthServiceMock, 'hasValidAccessToken').and.returnValue(true);
      let silentRefreshSpy = spyOn(oAuthServiceMock, 'silentRefresh').and.returnValue(new Promise(x => { }));
      let getIdentityClaimsSpy = spyOn(oAuthServiceMock, 'getIdentityClaims').and.returnValue(claims);

      // Act
      service.authenticateOrRefreshToken().then(()=> {
        // Assert
        
        expect(hasValidAccessTokenSpy).toHaveBeenCalled();
        expect(silentRefreshSpy).toHaveBeenCalled();
        expect(getIdentityClaimsSpy).toHaveBeenCalled();

        // Assert for latest data we set by spying
        service.getUserInfoAsync().subscribe( result => {
          expect(result.userName).toEqual(userInfo.userName);  
          expect(result.email).toEqual(userInfo.email);
          expect(result.firstName).toEqual(userInfo.firstName);
          expect(result.lastName).toEqual(userInfo.lastName);
          expect(result.roles[0]).toEqual(userInfo.roles[0]);
          expect(result.roles[1]).toEqual(userInfo.roles[1]);
          expect(result.country).toEqual(userInfo.country);
          expect(result.organization).toEqual(userInfo.organization);
          expect(result.workPhone).toEqual(userInfo.workPhone);
          expect(result.mobilePhone).toEqual(userInfo.mobilePhone);
        });
      });
    });
  });
});

class MockOAuthService extends OAuthService {
  constructor() {
    super(null, null, null, null, null);
  }
  initImplicitFlow() { }
}
