export class UserProfileModel {
  firstName: string;
  lastName: string;
  company: string;
  country: string;
  email: string;
  workPhone: string;
  mobilePhone: string;
  roles: string;
}