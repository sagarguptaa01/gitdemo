import { Component, OnInit, ViewChild } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { ConfigKeys } from '../../global/config-keys.constants';
import { ConfigService } from '../../global/config.service';
import { CountryDto } from '../../global/dto/country.dto';
import { CountryService } from '../../global/country.service';
import { ErrorExtractorService } from '../../global/error-extractor.service';
import { UserProfileModel } from './user-profile.model';
import { UserProfileService } from './service/user-profile.service';
import { AuthenticationService } from '../auth/service/authentication.service';
import { WSO2UserInfo } from '../auth/model/wso2userInfo.model';
import { UserProfileDto } from './service/dto/user-profile.dto';
import { Utils } from '../../global/utils';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {
  model = new UserProfileModel();

  countries: CountryDto[];
  userProfileData: any;

  message: string;
  isErrorMessage: boolean;

  firstNameRegex: string;
  lastNameRegex: string;
  companyNameRegex: string;
  phoneRegex: string;

  firstNameMaxLength: string;
  lastNameMaxLength: string;
  companyNameMaxLength: string;
  phoneMaxLength: string;

  @ViewChild('userProfileForm') form;

  constructor(private userProfileService: UserProfileService,
    private countryService: CountryService,
    private config: ConfigService,
    private authService: AuthenticationService,
    private errorService: ErrorExtractorService) { }

  private getCountries(): Observable<CountryDto[]> {
    let firstCountries = this.config.get(ConfigKeys.firstCountries);
    return this.countryService.getCountryList(firstCountries);
  }

  ngOnInit() {
    this.hideServerError();

    this.firstNameRegex = this.config.get(ConfigKeys.firstName.regex);
    this.lastNameRegex = this.config.get(ConfigKeys.lastName.regex);
    this.companyNameRegex = this.config.get(ConfigKeys.companyName.regex);
    this.phoneRegex = this.config.get(ConfigKeys.phoneNumber.regex);

    this.firstNameMaxLength = this.config.get(ConfigKeys.firstName.maxLength);
    this.lastNameMaxLength = this.config.get(ConfigKeys.lastName.maxLength);
    this.companyNameMaxLength = this.config.get(ConfigKeys.companyName.maxLength);
    this.phoneMaxLength = this.config.get(ConfigKeys.phoneNumber.maxLength);

    const userInfo = this.authService.getUserInfo();
    this.getCountries().subscribe(countries => {
      this.countries = countries;
      this.restoreData(userInfo);
    });
  }

  onSubmit() {
    this.hideServerError();

    let updateDto: UserProfileDto = new UserProfileDto();
    updateDto.country = this.getCountryName(this.model.country);
    updateDto.firstName = Utils.trim(this.model.firstName);
    updateDto.lastName = Utils.trim(this.model.lastName);
    updateDto.workPhone = Utils.trim(this.model.workPhone);
    updateDto.mobilePhone = Utils.trim(this.model.mobilePhone);
    updateDto.organization = Utils.trim(this.model.company);

    this.userProfileService.updateUserProfile(updateDto)
        .subscribe(
          response => this.afterSubmit(response),
          error => this.handleError(error)
        );

  }

  private afterSubmit(response) {
    if (response) {
      this.trimWhiteSpacesInModel();
      this.resetForm();
      this.isErrorMessage = false;
      this.message = 'Saved';

      //TODO We will change this method call by splitting the authenticateOrRefreshToken to RefreshTokenIfLoggedIn only.
      this.authService.authenticateOrRefreshToken();
    }
  }

  private resetForm() {
    this.form.reset({
      firstname: this.model.firstName,
      lastname: this.model.lastName,
      company: this.model.company,
      country: this.model.country,
      email: this.model.email,
      roles: this.model.roles,
      workphone: this.model.workPhone,
      mobilephone: this.model.mobilePhone
    });
  }

  hideServerError() {
    this.message = '';
  }

  private restoreData(userInfo: WSO2UserInfo) {

    this.model.firstName = userInfo.firstName;
    this.model.lastName = userInfo.lastName;
    this.model.company = userInfo.company;

    let countryDto = null;
    if (userInfo.country) {
      countryDto = this.countries.find(c => c.name === userInfo.country);
    }

    this.model.country = countryDto ? countryDto.code : '';
    this.model.email = userInfo.email;
    this.model.mobilePhone = userInfo.mobilePhone;
    this.model.workPhone = userInfo.workPhone;
    this.model.roles = userInfo.roles.filter(role => this.filterInternalRoles(role)).join(',');
    this.model.company = userInfo.organization;

    this.resetForm();
  }

  private filterInternalRoles(role: string) {
    return (role !== 'Internal/everyone') &&
           (!role.startsWith('Invite_')) &&
           (!role.startsWith('Organization_'));
  }

  private handleError(error) {
    this.isErrorMessage = true;
    this.message = this.errorService.getErrorMessage(error);
  }

  private getCountryName(countryCode: String): String {
    let country = this.countries.find(c => c.code === this.model.country);

    if (country !== undefined) {
      return country.name;
    }

    return '';
  }
  
  private trimWhiteSpacesInModel() {
    this.model.firstName=Utils.trim(this.model.firstName);
    this.model.lastName=Utils.trim(this.model.lastName);
    this.model.workPhone=Utils.trim(this.model.workPhone);
    this.model.mobilePhone= Utils.trim(this.model.mobilePhone);
    this.model.company=Utils.trim(this.model.company);
  }

}