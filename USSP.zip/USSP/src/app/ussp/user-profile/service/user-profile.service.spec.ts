import { UserProfileService } from './user-profile.service';
import { RequestOptions } from '@angular/http';
import { BackendApiConstants } from '../../../global/backend-api.constants';
import { AuthenticationService } from '../../auth/service/authentication.service';
import { UserProfileDto } from './dto/user-profile.dto';
import { AuthHttp } from '../../service/auth-http.service';
import { Observable } from 'rxjs/Rx';

describe('UserProfileService', () => {
  let service: UserProfileService;
  let authHttp: AuthHttp;
  let authService: AuthenticationService;

  beforeEach(() => {
    authHttp = new MockAuthHttp();
    authService = new MockAuthService();
    service = new UserProfileService(authHttp, authService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('setUserProfile', () => {
    it('should make a call to the USSP backend service endpoint', () => {
      let actualUrl: string;
      let authHttpGetSpy = spyOn(authHttp, 'post').and.callFake((url, body, options) => {
        actualUrl = url;
      });

      service.updateUserProfile(new UserProfileDto());

      expect(actualUrl).toContain(BackendApiConstants.baseUrl + BackendApiConstants.services.updateUserProfile.name);
    });

    it('should include the jwt token from the current authService current user in the request header', () => {
      const bearerTokenValue = 'BearerVALUE';
      spyOn(authService, 'getJwtToken').and.returnValue(bearerTokenValue);
      let actualOptions: RequestOptions;
      let authHttpGetSpy = spyOn(authHttp, 'post').and.callFake((url, body, options) => {
        actualOptions = options;
      });

      service.updateUserProfile(new UserProfileDto());

      let authHeader = actualOptions.headers.get('Authorization');
      expect(authHeader).toEqual('Bearer ' + bearerTokenValue);
    });
  });
});

class MockAuthService extends AuthenticationService {

  constructor() {
    super(null);
  }

  public getJwtToken(): string {
    return '';
  }
}

class MockAuthHttp extends AuthHttp {

  constructor() {
    super(null, null);
  }

  public post(url: string, body: any, options?: RequestOptions): Observable<any> {
    return Observable.of();
  }

  public get(url: string, options?: RequestOptions): Observable<any> {
    return Observable.of();
  }
}
