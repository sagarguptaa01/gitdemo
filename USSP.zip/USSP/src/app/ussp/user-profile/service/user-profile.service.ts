import { Injectable, Inject } from '@angular/core';
import { Headers, RequestOptions, URLSearchParams } from '@angular/http';
import { AuthenticationService } from '../../auth/service/authentication.service';
import { UserProfileDto } from './dto/user-profile.dto';
import { BackendApiConstants } from '../../../global/backend-api.constants';
import { AuthHttp } from '../../service/auth-http.service';

@Injectable()
export class UserProfileService {

  constructor(private authHttp: AuthHttp, private authService: AuthenticationService) { }

  public updateUserProfile(userProfile: UserProfileDto) {
    let params = new URLSearchParams();
    let requestOptions = new RequestOptions();
    requestOptions.params = params;
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
    headers.append('Authorization', `Bearer ${this.authService.getJwtToken()}`);
    requestOptions.headers = headers;
    let url = BackendApiConstants.baseUrl + BackendApiConstants.services.updateUserProfile.name;
    return this.authHttp.post(url, userProfile, requestOptions);
  }
}
