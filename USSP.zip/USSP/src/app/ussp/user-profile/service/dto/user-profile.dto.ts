import { PropertyDto } from "../../../../wso2/registration/service/dto/property.dto";

export class UserProfileDto {
    userName: String;
    firstName: String;
    lastName: String;
    organization: String;
    country: String;
    workPhone: String;
    mobilePhone: String;
    acceptUserPrivacyNotice: boolean;
    acceptLicenseAgreement: boolean;
    acceptReceiveExfoCommunication: boolean;
    properties:PropertyDto[] = [];
}
