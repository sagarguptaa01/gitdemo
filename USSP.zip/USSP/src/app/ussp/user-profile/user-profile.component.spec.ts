import { Observable } from 'rxjs/Rx';
import { UserProfileComponent } from './user-profile.component';
import { UserProfileService } from './service/user-profile.service';
import { CountryService } from '../../global/country.service';
import { CountryDto } from '../../global/dto/country.dto';
import { ConfigService } from '../../global/config.service';
import { ConfigKeys } from '../../global/config-keys.constants';
import { ErrorExtractorService } from '../../global/error-extractor.service';
import { AuthenticationService } from '../auth/service/authentication.service';
import { WSO2UserInfo } from '../auth/model/wso2userInfo.model';
import { Response, ResponseOptions } from '@angular/http';

describe('UserProfileComponent', () => {
  let component: UserProfileComponent;
  let authServiceMock: AuthenticationService;
  let configServiceMock: ConfigService;
  let countryServiceMock: CountryService;
  let userProfileServiceMock: UserProfileService;
  let errorExtractorServiceMock: ErrorExtractorService;

  class MockAuthService extends AuthenticationService {
    constructor() {
      super(null);
    }
    public getUserInfo(): WSO2UserInfo {
      return new WSO2UserInfo();
    }
  }

  class MockUserProfileService extends UserProfileService {
    constructor() {
      super(null, null);
    }
  }

  class MockCountryService extends CountryService {
    constructor() {
      super(null);
    }
  }

  class MockConfigService extends ConfigService {
    constructor() {
      super(null);
    }
  }

  class MockErrorExtractorService extends ErrorExtractorService {
    constructor() {
      super();
    }

    public getErrorMessage(data: any): string {
      return 'error';
    }
  }

  beforeEach(() => {
    userProfileServiceMock = new MockUserProfileService();
    countryServiceMock = new MockCountryService();
    authServiceMock = new MockAuthService();
    configServiceMock = new MockConfigService();
    errorExtractorServiceMock = new MockErrorExtractorService();
    component = new UserProfileComponent(userProfileServiceMock,
      countryServiceMock,
      configServiceMock,
      authServiceMock,
      errorExtractorServiceMock);

    // Default values
    component.form = new Object();
    component.form.reset = function () { };

    component.countries = [new CountryDto('CA', 'CANADA')];
    component.model.country = 'CA';
    component.model.firstName = "";
    component.model.lastName = "";
    component.model.workPhone = "";
    component.model.mobilePhone = "";
    component.model.company = "";
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should set the "isErrorMessage" flag to "false"', () => {
    expect(component.isErrorMessage).toBeFalsy();
  });

  it('should call CountryService to get the country list the first countries by Config', () => {
    let firstCountriesCodes = ['US', 'CA'];
    let configServiceSpy = spyOn(configServiceMock, 'get').and.callFake(configKey => {
      if (configKey === ConfigKeys.firstCountries) {
        return firstCountriesCodes;
      }
    });

    let countryServiceSpy = spyOn(countryServiceMock, 'getCountryList').and.returnValue(Observable.of(null));

    component.ngOnInit();
    expect(countryServiceSpy).toHaveBeenCalledWith(['US', 'CA']);
  });

  it('should call AuthService to get the user profile at startup', () => {
    let spy = spyOn(authServiceMock, 'getUserInfo').and.callThrough();
    spyOn(configServiceMock, 'get').and.returnValue('');
    spyOn(countryServiceMock, 'getCountryList').and.returnValue(Observable.of(null));

    component.ngOnInit();
    expect(spy).toHaveBeenCalledTimes(1);
  });

  it('should set the "message" to "" at startup', () => {
    spyOn(authServiceMock, 'getUserInfo').and.callThrough();
    spyOn(configServiceMock, 'get').and.returnValue('');
    spyOn(countryServiceMock, 'getCountryList').and.returnValue(Observable.of(null));

    component.ngOnInit();
    expect(component.message).toEqual('');
  });

  describe('onSubmit', () => {

    beforeEach(() => {
      spyOn(authServiceMock, 'authenticateOrRefreshToken').and.callFake(() => { });
    });

    it('should use UserProfileService to update the profile', () => {

      let spy = spyOn(userProfileServiceMock, 'updateUserProfile').and.returnValue(Observable.of(null));
      component.onSubmit();
      expect(spy).toHaveBeenCalledTimes(1);
    });

    describe('when the call to UserProfileService is successful', () => {
      it('should set the flag "isErrorMessage" to "false"', () => {
        spyOn(userProfileServiceMock, 'updateUserProfile').and.returnValue(Observable.of(true));
        component.onSubmit();
        expect(component.isErrorMessage).toBeFalsy();
      });

      it('should set the "message" to "Saved"', () => {
        spyOn(userProfileServiceMock, 'updateUserProfile').and.returnValue(Observable.of(true));
        component.onSubmit();
        expect(component.message).toEqual('Saved');
      });
    });

    describe('when the call to UserProfileService returns an error', () => {

      it('should set the flag "isErrorMessage" to "true"', () => {
        spyOn(userProfileServiceMock, 'updateUserProfile').and.returnValue(Observable.throw(new Response(new ResponseOptions({ body: '{}'}))));
        component.onSubmit();
        expect(component.isErrorMessage).toBeTruthy();
      });

      it('should set the "message" to the error', () => {
        spyOn(userProfileServiceMock, 'updateUserProfile').and.returnValue(Observable.throw(new Response(new ResponseOptions({ body: '{}'}))));
        component.onSubmit();
        expect(component.message).toEqual('error');
      });
    });

    it('should set the first name in the server data', () => {
      let expected = 'myFirstName';
      spyOn(userProfileServiceMock, 'updateUserProfile').and.callFake(data => {
        expect(data.firstName).toBe(expected);
        return new Observable<any>(observer => observer.next(new Response(new ResponseOptions({ body: '{}'}))));
      });
      component.model.firstName = expected;
      component.onSubmit();
    });

    it('should set the last name in the server data', () => {
      let expected = 'myLastName';
      let spy = spyOn(userProfileServiceMock, 'updateUserProfile')
        .and.callFake(data => {
          expect(data.lastName).toBe(expected);
          return new Observable<any>(observer => observer.next(new Response(new ResponseOptions({ body: '{}'}))));
        });
      component.model.lastName = expected;
      component.onSubmit();
    });

    it('should set the organization in the server data', () => {
      let expected = 'myOrganization';
      let spy = spyOn(userProfileServiceMock, 'updateUserProfile').and.callFake(data => {
        expect(data.organization).toBe(expected);
        return new Observable<any>(observer => observer.next(new Response(new ResponseOptions({ body: '{}'}))));
      });
      component.model.company = expected;
      component.onSubmit();
    });

    it('should set the country in the server data', () => {
      let expected = 'Mexico';
      let spy = spyOn(userProfileServiceMock, 'updateUserProfile').and.callFake(data => {
        expect(data.country).toBe(expected);
        return new Observable<any>(observer => observer.next(new Response(new ResponseOptions({ body: '{}'}))));
      });

      component.countries = [new CountryDto('ME', 'Mexico')];
      component.model.country = 'ME';
      component.onSubmit();
    });

    it('should set the mobile in the server data', () => {
      let expected = 'myMobilePhone';

      let spy = spyOn(userProfileServiceMock, 'updateUserProfile').and
        .callFake(data => {
          expect(data.mobilePhone).toBe(expected);
          return new Observable<any>(observer => observer.next(new Response(new ResponseOptions({ body: '{}'}))));
        });
      component.model.mobilePhone = expected;
      component.onSubmit();
    });

    it('should set the work phone in the server data', () => {
      let expected = 'myWorkPhone';
      let spy = spyOn(userProfileServiceMock, 'updateUserProfile').and.callFake(data => {
        expect(data.workPhone).toBe(expected);
        return new Observable<any>(observer => observer.next(new Response(new ResponseOptions({ body: '{}'}))));
      });
      component.model.workPhone = expected;
      component.onSubmit();
    });

   [{ modelElement: 'firstName',    updateUserProfileDtoElement: 'firstName',   value: ' firstName ',    expectedResult: 'firstName' },
    { modelElement: 'lastName',     updateUserProfileDtoElement: 'lastName',    value: ' address ',      expectedResult: 'address' },
    { modelElement: 'workPhone',    updateUserProfileDtoElement: 'workPhone',   value: ' 111111 ',       expectedResult: '111111' },
    { modelElement: 'mobilePhone',  updateUserProfileDtoElement: 'mobilePhone', value: ' 9999999999 ',   expectedResult: '9999999999' },
    { modelElement: 'company',      updateUserProfileDtoElement: 'organization',value: ' email ',        expectedResult: 'email' },
   ].forEach(function (run) {
      it('should trim when "' + run.modelElement + '" have extra spaces', function () {
        // Arrange & Define Assert
        component.model[run.modelElement] = run.value;
        spyOn(userProfileServiceMock, 'updateUserProfile').and.callFake(data => {
          expect(data[run.updateUserProfileDtoElement]).toBe(run.expectedResult);
          return new Observable<any>(observer => observer.next(new Response(new ResponseOptions())));
        });

        // Act
        component.onSubmit();
      });
    });

    [{modelElement: 'firstName',    updateUserProfileDtoElement: 'firstName',     value: undefined,          expectedResult: undefined },
    { modelElement: 'lastName',     updateUserProfileDtoElement: 'lastName',      value: null,               expectedResult: null },
    { modelElement: 'workPhone',    updateUserProfileDtoElement: 'workPhone',     value: undefined,          expectedResult: undefined },
    { modelElement: 'mobilePhone',  updateUserProfileDtoElement: 'mobilePhone',   value: ' 9999999999 ',     expectedResult: '9999999999' },
    { modelElement: 'company',      updateUserProfileDtoElement: 'organization',  value: '',                 expectedResult: '' },
   ].forEach(function (run) {
      it('should not trim when "' + run.modelElement + '" is NULL or UNDEFINED', function () {
        // Arrange & Define Assert
        component.model[run.modelElement] = run.value;
        spyOn(userProfileServiceMock, 'updateUserProfile').and.callFake(data => {
          expect(data[run.updateUserProfileDtoElement]).toBe(run.expectedResult);
          return new Observable<any>(observer => observer.next(new Response(new ResponseOptions())));
        });

        // Act
        component.onSubmit();
      });
    });

    [{modelElement: 'firstName',    updateUserProfileDtoElement: 'firstName',   value: ' firstName ',    expectedResult: 'firstName' },
    { modelElement: 'lastName',     updateUserProfileDtoElement: 'lastName',    value: ' address ',      expectedResult: 'address' },
    { modelElement: 'workPhone',    updateUserProfileDtoElement: 'workPhone',   value: ' 111111 ',       expectedResult: '111111' },
    { modelElement: 'mobilePhone',  updateUserProfileDtoElement: 'mobilePhone', value: ' 9999999999 ',   expectedResult: '9999999999' },
    { modelElement: 'company',      updateUserProfileDtoElement: 'organization',value: ' email ',        expectedResult: 'email' },
   ].forEach(function (run) {
      it('should trim when "' + run.modelElement + '" to its trimmed value after successful submit operation', function () {
        // Arrange & Define Assert
        component.model[run.modelElement] = run.value;
        spyOn(userProfileServiceMock, 'updateUserProfile').and.callFake(data => {
          expect(data[run.updateUserProfileDtoElement]).toBe(run.expectedResult);
          return new Observable<any>(observer => observer.next(new Response(new ResponseOptions())));
        });

        // Act
        component.onSubmit();
      });
    });    

  });
});

